# V8 Windows Installer - Instructions

## 1. Prepare Windows

Use Windows 10 or 11 x64 with 64-bit Python 3.11, 3.12 or 3.13. Use a Carlinkit Mini Ultra 3 with firmware 26011618.6238.2 and the board shown below. The Audi cluster extension must already work over an iPhone cable.

1. Download and install Python from python.org/downloads/windows/. Include the Python launcher.

2. Download Zadig from zadig.akeo.ie.

3. Right-click the V8 Windows ZIP, choose Extract All, and open the extracted folder. Keep an internet connection for the first setup.

## 2. Put the dongle into FEL mode

4. Disconnect the dongle. Open its case and match the board orientation to this drawing. If the board differs or B1 is not confirmed ground, stop.

![FEL reference board](docs/FEL-Reference.svg)

5. With USB disconnected, connect only flash pin 1 to the confirmed B1 ground point. Plug the dongle into the PC.

6. Remove the bridge immediately when FEL is detected, and always within five seconds, even without a detection message. Leave USB connected. Keep pin 8 and all other contacts untouched.

## 3. Install the first USB driver

1. Open Zadig. Select Options > List All Devices.

2. Select the dongle entry with USB ID 1F3A : EFE8. It may be named FEL, AWUSBFEX or USB Device. Match the ID before proceeding.

3. Select WinUSB, then click Install Driver or Replace Driver. Approve the Windows prompt. Leave the dongle connected without a bridge.

## 4. Run the installer

4. Double-click Start-Windows.cmd. Wait for setup to finish and the menu to appear.

5. Select 1. Continue when the window shows FEL CONNECTION VERIFIED.

6. Select 2. Type ULTRA3 when requested. Wait while both original backups are read and checked.

7. When prompted, type INSTALL. Keep USB connected until the full write and readback have finished.

8. When the installer asks, unplug the dongle and reconnect it normally, without a bridge. Then press Enter.

## 5. Install the second USB driver

9. While the installer waits for the diagnostic connection, return to Zadig and refresh the device list.

10. Select Audi-USB-Diagnose with USB ID 18D1 : D002. Select WinUSB and install that driver. Leave USB connected.

11. Return to the installer window. It continues automatically after the driver is available. If its wait has already ended, select 3 and choose the backup number created in step 6.

## 6. Complete installation

1. Wait until the installer displays VERSION 8 INSTALLED AND VERIFIED.

2. Close the window and unplug the dongle.

3. Keep the extracted installer folder and its private folder together. Save another private copy for recovery. Share only the original unused release ZIP.

## 7. Test in the Audi

4. Connect the dongle in the parked Audi and pair your iPhone as usual.

5. Start a route. Check the cluster map, street name and junction detail. Check steering-wheel zoom and repeated double-OK switching.

6. Check music and a phone call. Unplug and reconnect once, then check connection again after a longer parking period.

## Continue after an interrupted reconnect

Open Start-Windows.cmd from the same folder. Select 3, choose your backup number and leave the dongle connected. Complete the diagnostic WinUSB driver setup if requested. Wait for VERSION 8 INSTALLED AND VERIFIED before unplugging.

## Restore your original root filesystem

1. Connect the dongle normally to the PC, without a bridge. If necessary, allow about a minute for the diagnostic USB connection to appear.

2. Open Start-Windows.cmd from the same folder that contains your original backups.

3. Select 4 and choose your own backup number. Type RESTORE when requested.

4. Leave USB connected until ORIGINAL ROOT FILESYSTEM RESTORED AND VERIFIED appears.

5. Unplug and reconnect normally. Test original CarPlay in the Audi.

If the diagnostic connection is unavailable, repeat the confirmed FEL entry on page 1, then select 4 using the same backup folder.

