"""Shared validation. Never opens USB and never writes a device."""
from pathlib import Path
import hashlib
import json
import stat

PROJECT = Path(__file__).resolve().parents[1]
REFERENCE = json.loads((PROJECT / 'reference.json').read_text())
SIZE = REFERENCE['flash_bytes']
START, END = REFERENCE['root_start'], REFERENCE['root_end']

def sha(data):
    return hashlib.sha256(data).hexdigest()

def payload_ok():
    expected_names = set(REFERENCE['payload_files'])
    actual_names = {p.name for p in (PROJECT / 'payload').iterdir()}
    if actual_names != expected_names:
        raise ValueError('Release payload inventory differs from the reference.')
    for name, expected in REFERENCE['payload_files'].items():
        p = PROJECT / 'payload' / name
        if p.is_symlink() or not p.is_file() or sha(p.read_bytes()) != expected:
            raise ValueError('Release payload missing or modified: ' + name)

def factory_ok(data):
    if len(data) != SIZE:
        raise ValueError('Backup must contain exactly 16 MiB.')
    checks = [
        (data[START:END], 'factory_root_sha256'),
        (data[:START], 'factory_boot_kernel_region_sha256'),
        (data[END:REFERENCE['customer_end']], 'factory_customer_region_sha256'),
    ]
    for region, name in checks:
        if sha(region) != REFERENCE[name]:
            raise ValueError('Unsupported or modified firmware: ' + name)

def backup_pair(a, b):
    a, b = Path(a), Path(b)
    if a.is_symlink() or b.is_symlink():
        raise ValueError('Backup symlinks are not accepted.')
    if a.resolve() == b.resolve():
        raise ValueError('Two distinct backup files from two reads are required.')
    sa, sb = a.stat(), b.stat()
    if not stat.S_ISREG(sa.st_mode) or not stat.S_ISREG(sb.st_mode):
        raise ValueError('Backups must be regular files.')
    if (sa.st_dev, sa.st_ino) == (sb.st_dev, sb.st_ino):
        raise ValueError('Two hardlinks to the same file are not two reads.')
    if sa.st_size != SIZE or sb.st_size != SIZE:
        raise ValueError('Both backups must contain exactly 16 MiB.')
    first, second = a.read_bytes(), b.read_bytes()
    if len(first) != SIZE or len(second) != SIZE or first != second:
        raise ValueError('Two complete identical 16-MiB reads are required.')
    factory_ok(first)
    return first

def profile(path):
    path = Path(path).resolve()
    data = json.loads(path.read_text())
    if data.get('schema') != 1 or data.get('revision') != 8:
        raise ValueError('A Version-8 profile is required.')
    directory = path.parent
    original = (directory / 'fullbackup.bin').read_bytes()
    target = (directory / 'rootfs-v8.bin').read_bytes()
    factory_ok(original)
    if data['backup_sha256'] != sha(original):
        raise ValueError('Owner backup no longer matches its profile.')
    if sha(target) != REFERENCE['target_root_sha256'] or data['target_root_sha256'] != sha(target):
        raise ValueError('Target rootfs is not the tested V8 image.')
    if (directory / 'rootfs-original.bin').read_bytes() != original[START:END]:
        raise ValueError('Original rootfs does not match the owner backup.')
    manifest = (directory / 'runtime/SHA256SUMS').read_bytes()
    if sha(manifest) != REFERENCE['runtime_manifest_sha256']:
        raise ValueError('Runtime manifest is not the tested V8 manifest.')
    if {p.name for p in (directory / 'runtime').iterdir()} != set(REFERENCE['runtime_files']):
        raise ValueError('Unexpected local runtime files.')
    for name, expected in REFERENCE['runtime_files'].items():
        if (directory / 'runtime' / name).is_symlink():
            raise ValueError('Runtime symlinks are not accepted.')
        if sha((directory / 'runtime' / name).read_bytes()) != expected:
            raise ValueError('Runtime file modified: ' + name)
    payload_ok()
    return directory, data

def verify_flash(before, after, target):
    if len(before) != SIZE or len(after) != SIZE or len(target) != END - START:
        raise ValueError('Complete flash readbacks are required.')
    if after[START:END] != target or before[:START] != after[:START] or before[END:] != after[END:]:
        raise ValueError('Rootfs readback or unchanged regions failed verification.')
    return [hex(i) for i in range(0, SIZE, 4096) if before[i:i+4096] != after[i:i+4096]]

def apply_unified(original, patch):
    """Strict context matching; no fuzz, offsets, or execution of OEM code."""
    import re
    source = original.splitlines(keepends=True)
    lines = patch.splitlines(keepends=True)
    output, cursor, i = [], 0, 2
    while i < len(lines):
        match = re.match(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', lines[i])
        if not match:
            raise ValueError('Invalid patch hunk.')
        at, old_count = int(match[1]), int(match[2] or '1')
        new_count = int(match[4] or '1')
        at = at - 1 if old_count else at
        if at < cursor or at > len(source):
            raise ValueError('Patch position outside original file.')
        output.extend(source[cursor:at]); cursor = at
        seen_old = seen_new = 0
        i += 1
        while i < len(lines) and not lines[i].startswith('@@ '):
            line = lines[i]
            if not line or line[0] not in ' +-':
                raise ValueError('Unsupported patch line.')
            value = line[1:]
            if line[0] in ' -':
                if cursor >= len(source) or source[cursor] != value:
                    raise ValueError('Patch context differs from supported firmware.')
                cursor += 1; seen_old += 1
            if line[0] in ' +':
                output.append(value); seen_new += 1
            i += 1
        if (seen_old, seen_new) != (old_count, new_count):
            raise ValueError('Patch hunk counts differ.')
    output.extend(source[cursor:])
    return ''.join(output)
