"""Verify the actual V8 boot and all runtime bytes before enabling CarPlay."""
from pathlib import Path
import argparse
import datetime
import json
import re
import shutil
import subprocess
from common import REFERENCE, sha, profile

Z = '/mnt/UDISK/audi-zoom6238'

def valid_port(port):
    if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
        raise ValueError('Invalid local service port.')
    return port

def hash_lines(text):
    values = {}
    for line in text.splitlines():
        m = re.fullmatch(r'([0-9a-f]{64})\s+\*?(/\S+)', line.strip())
        if m:
            if m[2] in values:
                raise ValueError('Ambiguous device checksum.')
            values[m[2]] = m[1]
    return values

def adb_command(port=5037):
    import sys
    return [sys.executable, '-X', 'utf8', str(Path(__file__).with_name('adb_windows.py'))]

def verify_boot(text):
    hashes = hash_lines(text)
    if not re.search(r'\buid=0\(root\)', text) or hashes.get('/dev/mtd3') != REFERENCE['target_root_sha256'] or hashes.get('/sbin/ly_boot.sh') != REFERENCE['target_boot_script_sha256']:
        raise ValueError('Actual V8 root boot was not confirmed. No upload.')

def verify_runtime_copy(directory, allowed_modes=('diagnostic', 'carplay')):
    directory = Path(directory)
    expected = set(REFERENCE['runtime_files'])
    actual = {p.name for p in directory.iterdir()}
    if actual != expected | {'mode'}:
        raise ValueError('Unexpected or missing installed files.')
    for name, digest in REFERENCE['runtime_files'].items():
        p = directory / name
        if p.is_symlink() or not p.is_file() or sha(p.read_bytes()) != digest:
            raise ValueError('Installed file differs from V8: ' + name)
    mode = directory / 'mode'
    if mode.is_symlink() or mode.read_bytes().strip() not in [s.encode() for s in allowed_modes]:
        raise ValueError('Unexpected operating mode.')

def activate(path, port=5037, resume=False):
    d, data = profile(path)
    c = adb_command(port)
    folder = d / ('usb-activation-' + datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
    folder.mkdir(mode=0o700)
    report = {'actual_root_boot_verified': False, 'runtime_installed': False,
              'runtime_bytes_pulled_and_verified': False, 'vehicle_mode_enabled': False,
              'resume_requested': bool(resume), 'wifi_used': False, 'vehicle_tested': False}

    def shell(command, name, marker):
        r = subprocess.run(c + ['shell', command], capture_output=True, text=True, timeout=30)
        (folder / name).write_text(r.stdout + r.stderr)
        if r.returncode or marker not in r.stdout.splitlines():
            raise ValueError('USB step failed: ' + name)
        return r.stdout

    def pull_runtime(name):
        destination = folder / name
        subprocess.run(c + ['pull', Z, str(destination)], capture_output=True, timeout=60, check=True)
        verify_runtime_copy(destination)

    try:
        out = shell('id; sha256sum /dev/mtd3 /sbin/ly_boot.sh; echo V8_BOOT_READ', 'boot.txt', 'V8_BOOT_READ')
        verify_boot(out)
        report['actual_root_boot_verified'] = True
        subprocess.run(c + ['pull', '/dev/mtd9', str(folder / 'udisk-before.bin')], capture_output=True, timeout=60, check=True)
        if (folder / 'udisk-before.bin').stat().st_size != 524288:
            raise ValueError('Device data backup incomplete.')
        report['udisk_snapshot_sha256'] = sha((folder / 'udisk-before.bin').read_bytes())
        expected_marker = 'RUNTIME_ALREADY_EXISTS' if resume else 'RUNTIME_ABSENT'
        existing = shell('if [ -e ' + Z + ' ]; then echo RUNTIME_ALREADY_EXISTS; else echo RUNTIME_ABSENT; fi', 'existing.txt', expected_marker)
        if 'RUNTIME_ALREADY_EXISTS' in existing.splitlines():
            if not resume:
                raise ValueError('Existing installed files found. Nothing replaced.')
            pull_runtime('runtime-before-resume')
        else:
            if resume:
                raise ValueError('No V8 files found for continuation.')
            free = shell('df -k /mnt/UDISK; echo V8_SPACE_READ', 'space.txt', 'V8_SPACE_READ')
            rows = [line.split() for line in free.splitlines() if '/mnt/UDISK' in line]
            needed = sum(p.stat().st_size for p in (d / 'runtime').iterdir()) + 65536
            if len(rows) != 1 or len(rows[0]) < 4 or not rows[0][3].isdigit() or int(rows[0][3]) * 1024 < needed:
                raise ValueError('Insufficient free device space. No upload.')
            stage = Z + '-stage-' + datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')
            report['stage'] = stage
            subprocess.run(c + ['push', str(d / 'runtime'), stage], capture_output=True, timeout=60, check=True)
            pin = REFERENCE['runtime_manifest_sha256']
            shell('cd ' + stage + ' && chmod 755 *.sh *.so && sha256sum -c SHA256SUMS && '
                  '[ "$(sha256sum SHA256SUMS | awk \'{print $1}\')" = "' + pin + '" ] && '
                  'echo diagnostic >mode && [ ! -e ' + Z + ' ] && mv ' + stage + ' ' + Z +
                  ' && sync && echo V8_RUNTIME_INSTALLED', 'runtime.txt', 'V8_RUNTIME_INSTALLED')
        report['runtime_installed'] = True
        pull_runtime('runtime-before-enable')
        report['runtime_bytes_pulled_and_verified'] = True
        shell('cd ' + Z + ' && sha256sum -c SHA256SUMS && '
              'echo carplay >mode.tmp && mv mode.tmp mode && sync && '
              '[ "$(cat mode)" = carplay ] && echo V8_CARPLAY_ENABLED', 'mode.txt', 'V8_CARPLAY_ENABLED')
        pull_runtime('runtime-final')
        if (folder / 'runtime-final/mode').read_bytes().strip() != b'carplay':
            raise ValueError('Vehicle mode not confirmed by readback.')
        report['vehicle_mode_enabled'] = True
        print('V8 BOOT AND ALL INSTALLED FILES VERIFIED.')
        print('Ready to test in the parked Audi.')
        return report
    except Exception as error:
        report['error'] = str(error)
        raise
    finally:
        (folder / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
        print('Private installation record:', folder)

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('profile'); p.add_argument('--port', type=int, default=5037)
    p.add_argument('--resume', action='store_true'); a = p.parse_args()
    activate(a.profile, a.port, a.resume)
