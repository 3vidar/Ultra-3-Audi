"""Generate V8 locally from the recipient's two matching factory backups."""
from pathlib import Path
import argparse
import io
import json
import lzma
import os
import shutil
import struct
import tempfile
from common import PROJECT, REFERENCE, START, END, sha, payload_ok, backup_pair, apply_unified
from check_squashfs_mount import check_mount_layout

def rootfs(original, replacement):
    from dissect.squashfs import SquashFS
    fs = SquashFS(io.BytesIO(original)); node = fs.get('/sbin/ly_boot.sh')
    if len(replacement) != node.size:
        raise ValueError('Exact V8 boot script must retain the original inode size.')
    entry = fs._lookup_fragment(node.header.fragment)
    _, fragment = fs._read_block(entry.start_block, entry.size)
    start = node.header.offset
    if fragment[start:start+node.size] != node.open().read():
        raise ValueError('Original fragment differs from its inode.')
    newfragment = fragment[:start] + replacement + fragment[start+node.size:]
    compressed = lzma.compress(newfragment, format=lzma.FORMAT_XZ, check=lzma.CHECK_CRC32,
        filters=[{'id': lzma.FILTER_LZMA2, 'dict_size': fs.block_size, 'preset': 6}])
    patched = bytearray(original); pos = (fs.size + 4095) & ~4095; data_at = pos
    patched[pos:pos+len(compressed)] = compressed; pos += len(compressed)
    entries = []
    for i in range(fs.sb.fragments):
        old = fs._lookup_fragment(i)
        entries.append(struct.pack('<QII', data_at if i == node.header.fragment else old.start_block,
            len(compressed) if i == node.header.fragment else old.size, old.unused))
    metadata = b''.join(entries)
    if len(metadata) >= 8192:
        raise ValueError('Unsupported fragment table size.')
    meta_at = pos
    patched[pos:pos+2+len(metadata)] = struct.pack('<H', 0x8000 | len(metadata)) + metadata
    pos += 2 + len(metadata); index_at = pos
    patched[pos:pos+8] = struct.pack('<Q', meta_at); pos += 8
    struct.pack_into('<Q', patched, 80, index_at)
    for offset in (88, 48):
        oldindex = struct.unpack_from('<Q', original, offset)[0]
        oldmeta = struct.unpack_from('<Q', original, oldindex)[0]
        stored = original[oldmeta:oldindex]; newmeta = pos
        patched[pos:pos+len(stored)] = stored; pos += len(stored)
        newindex = pos; patched[pos:pos+8] = struct.pack('<Q', newmeta); pos += 8
        struct.pack_into('<Q', patched, offset, newindex)
    if pos >= len(original) or not set(original[data_at:pos]) <= {0, 255}:
        raise ValueError('New fragment would overwrite existing firmware data.')
    struct.pack_into('<Q', patched, 40, pos)
    check_mount_layout(patched, strict_id_end=True)
    def inventory(data):
        sq = SquashFS(io.BytesIO(data)); result = {}
        def walk(n, path):
            record = (n.type, n.mode, n.uid, n.gid, n.mtime.isoformat(), n.inode_number, n.size)
            if n.is_file(): record += (sha(n.open().read()),)
            elif n.is_symlink(): record += (n.link,)
            result[path] = record
            if n.is_dir():
                for child in n.iterdir(): walk(child, path.rstrip('/') + '/' + child.name)
        walk(sq.root, '/'); return result
    before, after = inventory(original), inventory(patched)
    if before.keys() != after.keys() or len(after) != 307 or [n for n in before if before[n] != after[n]] != ['/sbin/ly_boot.sh']:
        raise ValueError('Unexpected filesystem change.')
    if sha(patched) != REFERENCE['target_root_sha256'] or sha(replacement) != REFERENCE['target_boot_script_sha256']:
        raise ValueError('Generated target differs from the tested V8 release.')
    return bytes(patched)

def prepare(a, b, destination):
    from dissect.squashfs import SquashFS
    payload_ok(); backup = backup_pair(a, b)
    destination = Path(destination).resolve()
    if destination.exists():
        raise ValueError('Output must be a new directory; existing backups are never overwritten.')
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.v8-build-', dir=destination.parent) as temporary:
        d = Path(temporary); runtime = d/'runtime'; runtime.mkdir()
        original = backup[START:END]
        sq = SquashFS(io.BytesIO(original))
        csq = SquashFS(io.BytesIO(backup[END:REFERENCE['customer_end']]))
        boot = sq.get('/sbin/ly_boot.sh').open().read().decode('utf-8')
        link = csq.get('/app/lyLink.sh').open().read().decode('utf-8')
        (runtime/'carplay.sh').write_bytes(apply_unified(boot, (PROJECT/'payload/carplay.patch').read_text(encoding='utf-8')).encode('utf-8'))
        (runtime/'lyLink-zoom.sh').write_bytes(apply_unified(link, (PROJECT/'payload/lyLink.patch').read_text(encoding='utf-8')).encode('utf-8'))
        for name in REFERENCE['runtime_files']:
            if name not in ('carplay.sh', 'lyLink-zoom.sh', 'SHA256SUMS'):
                shutil.copy2(PROJECT/'payload'/name, runtime/name)
        manifest = ''.join(sha(f.read_bytes()) + '  ' + f.name + '\n' for f in sorted(runtime.iterdir()))
        (runtime/'SHA256SUMS').write_bytes(manifest.encode('ascii'))
        for name, expected in REFERENCE['runtime_files'].items():
            if sha((runtime/name).read_bytes()) != expected:
                raise ValueError('Generated runtime differs from tested release: ' + name)
        for f in runtime.iterdir():
            if f.suffix in ('.sh', '.so'): f.chmod(0o755)
        target = rootfs(original, (PROJECT/'payload/boot-dispatcher.sh').read_bytes())
        for name, value in [('fullbackup.bin', backup), ('rootfs-original.bin', original), ('rootfs-v8.bin', target)]:
            (d/name).write_bytes(value); (d/name).chmod(0o600)
        sectors = [hex(START+i) for i in range(0, len(original), 4096) if original[i:i+4096] != target[i:i+4096]]
        data = {'schema':1, 'revision':8, 'backup_sha256':sha(backup), 'two_complete_identical_backup_files_confirmed':True,
            'factory_root_sha256':sha(original), 'target_root_sha256':sha(target),
            'runtime_manifest_sha256':sha(manifest.encode()), 'changed_factory_rootfs_sectors':sectors,
            'device_installation_performed':False, 'contains_private_backup':True}
        (d/'profile.json').write_text(json.dumps(data, indent=2)+'\n')
        os.replace(d, destination)
    return data

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('backup_a'); p.add_argument('backup_b'); p.add_argument('--output', required=True)
    args = p.parse_args()
    try:
        result = prepare(args.backup_a, args.backup_b, args.output)
        print(json.dumps(result, indent=2)); print('LOCAL_PACKAGE_READY; no USB or device write performed.')
    except (OSError, ValueError) as error:
        raise SystemExit(str(error))
