"""Full backup-bound rootfs installation and recovery over WinUSB."""
from pathlib import Path
import datetime
import json
import os
import time
from common import SIZE, START, END, REFERENCE, sha, profile, verify_flash
from usb_transport import USB, FEL_ID
from fel_windows import FEL, valid_write

def save_new(path, data):
    with Path(path).open('xb') as stream:
        stream.write(data); stream.flush(); os.fsync(stream.fileno())

def wait_ready(device, seconds):
    deadline = time.monotonic()+seconds
    while device.status_register(5) & 1:
        if time.monotonic() >= deadline:
            raise ValueError('Flash busy timeout. Keep the backups.')
        time.sleep(0.002)

def enable_write(device):
    device.write_command(b'\x06')
    if device.status_register(5) & 3 != 2:
        raise ValueError('Flash did not enable writing.')

def sector_write(device, address, target):
    if len(target) != 4096 or not valid_write(b'\x20'+address.to_bytes(3,'big')):
        raise ValueError('Invalid root filesystem sector.')
    enable_write(device)
    device.write_command(b'\x20'+address.to_bytes(3,'big')); wait_ready(device, 10)
    if device.read_range(address, 4096) != b'\xff'*4096:
        raise ValueError('Sector erase readback failed.')
    for offset in range(0,4096,256):
        page = target[offset:offset+256]
        if page == b'\xff'*256:
            continue
        enable_write(device)
        device.write_command(b'\x02'+(address+offset).to_bytes(3,'big')+page)
        wait_ready(device, 2)
    if device.read_range(address,4096) != target:
        raise ValueError('Sector readback failed at '+hex(address))

def apply_image(device, mode, backup, target, before_path, after_path, backup_sha):
    if mode not in ('install','restore') or len(backup) != SIZE or sha(backup) != backup_sha:
        raise ValueError('Owner backup binding failed.')
    from common import factory_ok
    factory_ok(backup)
    expected = REFERENCE['target_root_sha256'] if mode == 'install' else REFERENCE['factory_root_sha256']
    if len(target) != END-START or sha(target) != expected:
        raise ValueError('Target filesystem hash failed.')
    if Path(before_path).exists() or Path(after_path).exists():
        raise ValueError('Readback paths must be new files.')
    print('Reading the entire flash before writing ...', flush=True)
    before = device.read_range(0,SIZE); save_new(before_path,before)
    customer_end = REFERENCE['customer_end']
    if before[:START] != backup[:START] or before[END:customer_end] != backup[END:customer_end]:
        raise ValueError('Boot or application regions differ from this backup.')
    if mode == 'install' and sha(before) != backup_sha:
        raise ValueError('First installation requires the unchanged complete original backup.')
    device.writable()
    changed = [address for address in range(START, END, 4096) if before[address:address+4096] != target[address-START:address-START+4096]]
    ordered = [address for address in changed if address != START] + ([START] if START in changed else [])
    print('Updating '+str(len(changed))+' root filesystem sectors. Keep USB connected.', flush=True)
    for address in ordered:
        sector_write(device,address,target[address-START:address-START+4096])
        print('Written and verified: '+hex(address),flush=True)
    device.write_command(b'\x04')
    print('Reading the entire flash for final verification ...',flush=True)
    after = device.read_range(0,SIZE); save_new(after_path,after)
    sectors = verify_flash(before,after,target)
    print('FULL FLASH READBACK VERIFIED.',flush=True)
    return {'mode':mode,'flash_verified':True,'changed_sectors':sectors,'before_sha256':sha(before),'after_sha256':sha(after)}

def flash(path, restore=False):
    directory,data = profile(path)
    folder = directory/(('restore-' if restore else 'install-')+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
    folder.mkdir()
    mode = 'restore' if restore else 'install'
    report = {'mode':mode,'flash_verified':False,'real_boot_verified':False}
    target = (directory/('rootfs-original.bin' if restore else 'rootfs-v8.bin')).read_bytes()
    try:
        with USB(FEL_ID) as usb:
            device = FEL(usb); device.probe()
            report.update(apply_image(device,mode,(directory/'fullbackup.bin').read_bytes(),target,folder/'before.bin',folder/'after.bin',data['backup_sha256']))
    except BaseException as error:
        report['error'] = type(error).__name__+': '+str(error)
        raise
    finally:
        (folder/'result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
        print('Private readback record:',folder)
