/* Fixed-device rootfs-only writer. Includes the already verified read transport.
 * No chip erase, status-register write, unlock, bootloader, eFuse or JTAG commands.
 */
#define main backup_reader_main
#include "fel/reader.c"
#undef main
#include <CommonCrypto/CommonDigest.h>
#include <time.h>
#include <unistd.h>

#define ROOT_START 0x680000u
#define ROOT_BYTES 0x480000u
#define ROOT_END (ROOT_START + ROOT_BYTES)
#define SECTOR 4096u
#define PAGE 256u
#ifndef BACKUP_SHA
#error BACKUP_SHA must come from the owner-specific verified backup profile
#endif
#ifndef ORIGINAL_ROOT_SHA
#error ORIGINAL_ROOT_SHA must come from the verified own original rootfs
#endif
#ifndef PATCHED_ROOT_SHA
#error PATCHED_ROOT_SHA must be supplied from the verified image report
#endif

static int digest_is(const uint8_t *b, uint32_t n, const char *expected) {
    uint8_t hash[CC_SHA256_DIGEST_LENGTH]; char encoded[65];
    CC_SHA256(b, n, hash);
    for(unsigned i=0; i<32; i++) snprintf(encoded + 2*i, 3, "%02x", hash[i]);
    return !strcmp(encoded, expected);
}

static uint8_t *load_exact(const char *p, uint32_t bytes, const char *expected) {
    FILE *f=fopen(p,"rb"); if(!f) { perror("Quelldatei"); return NULL; }
    uint8_t *b=malloc(bytes); if(!b) { fclose(f); return NULL; }
    int ok=fread(b,1,bytes,f)==bytes && fgetc(f)==EOF && !ferror(f);
    fclose(f);
    if(!ok || !digest_is(b,bytes,expected)) {
        fprintf(stderr,"ERROR: Quelldatei oder SHA-256 stimmt nicht.\n"); free(b); return NULL;
    }
    return b;
}

static int read_range(struct reader *r,uint32_t at,uint8_t *b,uint32_t n) {
    if(at > FLASH_BYTES || n > FLASH_BYTES-at) return 0;
    for(uint32_t off=0;off<n;) {
        uint32_t count=n-off; if(count>65536) count=65536;
        uint32_t a=at+off;
        uint8_t cmd[]={3,(uint8_t)(a>>16),(uint8_t)(a>>8),(uint8_t)a};
        if(!transfer(r,cmd,4,b+off,count)) return 0;
        off+=count;
    }
    return 1;
}

static int save_new(const char *p,const uint8_t *b,uint32_t n) {
    int fd=open(p,O_WRONLY|O_CREAT|O_EXCL,0600); if(fd<0) { perror("Protokolldatei"); return 0; }
    uint32_t done=0;
    while(done<n) {
        ssize_t k=write(fd,b+done,n-done);
        if(k<0 && errno==EINTR) continue;
        if(k<=0) { close(fd); return 0; } done+=(uint32_t)k;
    }
    int synced=fsync(fd); int closed=close(fd); return !synced && !closed;
}

/* Flash mutations have a separate narrow gate, with fixed address bounds. */
static int write_command_valid(const uint8_t *cmd,uint32_t n) {
    if(n==1) return cmd[0]==6 || cmd[0]==4;
    if(n<4) return 0;
    uint32_t at=((uint32_t)cmd[1]<<16)|((uint32_t)cmd[2]<<8)|cmd[3];
    if(at<ROOT_START || at>=ROOT_END) return 0;
    if(cmd[0]==0x20) return n==4 && at%SECTOR==0 && ROOT_END-at>=SECTOR;
    if(cmd[0]==2) return n>4 && n<=PAGE+4 && at%PAGE==0 && ROOT_END-at>=n-4;
    return 0;
}

static int send_write(struct reader *r,uint8_t *cmd,uint32_t n) {
    if(!write_command_valid(cmd,n)) { fprintf(stderr,"ERROR: Schreibbereich gesperrt.\n"); return 0; }
    return fel_spi_xfer(&r->ctx,r->swapbuf,r->swaplen,r->cmdlen,cmd,n,NULL,0);
}

static int read_sr(struct reader *r,uint8_t cmd,uint8_t *value) {
    if(cmd!=5 && cmd!=0x35 && cmd!=0x15) return 0;
    return fel_spi_xfer(&r->ctx,r->swapbuf,r->swaplen,r->cmdlen,&cmd,1,value,1);
}

static int writable(struct reader *r) {
    uint8_t id[3],cmd=0x9f,sr1,sr2,sr3,first[4],header[8],ph[8];
    if(!transfer(r,&cmd,1,id,3) || memcmp(id,"\x0b\x40\x18",3) ||
       !read_sr(r,5,&sr1) || !read_sr(r,0x35,&sr2) || !read_sr(r,0x15,&sr3) ||
       (sr1&0xfd) || (sr2&0x40) || (sr3&4) || !sfdp_read(r,0,header,8)) {
        fprintf(stderr,"ERROR: Flash beschäftigt, geschützt oder falsches Gerät. Schutz wird nicht geändert.\n");
        return 0;
    }
    int found=0;
    for(unsigned i=0;i<=header[6];i++) {
        if(!sfdp_read(r,8+i*8,ph,8)) return 0;
        if(ph[0]==0 && ph[7]==255 && ph[2]==1 && ph[3]>=2) {
            uint32_t at=(uint32_t)ph[4]|((uint32_t)ph[5]<<8)|((uint32_t)ph[6]<<16);
            if(!sfdp_read(r,at,first,4)) return 0;
            found=1; break;
        }
    }
    /* BFPT DWORD 1 declares 4KiB erase support and its opcode, which must be 20H. */
    if(!found || !(first[0]&1) || first[1]!=0x20) {
        fprintf(stderr,"ERROR: 4-KiB-Löschbefehl nicht bestätigt.\n"); return 0;
    }
    fprintf(stderr,"Schutzprüfung: SR1=%02x SR2=%02x SR3=%02x; unverändert.\n",sr1,sr2,sr3);
    return 1;
}

static int wait_ready(struct reader *r,double seconds) {
    struct timespec begin,now; clock_gettime(CLOCK_MONOTONIC,&begin);
    for(;;) {
        uint8_t s; if(!read_sr(r,5,&s)) return 0;
        if(!(s&1)) return 1;
        clock_gettime(CLOCK_MONOTONIC,&now);
        double elapsed=now.tv_sec-begin.tv_sec+(now.tv_nsec-begin.tv_nsec)/1e9;
        if(elapsed>seconds) { fprintf(stderr,"ERROR: Flash bleibt beschäftigt.\n"); return 0; }
        usleep(2000);
    }
}

static int enable_write(struct reader *r) {
    uint8_t cmd=6,s;
    return send_write(r,&cmd,1) && read_sr(r,5,&s) && (s&3)==2;
}

static int sector_write(struct reader *r,uint32_t at,const uint8_t *target) {
    uint8_t erase[]={0x20,(uint8_t)(at>>16),(uint8_t)(at>>8),(uint8_t)at};
    if(!enable_write(r) || !send_write(r,erase,4) || !wait_ready(r,10)) return 0;
    uint8_t verify[SECTOR];
    if(!read_range(r,at,verify,SECTOR)) return 0;
    for(unsigned j=0;j<SECTOR;j++) if(verify[j]!=255) {
        fprintf(stderr,"ERROR: Löschung nicht bestätigt bei 0x%06x.\n",at+j); return 0;
    }
    for(unsigned off=0;off<SECTOR;off+=PAGE) {
        unsigned j=0; while(j<PAGE && target[off+j]==255) j++;
        if(j==PAGE) continue;
        uint32_t addr=at+off;
        uint8_t cmd[PAGE+4]={2,(uint8_t)(addr>>16),(uint8_t)(addr>>8),(uint8_t)addr};
        memcpy(cmd+4,target+off,PAGE);
        if(!enable_write(r) || !send_write(r,cmd,sizeof(cmd)) || !wait_ready(r,2)) return 0;
    }
    if(!read_range(r,at,verify,SECTOR) || memcmp(verify,target,SECTOR)) {
        fprintf(stderr,"ERROR: Rücklesen stimmt nicht bei 0x%06x.\n",at); return 0;
    }
    return 1;
}

/* mode: 0 restore own original rootfs, 1 exact factory installation. */
static int apply_image(struct reader *r,int mode,const uint8_t *backup,const uint8_t *patch,
                       const char *before_path,const char *after_path) {
    uint8_t *before=malloc(FLASH_BYTES),*after=malloc(FLASH_BYTES); int ok=0;
    if(!before || !after) goto done;
    if(access(after_path,F_OK)==0) { fprintf(stderr,"ERROR: Ergebnisdatei existiert bereits.\n"); goto done; }
    fprintf(stderr,"Lese vor dem Schreiben den gesamten Flash …\n");
    if(!read_range(r,0,before,FLASH_BYTES) || !save_new(before_path,before,FLASH_BYTES)) goto done;
    /* Boot images and CarPlay application must still match this exact backup.
       Mutable environment and JFFS2 may change after a normal diagnostic boot. */
    if(memcmp(before,backup,ROOT_START) || memcmp(before+ROOT_END,backup+ROOT_END,0xea0000-ROOT_END)) {
        fprintf(stderr,"ERROR: Boot-/Anwendungsdaten passen nicht zu dieser Sicherung.\n"); goto done;
    }
    if(mode==1 && !digest_is(before,FLASH_BYTES,BACKUP_SHA)) {
        fprintf(stderr,"ERROR: Installation verlangt den unveränderten vollständigen Sicherungsstand.\n"); goto done;
    }
    if(mode<0 || mode>1) goto done;
    if(!writable(r)) goto done;
    const uint8_t *target=mode?patch:backup+ROOT_START;
    unsigned changed=0;
    for(unsigned i=0;i<ROOT_BYTES;i+=SECTOR) if(memcmp(before+ROOT_START+i,target+i,SECTOR)) changed++;
    fprintf(stderr,"Ändere %u Sektoren ausschließlich im Root-Dateisystem; Startblock zuletzt.\n",changed);
    /* Data and the fragment table first. Superblock switch last. */
    for(unsigned i=SECTOR;i<ROOT_BYTES;i+=SECTOR) {
        if(!memcmp(before+ROOT_START+i,target+i,SECTOR)) continue;
        if(!sector_write(r,ROOT_START+i,target+i)) goto done;
        fprintf(stderr,"Sektor 0x%06x geschrieben und geprüft.\n",ROOT_START+i);
    }
    if(memcmp(before+ROOT_START,target,SECTOR) && !sector_write(r,ROOT_START,target)) goto done;
    uint8_t disable=4; if(!send_write(r,&disable,1)) goto done;
    fprintf(stderr,"Lese den gesamten Flash zur Abschlussprüfung …\n");
    if(!read_range(r,0,after,FLASH_BYTES) || !save_new(after_path,after,FLASH_BYTES)) goto done;
    if(memcmp(after+ROOT_START,target,ROOT_BYTES) || memcmp(before,after,ROOT_START) ||
       memcmp(before+ROOT_END,after+ROOT_END,FLASH_BYTES-ROOT_END)) {
        fprintf(stderr,"ERROR: Abschlussprüfung nicht bestanden.\n"); goto done;
    }
    printf("PATCH_OK mode=%s sectors=%u outside_rootfs_unchanged=true\n",mode==1?"install":"restore",changed);
    ok=1;
done: free(before); free(after); return ok;
}

#ifndef ROOTFS_TEST
int main(int argc,char **argv) {
    if(argc!=6 || (strcmp(argv[1],"install") && strcmp(argv[1],"restore"))) {
        fprintf(stderr,"V821-Rootfs-Werkzeug: install|restore <eigenes Original-Vollbackup> <geprüftes V8-Rootfs> <neue-Vorher.bin> <neue-Nachher.bin>\n");
        return 2;
    }
    uint8_t *backup=load_exact(argv[2],FLASH_BYTES,BACKUP_SHA);
    uint8_t *patch=load_exact(argv[3],ROOT_BYTES,PATCHED_ROOT_SHA);
    if(!backup || !patch) { free(backup); free(patch); return 1; }
    if(!digest_is(backup+ROOT_START,ROOT_BYTES,ORIGINAL_ROOT_SHA)) { free(backup); free(patch); return 1; }
    struct reader r={0}; libusb_context *context=NULL; libusb_device **list=NULL;
    int result=1;
    if(libusb_init(&context)) goto cleanup;
    ssize_t count=libusb_get_device_list(context,&list); libusb_device *device=NULL; unsigned matches=0;
    for(ssize_t i=0;i<count;i++) {
        struct libusb_device_descriptor d;
        if(!libusb_get_device_descriptor(list[i],&d) && d.idVendor==0x1f3a && d.idProduct==0xefe8) {
            device=list[i]; matches++;
        }
    }
    if(matches!=1 || libusb_open(device,&r.ctx.hdl) || !fel_init(&r.ctx) ||
       r.ctx.version.id!=0x00188200 || memcmp(r.ctx.version.magic,"AWUSBFEX",8)) {
        fprintf(stderr,"ERROR: Genau ein V821 im USB-FEL-Modus erforderlich.\n"); goto cleanup;
    }
    int mode=!strcmp(argv[1],"install")?1:0;
    if(probe(&r) && apply_image(&r,mode,backup,patch,argv[4],argv[5])) result=0;
cleanup:
    if(r.ctx.hdl) { libusb_release_interface(r.ctx.hdl,0); libusb_close(r.ctx.hdl); }
    if(list) libusb_free_device_list(list,1);
    if(context) libusb_exit(context);
    free(backup); free(patch); return result;
}
#endif
