"""Audi Version 8 macOS Build Test installer."""
from pathlib import Path
import argparse
import datetime
import importlib.metadata
import json
import os
import platform
import secrets
import re
import socket
import shutil
import struct
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from common import SIZE, sha, backup_pair, profile
from integrity import verify_release
from prepare import prepare
from flash import flash
from build_host import build, find_libusb
from activate import activate, adb_command, verify_boot, valid_port

PRIVATE=ROOT/'private'

def confirm(word,message):
    print(message,flush=True)
    if input('Type '+word+' to continue: ').strip()!=word:
        raise ValueError('Cancelled before the next operation.')

def preflight():
    if platform.system()!='Darwin':raise ValueError('This installer requires macOS.')
    if sys.version_info<(3,10):raise ValueError('Python 3.10 or newer is required.')
    for line in (ROOT/'requirements.txt').read_text(encoding='ascii').splitlines():
        name,wanted=line.split('==')
        if importlib.metadata.version(name)!=wanted:raise ValueError('Run Start-Mac.command to set up the required packages.')
    if not shutil.which('adb'):raise ValueError('Install Android Platform Tools.')
    subprocess.run(['/usr/bin/xcrun','--find','clang'],capture_output=True,check=True)
    find_libusb()
    if '--one-device' not in subprocess.run(['adb','help'],capture_output=True,text=True,check=True).stdout:
        raise ValueError('Update Android Platform Tools.')
    if PRIVATE.is_symlink():raise ValueError('The private folder must not be a link.')
    PRIVATE.mkdir(mode=0o700,exist_ok=True);PRIVATE.chmod(0o700)
    if shutil.disk_usage(PRIVATE).free<512*1024*1024:raise ValueError('At least 512 MiB free space is required.')

_reader_path=None
def host_reader():
    global _reader_path
    if _reader_path is None:
        output=PRIVATE/'host-tools';build(output=output);_reader_path=output/'flash-reader'
    return _reader_path

def run_reader(path,*args,timeout=30):
    result=subprocess.run([str(path),*map(str,args)],capture_output=True,text=True,timeout=timeout)
    if result.returncode:raise ValueError('FEL access failed: '+(result.stderr.strip() or result.stdout.strip()))
    return result.stdout

def reader(action,destination=None):
    args=[action] if destination is None else [action,str(destination)]
    return run_reader(host_reader(),*args,timeout=240 if action=='read' else 30)

def check_fel():
    version=reader('version')
    if 'ID=0x00188200(V821)' not in version:
        raise ValueError('Unexpected processor.')
    result=json.loads(reader('probe'))
    if result.get('chip')!='V821' or result.get('jedec')!='0b4018' or result.get('bytes')!=SIZE or result.get('flash_write_commands') is not False:
        raise ValueError('Unexpected flash device.')
    print('FEL CONNECTION VERIFIED.',flush=True)
    return result

def wait_fel():
    preflight()
    print('Waiting for FEL. Remove the contact bridge within five seconds in all cases.',flush=True)
    deadline=time.monotonic()+90
    while time.monotonic()<deadline:
        try:
            reader('version')
        except Exception:
            time.sleep(1);continue
        print('FEL DETECTED. Remove every contact bridge now. Leave USB connected.',flush=True)
        input('Press Enter only after removing the bridge: ')
        return check_fel()
    raise ValueError('FEL not detected. Remove any bridge. Set up WinUSB as described in the guide.')

def save_state(directory,phase,**data):
    path=Path(directory)/'state.json'
    value=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
    value.setdefault('history',[]).append({'phase':phase,'at':datetime.datetime.now().isoformat(timespec='seconds')})
    value.update(phase=phase,**data)
    temp=path.with_name('state.json.tmp')
    temp.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8');temp.replace(path)

class USBSession:
    """Reuse an existing local service, otherwise own one isolated process only."""
    def __init__(self, directory, port=None):
        self.directory = Path(directory); self.requested_port = port
        self.port = None; self.process = None; self.log = None

    def root(self, port):
        try:
            r = subprocess.run(adb_command(port) + ['shell', 'id'], capture_output=True, text=True, timeout=4)
            return r.returncode == 0 and bool(re.search(r'\buid=0\(root\)', r.stdout))
        except (OSError, subprocess.TimeoutExpired):
            return False

    def __enter__(self):
        if self.requested_port is not None:
            self.port = valid_port(self.requested_port)
        else:
            for port in (5037, 5039):
                if self.root(port):
                    self.port = port
                    print('Using existing local USB service:', port)
                    return self
            with socket.socket() as s:
                s.settimeout(1)
                occupied = s.connect_ex(('127.0.0.1', 5039)) == 0
            self.port = 5039
            if not occupied:
                env = dict(os.environ, ADB_LIBUSB='1', ADB_MDNS_AUTO_CONNECT='0')
                env.pop('ADB_SERVER_SOCKET', None)
                self.log = (self.directory / ('usb-service-' + secrets.token_hex(4) + '.txt')).open('w')
                self.process = subprocess.Popen([shutil.which('adb'), '-L', 'tcp:127.0.0.1:5039', '--one-device', 'V821-Audi-USB', 'server', 'nodaemon'], env=env, stdout=self.log, stderr=subprocess.STDOUT)
                print('Started the installer USB service on this Mac (port 5039).')
            else:
                print('Port 5039 is occupied; no other service will be stopped.')
        print('Waiting for USB root. Reconnect normally without a bridge if needed.', flush=True)
        try:
            deadline = time.monotonic() + 90
            while time.monotonic() < deadline:
                if self.root(self.port):
                    return self
                if self.process and self.process.poll() is not None:
                    raise ValueError('Installer USB service ended. Check the USB connection. Other services were not stopped.')
                time.sleep(2)
            raise ValueError('USB root not confirmed. Reconnect and select 3 to continue. Keep all backups.')
        except BaseException:
            self.__exit__(None, None, None)
            raise

    def __exit__(self, *args):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=4)
            except subprocess.TimeoutExpired:
                self.process.kill(); self.process.wait(timeout=4)
        if self.log:
            self.log.close()

def activate_remaining(path):
    directory,data=profile(path)
    with USBSession(directory) as usb:
        command=adb_command(usb.port)
        result=subprocess.run(command+['shell','id; sha256sum /dev/mtd3 /sbin/ly_boot.sh'],capture_output=True,text=True,timeout=30,check=True)
        verify_boot(result.stdout,data['expected'])
        result=subprocess.run(command+['shell','if [ -e /mnt/UDISK/audi-zoom6238 ]; then echo EXISTS; else echo ABSENT; fi'],capture_output=True,text=True,timeout=10,check=True)
        if result.stdout.strip() not in ('EXISTS','ABSENT'):raise ValueError('Runtime state is ambiguous.')
        return activate(path,usb.port,resume=result.stdout.strip()=='EXISTS')

def install():
    preflight()
    confirm('ULTRA3','V8 BUILD TEST. Build number is not checked. Connect the ly6238 Mini Ultra 3 in FEL mode. Remove every contact bridge.')
    device=check_fel()
    directory=PRIVATE/('device-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(3))
    backups=directory/'backups';backups.mkdir(parents=True)
    save_state(directory,'reading_original',device_probe=device)
    try:
        for name in ('a','b'):
            print('Reading full backup '+name.upper()+'. Keep USB connected.',flush=True)
            reader('read',backups/('original-'+name+'.bin'))
        original=backup_pair(backups/'original-a.bin',backups/'original-b.bin')
        save_state(directory,'original_backups_verified',backup_sha256=sha(original))
        print('BOTH ORIGINAL BACKUPS VERIFIED.',flush=True)
        prepare(backups/'original-a.bin',backups/'original-b.bin',directory/'device-v8')
        path=directory/'device-v8/profile.json'
        build(profile_path=path)
        save_state(directory,'ready_to_flash',profile='device-v8/profile.json')
        print('Keep this backup folder:',directory)
        confirm('INSTALL','Ready to install Version 8 Build Test from your own backup. The target build is not vehicle-tested. Keep USB connected during writing and readback.')
        save_state(directory,'flashing_rootfs');flash(path)
        save_state(directory,'rootfs_readback_verified')
        input('Unplug and reconnect normally, without any bridge. Then press Enter: ')
        result=activate_remaining(path)
        save_state(directory,'ready_for_vehicle_test',actual_root_boot_verified=result['actual_root_boot_verified'],vehicle_mode_enabled=result['vehicle_mode_enabled'])
        print('V8 BUILD TEST INSTALLED; BYTES AND BOOT VERIFIED. You may unplug the dongle and test in the parked Audi.')
    except BaseException as error:
        save_state(directory,'stopped',error=type(error).__name__+': '+str(error))
        print('Installation stopped. Keep this backup folder:',directory)
        raise

def choose_profile():
    files=sorted(PRIVATE.glob('device-*/device-v8/profile.json'))
    if not files:
        raise ValueError('No original backup found in this installer folder.')
    for number,path in enumerate(files,1):
        print(str(number)+': '+str(path.relative_to(ROOT)))
    value=input('Select your backup number: ').strip()
    if not value.isdigit() or not 1<=int(value)<=len(files):
        raise ValueError('No backup selected.')
    return files[int(value)-1]

def restore(path):
    preflight();directory,data=profile(path)
    confirm('RESTORE','Restore your own original root filesystem. Keep USB connected.')
    try:check_fel()
    except ValueError:
        with USBSession(directory) as usb:
            command=adb_command(usb.port)
            result=subprocess.run(command+['shell','id; sha256sum /dev/mtd3 /sbin/ly_boot.sh'],capture_output=True,text=True,timeout=30,check=True)
            verify_boot(result.stdout,data['expected'])
            try:
                subprocess.run(command+['shell','sync; if echo 1 >/sys/class/misc/ly_misc_dev/ly/ly_efex; then sync; reboot -f; else echo V8_FEL_FAILED; exit 1; fi'],capture_output=True,text=True,timeout=15)
            except subprocess.TimeoutExpired:pass
        for _ in range(30):
            try:check_fel();break
            except ValueError:time.sleep(1)
        else:raise ValueError('FEL restart not confirmed. No recovery data written.')
    build(profile_path=path)
    flash(path,restore=True)
    print('ORIGINAL ROOT FILESYSTEM RESTORED AND VERIFIED. Reconnect normally and test original CarPlay.')

def menu():
    while True:
        print('\nAudi Version 8 Build Test - macOS\n1: Check FEL connection\n2: Back up and install V8 Build Test\n3: Continue installation after reconnecting\n4: Restore your original firmware filesystem\n5: Verify installer files\n6: Wait for FEL connection\n0: Exit')
        choice=input('Select: ').strip()
        if choice=='0':
            return
        try:
            if choice=='5':
                print('INSTALLER FILES VERIFIED:',verify_release());continue
            preflight()
            if choice=='1':check_fel()
            elif choice=='2':install()
            elif choice=='3':
                result=activate_remaining(choose_profile())
                if result['vehicle_mode_enabled']:print('V8 BUILD TEST INSTALLED; BYTES AND BOOT VERIFIED. You may unplug the dongle.')
            elif choice=='4':restore(choose_profile())
            elif choice=='6':wait_fel()
            else:raise ValueError('Select a listed number.')
        except Exception as error:
            print('STOPPED:',error,flush=True)
            print('Keep the installer folder and all backups. Use 3 to continue after driver setup, or 4 to restore.')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify-release',action='store_true')
    options=parser.parse_args()
    verify_release()
    if options.verify_release:
        print('INSTALLER FILES VERIFIED. No device accessed.');return
    menu()

if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('Stopped. Keep all backups.');raise SystemExit(130)
    except Exception as error:print('STOPPED:',error,file=sys.stderr);raise SystemExit(1)
