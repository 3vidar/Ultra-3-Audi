#define ROOTFS_TEST
#define fel_spi_xfer mock_spi_xfer
#include "../src/rootfs_writer.c"
#undef fel_spi_xfer
#include <assert.h>

static uint8_t device_bytes[FLASH_BYTES];
static unsigned wel, erase_count, last_erased;
static uint8_t protection1, protection2, protection3;
static int corrupt_program;

int mock_spi_xfer(struct xfel_ctx_t *ctx,uint32_t sb,uint32_t sl,uint32_t cl,
                  void *transmit,uint32_t n,void *receive,uint32_t rn) {
    uint8_t *tx=transmit,*rx=receive;
    uint32_t at=n>=4?((uint32_t)tx[1]<<16)|((uint32_t)tx[2]<<8)|tx[3]:0;
    switch(tx[0]) {
    case 0x9f: assert(n==1&&rn==3); memcpy(rx,"\x0b\x40\x18",3); return 1;
    case 5: assert(n==1&&rn==1); rx[0]=(wel?2:0)|protection1; return 1;
    case 0x35: rx[0]=protection2; return 1;
    case 0x15: rx[0]=protection3; return 1;
    case 0x5a:
        if(at==0 && rn==8) memcpy(rx,"SFDP\x06\x01\x00\xff",8);
        else if(at==8 && rn==8) memcpy(rx,"\x00\x06\x01\x10\x40\x00\x00\xff",8);
        else if(at==0x40 && rn==4) memcpy(rx,"\xe5\x20\xf9\xff",4);
        else assert(0);
        return 1;
    case 3: assert(n==4&&rn&&at+rn<=FLASH_BYTES); memcpy(rx,device_bytes+at,rn); return 1;
    case 6: assert(n==1&&!rn); wel=1; return 1;
    case 4: assert(n==1&&!rn); wel=0; return 1;
    case 0x20:
        assert(wel&&n==4&&!rn&&at>=ROOT_START&&at+SECTOR<=ROOT_END&&!(at%SECTOR));
        memset(device_bytes+at,255,SECTOR); wel=0; erase_count++; last_erased=at; return 1;
    case 2:
        assert(wel&&n==260&&!rn&&at>=ROOT_START&&at+256<=ROOT_END&&!(at%PAGE));
        for(unsigned i=0;i<256;i++) device_bytes[at+i]&=tx[4+i];
        if(corrupt_program) { device_bytes[at]=tx[4]^1; corrupt_program=0; }
        wel=0; return 1;
    default: assert(0); return 0;
    }
}

static void reset_device(const uint8_t *backup) {
    memcpy(device_bytes,backup,FLASH_BYTES);
    wel=erase_count=last_erased=protection1=protection2=protection3=corrupt_program=0;
}

static unsigned differences(const uint8_t*a,const uint8_t*b) {
 unsigned n=0;for(unsigned i=0;i<ROOT_BYTES;i+=SECTOR)if(memcmp(a+i,b+i,SECTOR))n++;return n;
}
static unsigned last_mutation(const uint8_t*a,const uint8_t*b) {
 if(memcmp(a,b,SECTOR))return ROOT_START;
 unsigned last=0;for(unsigned i=SECTOR;i<ROOT_BYTES;i+=SECTOR)if(memcmp(a+i,b+i,SECTOR))last=ROOT_START+i;return last;
}

int main(int argc,char **argv) {
    assert(argc==4);
    uint8_t *original=load_exact(argv[1],FLASH_BYTES,BACKUP_SHA);
    uint8_t *patch=load_exact(argv[2],ROOT_BYTES,PATCHED_ROOT_SHA);
    assert(original&&patch);
    unsigned original_diff=differences(original+ROOT_START,patch);
    assert(original_diff);
    char before[1024],after[1024]; struct reader r={.swaplen=65536};
    #define PATHS(name) snprintf(before,sizeof(before),"%s/%s-before.bin",argv[3],name); \
                        snprintf(after,sizeof(after),"%s/%s-after.bin",argv[3],name)

    reset_device(original); PATHS("install");
    assert(apply_image(&r,1,original,patch,before,after));
    assert(erase_count==original_diff && last_erased==last_mutation(original+ROOT_START,patch));
    assert(!memcmp(device_bytes+ROOT_START,patch,ROOT_BYTES));
    assert(!memcmp(device_bytes,original,ROOT_START));
    assert(!memcmp(device_bytes+ROOT_END,original+ROOT_END,FLASH_BYTES-ROOT_END));
    printf("PASS exact installation; %u sectors derived from images; superblock last when changed; other regions unchanged\n",original_diff);

    device_bytes[0xf90000]^=1; uint8_t user_byte=device_bytes[0xf90000];
    erase_count=last_erased=0; PATHS("restore");
    assert(apply_image(&r,0,original,patch,before,after));
    assert(erase_count==original_diff&&last_erased==last_mutation(patch,original+ROOT_START));
    assert(!memcmp(device_bytes+ROOT_START,original+ROOT_START,ROOT_BYTES));
    assert(device_bytes[0xf90000]==user_byte);
    puts("PASS restoration preserves changed user-data outside rootfs");

    reset_device(original); device_bytes[0xf90000]^=1; PATHS("mismatch");
    assert(!apply_image(&r,1,original,patch,before,after)); assert(!erase_count&&!wel);
    puts("PASS install rejects a changed complete backup before write enable");

    reset_device(original); device_bytes[0x60000]^=1; PATHS("boot-mismatch");
    assert(!apply_image(&r,0,original,patch,before,after)); assert(!erase_count&&!wel);
    puts("PASS restoration rejects changed boot/application identity");

    reset_device(original); corrupt_program=1; PATHS("corrupt");
    assert(!apply_image(&r,1,original,patch,before,after));
    assert(erase_count==1 && last_erased!=ROOT_START);
    assert(!memcmp(device_bytes+ROOT_START,original+ROOT_START,SECTOR));
    puts("PASS readback error stops before switching the superblock");
    erase_count=last_erased=0; PATHS("partial-restore");
    assert(apply_image(&r,0,original,patch,before,after));
    assert(!memcmp(device_bytes,original,FLASH_BYTES));
    puts("PASS recovery from a partially written fragment");

    reset_device(original); protection1=4; assert(!writable(&r));
    protection1=0; protection2=64; assert(!writable(&r));
    protection2=0; protection3=4; assert(!writable(&r));
    assert(!erase_count&&!wel);
    puts("PASS BP/CMP/WPS protection rejected without protection changes");

    uint8_t cmd[260]={0xc7}; assert(!write_command_valid(cmd,1));
    cmd[0]=1; assert(!write_command_valid(cmd,1));
    cmd[0]=0x20;cmd[1]=0x60; assert(!write_command_valid(cmd,4));
    cmd[1]=0xb0; assert(!write_command_valid(cmd,4));
    cmd[1]=0x68;cmd[3]=1; assert(!write_command_valid(cmd,4));
    cmd[0]=2; assert(!write_command_valid(cmd,260));
    cmd[3]=0; assert(write_command_valid(cmd,260));
    assert(!write_command_valid(cmd,261));
    cmd[1]=0xaf;cmd[2]=0xff;cmd[3]=0; assert(write_command_valid(cmd,260));
    puts("PASS chip erase/status write/range/alignment/page guards");
    reset_device(original); device_bytes[ROOT_START+100]^=1; PATHS("wrong-root");
    assert(!apply_image(&r,1,original,patch,before,after)); assert(!erase_count&&!wel);
    puts("PASS installation rejects an unknown rootfs before write enable");

    reset_device(original); device_bytes[ROOT_END+100]^=1; PATHS("wrong-customer");
    assert(!apply_image(&r,0,original,patch,before,after)); assert(!erase_count&&!wel);
    puts("PASS restoration rejects a different application partition");

    reset_device(original); PATHS("restore-original");
    assert(apply_image(&r,0,original,patch,before,after)); assert(!erase_count);
    assert(!memcmp(device_bytes,original,FLASH_BYTES));
    puts("PASS already original restoration writes no sectors");

    reset_device(original); PATHS("existing-output");
    assert(save_new(after,original,FLASH_BYTES));
    assert(!apply_image(&r,1,original,patch,before,after)); assert(!erase_count&&!wel);
    puts("PASS existing output file rejected before any flash mutation");
    free(original);free(patch);return 0;
}
