from pathlib import Path
import json
import os
import sys
import tempfile
import unittest
from unittest.mock import patch
import subprocess

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
sys.path.insert(0, str(ROOT))
import common
import activate
import check_vendor
import installer
import build_host
import export_report

class AdditionalGuards(unittest.TestCase):
    def test_private_http_endpoint_is_fixed(self):
        self.assertEqual(check_vendor.endpoint('http://192.168.50.100'), 'http://192.168.50.100/cgi-bin/index.cgi?id=host')

    def test_unsafe_addresses_rejected(self):
        for url in ('https://192.168.50.100', 'http://example.com', 'http://127.0.0.1', 'http://169.254.1.1', 'http://8.8.8.8',
                    'http://192.168.50.100:8080', 'http://u:p@192.168.50.100', 'http://192.168.50.100/?id=set',
                    'http://192.168.50.100/cgi-bin/index.cgi?id=upload'):
            with self.subTest(url=url), self.assertRaises(ValueError):check_vendor.endpoint(url)

    def test_vendor_report_omits_identifiers(self):
        value={'sys':{'appver':'26011618.6238.2','password':'synthetic-secret'}, 'sn':'synthetic-serial', 'name':'synthetic-name', 'update':0}
        report=check_vendor.summarize(value)
        self.assertTrue(report['software_candidate']);self.assertFalse(report['installation_approved'])
        self.assertNotIn('synthetic', json.dumps(report))

    def test_wrong_firmware_not_candidate(self):
        self.assertFalse(check_vendor.summarize({'sys':{'appver':'26060818.7115.2'}, 'update':0})['software_candidate'])
        self.assertFalse(check_vendor.summarize({'sys':{'appver':'26011618.6238.2'}, 'update':1})['software_candidate'])

    def test_http_redirect_is_rejected(self):
        with self.assertRaises(ValueError):check_vendor.NoRedirect().redirect_request(None,None,302,'m',{},'http://192.168.50.100/cgi-bin/index.cgi?id=set')

    def test_duplicate_boot_hash_is_rejected(self):
        with self.assertRaises(ValueError):activate.hash_lines(('a'*64+'  /dev/mtd3\n')*2)

    def test_boot_hash_must_belong_to_correct_file(self):
        value='uid=0(root)\n'+common.REFERENCE['target_root_sha256']+'  /wrong\n'+common.REFERENCE['target_boot_script_sha256']+'  /sbin/ly_boot.sh\n'
        with self.assertRaises(ValueError):activate.verify_boot(value)

    def test_ports_are_strict(self):
        for value in (-1,0,65536,True,'5037'):
            with self.subTest(value=value),self.assertRaises(ValueError):activate.valid_port(value)

    def test_hardlinked_backups_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            a,b=Path(temp)/'a',Path(temp)/'b';a.write_bytes(bytes(common.SIZE));os.link(a,b)
            with self.assertRaises(ValueError):common.backup_pair(a,b)

    def test_wrong_flash_is_rejected(self):
        version='AWUSBFEX ID=0x00188200(V821)\n'
        raw=json.dumps({'chip':'V821','jedec':'ffffff','bytes':common.SIZE,'flash_write_commands':False})
        with patch.object(installer,'host_reader',return_value='/mock/reader'),patch.object(installer,'run_reader',side_effect=[version,raw]),self.assertRaises(ValueError):installer.check_fel()

    def test_existing_usb_server_is_not_stopped(self):
        with tempfile.TemporaryDirectory() as t,patch.object(installer.USBSession,'root',return_value=True),patch.object(installer.subprocess,'Popen') as create:
            with installer.USBSession(t) as session:self.assertEqual(session.port,5037)
            create.assert_not_called()

    def test_other_host_rejected(self):
        with patch.object(installer.platform,'system',return_value='Windows'),self.assertRaises(ValueError):installer.preflight()

    def test_journal_retains_phase_history(self):
        with tempfile.TemporaryDirectory() as t:
            installer.save_state(t,'reading_original');installer.save_state(t,'stopped')
            v=json.loads((Path(t)/'state.json').read_text())
            self.assertEqual([x['phase'] for x in v['history']],['reading_original','stopped'])

    def test_libusb_lookup_needs_no_brew_process(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);(p/'include/libusb-1.0').mkdir(parents=True);(p/'lib').mkdir()
            (p/'include/libusb-1.0/libusb.h').write_text('test')
            (p/'lib/libusb-1.0.dylib').write_text('test')
            with patch.dict(os.environ,{'AUDI_V8_LIBUSB_PREFIX':t}),patch.object(build_host.subprocess,'run') as run:
                self.assertEqual(build_host.find_libusb(),t);run.assert_not_called()

    def test_cancel_before_device_access(self):
        with patch.object(installer,'preflight'),patch.object(installer,'confirm',side_effect=ValueError('cancel')),patch.object(installer,'host_reader') as reader:
            with self.assertRaises(ValueError):installer.install()
            reader.assert_not_called()

    def test_bad_factory_backup_stops_before_write(self):
        with tempfile.TemporaryDirectory() as t:
            def fake_read(reader,*args,**kwargs):
                self.assertEqual(args[0],'read');Path(args[1]).write_bytes(bytes(common.SIZE));return 'READ_OK'
            with patch.object(installer,'PRIVATE',Path(t)),patch.object(installer,'preflight'),patch.object(installer,'confirm'),patch.object(installer,'host_reader',return_value='/mock'),patch.object(installer,'check_fel',return_value={}),patch.object(installer,'run_reader',side_effect=fake_read),patch.object(installer,'flash') as write:
                with self.assertRaises(ValueError):installer.install()
                write.assert_not_called()
                states=list(Path(t).glob('device-*/state.json'));self.assertEqual(len(states),1)
                self.assertEqual(json.loads(states[0].read_text())['phase'],'stopped')

    def test_export_does_not_copy_error_or_owner_data(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);(p/'install-test').mkdir();(p/'usb-test').mkdir()
            (p/'install-test/result.json').write_text(json.dumps({'mode':'install','flash_verified':False,'error':'synthetic-owner-secret', 'backup_sha256':'synthetic-backup'}))
            (p/'usb-test/result.json').write_text(json.dumps({'actual_root_boot_verified':True,'runtime_installed':True,'runtime_bytes_pulled_and_verified':True,'vehicle_mode_enabled':True,'udisk_snapshot_sha256':'synthetic-udisk'}))
            with patch.object(export_report,'profile',return_value=(p,{'expected':{'target_root_sha256':common.REFERENCE['target_root_sha256'],'runtime_manifest_sha256':common.REFERENCE['runtime_manifest_sha256']}})):
                value=export_report.export('unused',p/'share.json')
                self.assertNotIn('synthetic',json.dumps(value));self.assertTrue(value['flash_runs'][0]['error_recorded'])

if __name__=='__main__':unittest.main()
