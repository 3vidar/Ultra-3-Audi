"""Compile/run the real writer against a mock flash only; never opens USB."""
from pathlib import Path
import argparse
import json
import subprocess
import sys
import tempfile
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from common import PROJECT, REFERENCE, profile, sha
from build_host import find_libusb

def run(path):
    d, data = profile(path)
    prefix = find_libusb()
    with tempfile.TemporaryDirectory(prefix='v8-writer-test-') as temp:
        temp = Path(temp); binary = temp / 'writer-tests'; results = temp / 'readbacks'; results.mkdir()
        command = ['/usr/bin/clang', '-O1', '-UNDEBUG', '-Wall', '-Wextra', '-Wno-unused-parameter', '-Wno-deprecated-declarations',
                   '-I' + str(PROJECT / 'src/fel'), '-I' + prefix + '/include/libusb-1.0',
                   '-DBACKUP_SHA="' + data['backup_sha256'] + '"',
                   '-DORIGINAL_ROOT_SHA="' + sha((d/'rootfs-original.bin').read_bytes()) + '"',
                   '-DPATCHED_ROOT_SHA="' + data['expected']['target_root_sha256'] + '"',
                   str(PROJECT / 'tests/rootfs_writer_mock.c')]
        command += [str(PROJECT / 'src/fel' / n) for n in ('fel.c', 'v821-spi.c', 'progress.c')]
        command += ['-L' + prefix + '/lib', '-lusb-1.0', '-framework', 'IOKit', '-framework', 'CoreFoundation', '-framework', 'Security', '-o', str(binary)]
        subprocess.run(command, check=True)
        r = subprocess.run([str(binary), str(d / 'fullbackup.bin'), str(d / 'rootfs-v8.bin'), str(results)], capture_output=True, text=True, timeout=120)
        (d / 'writer-mock-test.txt').write_text(r.stdout + r.stderr)
        count = sum(line.startswith('PASS ') for line in r.stdout.splitlines())
        if r.returncode or count != 12:
            raise ValueError('Writer-Mockprüfung fehlgeschlagen. Privaten Prüfbericht ansehen.')
        report = {'mock_flash_cases_passed': count, 'usb_opened': False, 'target_root_sha256': data['expected']['target_root_sha256']}
        (d / 'writer-mock-test.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report, indent=2))
        return report

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__); p.add_argument('profile'); a = p.parse_args(); run(a.profile)
