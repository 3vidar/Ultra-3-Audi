from pathlib import Path
import contextlib
import io
import json
import os
import struct
import sys
import tempfile
import unittest
import shutil
import subprocess
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'));sys.path.insert(0,str(ROOT))
import candidate
import common
import prepare
import activate
import flash

@unittest.skipUnless(os.environ.get('V8_TEST_OWN_FACTORY_BACKUP'),'requires local private owner fixture')
class BuildIndependentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original=Path(os.environ['V8_TEST_OWN_FACTORY_BACKUP']).read_bytes()
        changed=bytearray(cls.original)
        stamp=struct.unpack_from('<I',changed,common.START+8)[0]
        struct.pack_into('<I',changed,common.START+8,stamp+86400)
        stamp=struct.unpack_from('<I',changed,common.END+8)[0]
        struct.pack_into('<I',changed,common.END+8,stamp+86400)
        cls.other=bytes(changed)
        cls.target,cls.runtime,cls.expected,cls.report=candidate.build(cls.other)

    def test_changed_build_metadata_is_accepted(self):
        self.assertFalse(self.report['build_number_checked'])
        self.assertNotEqual(common.sha(self.other[common.START:common.END]),common.REFERENCE['factory_root_sha256'])
        self.assertNotEqual(common.sha(self.other[common.END:common.REFERENCE['customer_end']]),common.REFERENCE['factory_customer_region_sha256'])
        self.assertNotEqual(self.expected['target_root_sha256'],common.REFERENCE['target_root_sha256'])
        self.assertEqual(self.target[:8],self.other[common.START:common.START+8])
        self.assertEqual(self.target[8:12],self.other[common.START+8:common.START+12])

    def test_existing_v8_libraries_remain_identical(self):
        for name in ('libaudi_knob_k1.so','libaudi_navigation.so','libaudi_zoom.so'):
            self.assertEqual(common.sha(self.runtime[name]),common.REFERENCE['runtime_files'][name])

    def test_required_code_identity_still_checked(self):
        pins=dict(candidate.API_FILES);pins['/app/libiap_new.so']='0'*64
        with patch.object(candidate,'API_FILES',pins),self.assertRaises(ValueError):candidate.inspect(self.other)

    def test_corrupt_environment_is_refused(self):
        raw=bytearray(self.other);raw[0xea0100]^=1
        with self.assertRaises(ValueError):candidate.inspect(raw)

    def test_different_layout_is_refused(self):
        raw=bytearray(self.other);raw[common.START:common.START+4]=b'nope'
        with self.assertRaises(ValueError):candidate.inspect(raw)

    def test_bad_inner_container_is_refused(self):
        with self.assertRaises(ValueError):candidate.packed_libraries(bytes(300))

    def test_personalised_profile_and_tamper_rejection(self):
        with tempfile.TemporaryDirectory() as t:
            t=Path(t);a,b=t/'a',t/'b';a.write_bytes(self.other);b.write_bytes(self.other)
            prepare.prepare(a,b,t/'output');common.profile(t/'output/profile.json')
            path=t/'output/profile.json';data=json.loads(path.read_text());data['expected']['target_root_sha256']='0'*64;path.write_text(json.dumps(data))
            with self.assertRaises(ValueError):common.profile(path)


    def test_boot_check_uses_the_actual_generated_target(self):
        text='uid=0(root)\n'+self.expected['target_root_sha256']+'  /dev/mtd3\n'+self.expected['target_boot_script_sha256']+'  /sbin/ly_boot.sh\n'
        activate.verify_boot(text,self.expected)
        with self.assertRaises(ValueError):activate.verify_boot(text)

    def test_activation_uses_personalised_root_hash(self):
        with tempfile.TemporaryDirectory() as t:
            t=Path(t);a,b=t/'a',t/'b';a.write_bytes(self.other);b.write_bytes(self.other)
            prepare.prepare(a,b,t/'output')
            mode={'value':'diagnostic'}
            def run(args,**kwargs):
                if 'shell' in args:
                    cmd=args[-1]
                    if 'V8_BOOT_READ' in cmd:
                        out='uid=0(root)\n'+self.expected['target_root_sha256']+'  /dev/mtd3\n'+self.expected['target_boot_script_sha256']+'  /sbin/ly_boot.sh\nV8_BOOT_READ\n'
                    elif 'RUNTIME_ALREADY_EXISTS' in cmd:out='RUNTIME_ABSENT\n'
                    elif 'V8_SPACE_READ' in cmd:out='/dev/mtd9 512 100 400 50% /mnt/UDISK\nV8_SPACE_READ\n'
                    elif 'V8_RUNTIME_INSTALLED' in cmd:
                        self.assertIn(self.expected['runtime_manifest_sha256'],cmd);out='V8_RUNTIME_INSTALLED\n'
                    elif 'V8_CARPLAY_ENABLED' in cmd:mode['value']='carplay';out='V8_CARPLAY_ENABLED\n'
                    else:raise AssertionError(cmd)
                    return subprocess.CompletedProcess(args,0,out,'')
                if 'pull' in args:
                    if args[-2]=='/dev/mtd9':Path(args[-1]).write_bytes(bytes(524288))
                    else:
                        shutil.copytree(t/'output/runtime',args[-1]);(Path(args[-1])/'mode').write_text(mode['value']+'\n')
                elif 'push' not in args:raise AssertionError(args)
                return subprocess.CompletedProcess(args,0,'','')
            with patch.object(activate.subprocess,'run',side_effect=run):
                result=activate.activate(t/'output/profile.json')
            self.assertTrue(result['actual_root_boot_verified']);self.assertTrue(result['vehicle_mode_enabled'])

    def test_changed_oem_script_updates_manifest_and_dispatcher(self):
        from dissect.squashfs import SquashFS
        original_fs=SquashFS(io.BytesIO(self.original[common.START:common.END]))
        boot=original_fs.get('/sbin/ly_boot.sh').open().read()
        # Same byte count, unrelated comment only. Native binaries remain intact.
        marker=b'#!/bin/sh';self.assertIn(marker,boot)
        changed=boot.replace(marker,b'#!/bin/sh',1)
        # Exercise a realistic harmless one-byte edit in an existing comment.
        comment=next(line for line in boot.splitlines() if line.startswith(b'#') and len(line)>10 and not line.startswith(b'#!'))
        at=boot.index(comment)+2
        changed=boot[:at]+(b'x' if boot[at:at+1]!=b'x' else b'y')+boot[at+1:]
        from rootfs_patch import rootfs
        newroot=rootfs(self.original[common.START:common.END],changed)
        raw=self.original[:common.START]+newroot+self.original[common.END:]
        target,runtime,expected,_=candidate.build(raw)
        self.assertNotEqual(expected['runtime_manifest_sha256'],common.REFERENCE['runtime_manifest_sha256'])
        fs=SquashFS(io.BytesIO(target));dispatcher=fs.get('/sbin/ly_boot.sh').open().read()
        self.assertIn(expected['runtime_manifest_sha256'].encode(),dispatcher)
        self.assertNotIn(common.REFERENCE['runtime_manifest_sha256'].encode(),dispatcher)
        with tempfile.TemporaryDirectory() as t:
            t=Path(t)
            for name,value in runtime.items():(t/name).write_bytes(value)
            (t/'mode').write_bytes(b'carplay\n')
            activate.verify_runtime_copy(t,expected=expected)
            with self.assertRaises(ValueError):activate.verify_runtime_copy(t)

if __name__=='__main__':unittest.main()
