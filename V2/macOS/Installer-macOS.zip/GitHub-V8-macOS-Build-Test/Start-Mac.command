#!/bin/zsh
cd -- "${0:A:h}" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
    print 'Python 3 is missing. See Instructions-English.pdf.'
    read '?Press Enter to close: '
    exit 1
fi
python3 tools/bootstrap.py
result=$?
read '?Press Enter to close: '
exit "$result"
