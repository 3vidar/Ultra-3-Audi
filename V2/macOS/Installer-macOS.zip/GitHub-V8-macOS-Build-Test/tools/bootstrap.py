"""Prepare a project-local Python environment; never accesses a dongle."""
from pathlib import Path
import os
import shutil
import subprocess
import sys
from integrity import verify_release
from build_host import find_libusb

ROOT = Path(__file__).resolve().parents[1]

def main():
    verify_release()
    if sys.version_info < (3, 10):
        raise ValueError('Python 3.10+ is required. See Instructions-English.pdf.')
    if not shutil.which('adb'):
        raise ValueError('Install Homebrew libusb and Android Platform Tools first.')
    find_libusb()
    subprocess.run(['/usr/bin/xcrun', '--find', 'clang'], capture_output=True, check=True)
    environment = ROOT / '.venv'
    if environment.is_symlink():
        raise ValueError('The local Python environment must not be a link.')
    python = environment / 'bin/python3'
    if not environment.exists():
        print('First setup downloads the pinned Python packages from PyPI. Internet is required. No device is opened.')
        if input('Create the local environment? Type YES: ').strip() != 'YES':
            raise ValueError('Setup cancelled.')
        subprocess.run([sys.executable, '-m', 'venv', str(environment)], check=True)
        subprocess.run([str(python), '-m', 'pip', '--disable-pip-version-check', 'install', '-r', str(ROOT / 'requirements.txt')], check=True)
    if not python.is_file():
        raise ValueError('Python setup is incomplete. See Instructions-English.pdf.')
    return subprocess.run([str(python), str(ROOT / 'installer.py')], cwd=ROOT).returncode

if __name__ == '__main__':
    try: raise SystemExit(main())
    except (OSError, ValueError, subprocess.SubprocessError) as e:
        print('Setup stopped: ' + str(e), file=sys.stderr); raise SystemExit(1)
