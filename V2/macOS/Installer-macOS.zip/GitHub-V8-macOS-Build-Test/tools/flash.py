"""Explicit FEL rootfs installation/restoration, using an owner-specific writer."""
from pathlib import Path
import argparse
import datetime
import json
import subprocess
from common import SIZE, START, END, sha, profile, verify_flash

def flash(path, restore=False):
    d, data = profile(path)
    build=json.loads((d/'writer-build.json').read_text())
    if build['backup_sha256']!=data['backup_sha256'] or build['target_root_sha256']!=data['expected']['target_root_sha256'] or build['binary_sha256']!=sha((d/'rootfs-writer').read_bytes()):
        raise ValueError('Writer build does not match this owner-specific package.')
    folder=d/('restore-' if restore else 'install-')
    folder=folder.with_name(folder.name+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'));folder.mkdir()
    before,after=folder/'before.bin',folder/'after.bin'
    report={'mode':'restore' if restore else 'install','flash_verified':False,'real_boot_verified':False}
    print('Requires confirmed V821 FEL; every contact bridge must be removed. Keep USB connected.',flush=True)
    try:
        with (folder/'writer.log').open('w') as log:
            p=subprocess.Popen([str(d/'rootfs-writer'),report['mode'],str(d/'fullbackup.bin'),str(d/'rootfs-v8.bin'),str(before),str(after)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
            for line in p.stdout:log.write(line);log.flush();print(line.rstrip(),flush=True)
            if p.wait():raise ValueError('Writer failed. Do not claim successful installation; retain this report.')
        target=(d/('rootfs-original.bin' if restore else 'rootfs-v8.bin')).read_bytes()
        sectors=verify_flash(before.read_bytes(),after.read_bytes(),target)
        report.update(flash_verified=True,changed_sectors=sectors,before_sha256=sha(before.read_bytes()),after_sha256=sha(after.read_bytes()))
        print('FULL FLASH READBACK VERIFIED. Unplug and reconnect normally without any bridge.')
        if restore:print('Original rootfs restored. Custom USB root diagnosis is no longer supplied by this rootfs.')
        else:print('Fresh V8 initially starts USB diagnosis because its runtime is not installed. Next run tools/activate.py.')
    except Exception as error:
        report['error']=str(error);raise
    finally:
        (folder/'result.json').write_text(json.dumps(report,indent=2)+'\n')
        print('REPORT',folder)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('profile');p.add_argument('--restore',action='store_true');a=p.parse_args()
    flash(a.profile,a.restore)
