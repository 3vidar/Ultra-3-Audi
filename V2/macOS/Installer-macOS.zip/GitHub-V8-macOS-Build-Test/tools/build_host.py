"""Build host tools on macOS; never opens USB or changes a dongle."""
from pathlib import Path
import argparse
import json
import os
import platform
import shutil
import subprocess
from common import PROJECT, REFERENCE, sha, profile

def find_libusb():
    custom = os.environ.get('AUDI_V8_LIBUSB_PREFIX')
    defaults = ['/opt/homebrew/opt/libusb', '/usr/local/opt/libusb']
    if platform.machine() != 'arm64':
        defaults.reverse()
    for value in ([custom] if custom else defaults):
        p = Path(value)
        if (p/'include/libusb-1.0/libusb.h').is_file() and (p/'lib/libusb-1.0.dylib').is_file():
            return str(p)
    raise ValueError('libusb not found. Install Homebrew libusb or set AUDI_V8_LIBUSB_PREFIX.')

def build(profile_path=None, output=None):
    if platform.system() != 'Darwin':
        raise ValueError('This host build is supported on macOS only.')
    prefix = find_libusb()
    include = ['-I'+str(PROJECT/'src/fel'), '-I'+prefix+'/include/libusb-1.0']
    flags = ['-O2','-Wall','-Wextra','-Wno-unused-parameter','-Wno-deprecated-declarations',*include]
    support = [str(PROJECT/'src/fel'/n) for n in ('fel.c','v821-spi.c','progress.c')]
    libraries = ['-L'+prefix+'/lib','-lusb-1.0','-framework','IOKit','-framework','CoreFoundation','-framework','Security']
    if profile_path:
        d, data = profile(profile_path)
        target = d/'rootfs-writer'
        command = ['/usr/bin/clang',*flags,'-DBACKUP_SHA="'+data['backup_sha256']+'"',
            '-DORIGINAL_ROOT_SHA="'+sha((d/'rootfs-original.bin').read_bytes())+'"',
            '-DPATCHED_ROOT_SHA="'+data['expected']['target_root_sha256']+'"',str(PROJECT/'src/rootfs_writer.c'),*support,*libraries,'-o',str(target)]
        subprocess.run(command,check=True)
        (d/'writer-build.json').write_text(json.dumps({'backup_sha256':data['backup_sha256'],
            'target_root_sha256':data['expected']['target_root_sha256'],'binary_sha256':sha(target.read_bytes()),
            'host':platform.machine(), 'physical_public_flow_tested':False},indent=2)+'\n')
    else:
        if not output:
            raise ValueError('--output required when building the backup reader.')
        directory = Path(output).resolve(); directory.mkdir(parents=True,exist_ok=True)
        target = directory/'flash-reader'
        subprocess.run(['/usr/bin/clang',*flags,str(PROJECT/'src/fel/reader.c'),*support,*libraries,'-o',str(target)],check=True)
    print('BUILT',target,'(build only; no device access)')

if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--profile');p.add_argument('--output');a=p.parse_args()
    build(a.profile,a.output)
