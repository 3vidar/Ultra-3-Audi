# V8 macOS Build Test - Instructions

## 1. Prepare the Mac

Use macOS, Python 3.10 or newer and a matching Carlinkit Mini Ultra 3 in the ly6238 hardware family. This test package does not select by firmware build number. The Audi cluster extension must already work over an iPhone cable.

1. Install Python from python.org/downloads/macos/ if it is not already available.

2. Install Apple Command Line Tools in Terminal: xcode-select --install.

3. Install Homebrew from brew.sh. In Terminal run brew install libusb, then brew install --cask android-platform-tools.

4. Extract the installer ZIP into a local folder. Keep an internet connection for the first setup.

## 2. Enter USB FEL mode

5. Disconnect the dongle. Open its case and match the board to the drawing. If the board differs or B1 is not confirmed ground, stop.

6. With USB disconnected, connect only flash pin 1 to confirmed B1 ground. Plug the dongle into the Mac.

7. Remove the bridge immediately when FEL is detected, and always within five seconds, even without a detection message. Leave USB connected. Keep all other contacts untouched.

## 3. Start and install

1. Open Start-Mac.command in the extracted folder. If asked to create the local Python environment, type YES and wait for setup.

2. Select 1 to check FEL. Continue when FEL CONNECTION VERIFIED appears.

3. Select 2. Type ULTRA3 when requested. Keep USB connected while both complete original backups are read and checked.

4. Type INSTALL when requested. Wait for the full write and readback to finish.

5. When prompted, unplug the dongle and reconnect normally, without any bridge. Then press Enter.

6. Leave the dongle connected while USB startup and all installed files are checked. Wait for V8 BUILD TEST INSTALLED; BYTES AND BOOT VERIFIED.

## 4. Keep your recovery copy

7. Close the window and unplug the dongle. Keep the complete installer folder and its private folder together. Save another private copy for recovery. Share only the original unused release ZIP.

## 5. Test in the Audi

8. Connect the dongle in the parked Audi and pair your iPhone as usual. Start a route.

9. Check the cluster map, street name, junction detail, steering-wheel zoom and repeated double-OK switching.

10. Check music and a phone call. Unplug and reconnect, then repeat the connection check after a longer parking period.

## Continue after an interrupted reconnect

1. Connect the dongle normally to the Mac, without a bridge. Allow about a minute for the diagnostic USB connection to appear if needed.

2. Open Start-Mac.command from the same folder. Select 3 and choose your backup number.

3. Wait for V8 BUILD TEST INSTALLED; BYTES AND BOOT VERIFIED before unplugging.

## Restore your original root filesystem

1. Connect the dongle normally to the Mac, without a bridge. Allow about a minute for diagnostic USB if needed.

2. Open Start-Mac.command from the original installer folder containing your backups.

3. Select 4 and choose your own backup number. Type RESTORE when requested.

4. Keep USB connected until ORIGINAL ROOT FILESYSTEM RESTORED AND VERIFIED appears.

5. Unplug and reconnect normally. Test original CarPlay in the Audi.

If diagnostic USB is unavailable, repeat the confirmed FEL entry on page 1, then select 4 with the same backup folder.

