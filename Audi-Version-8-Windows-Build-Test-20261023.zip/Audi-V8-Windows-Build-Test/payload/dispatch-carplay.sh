# Verified runtime only. No vehicle power-on counter.
if [ -e "$Z/diagnostic.next" ]; then
 rm -f "$Z/diagnostic.next"
 sync
 echo 'V6 requested USB diagnosis' >/dev/null
elif [ "$(cat "$Z/mode" 2>/dev/null)" = carplay ]; then
 echo 'V6 persistent CarPlay start' >/dev/null
 /bin/sh "$Z/mac-return.sh" &
 exec /bin/sh "$Z/carplay.sh"
fi
