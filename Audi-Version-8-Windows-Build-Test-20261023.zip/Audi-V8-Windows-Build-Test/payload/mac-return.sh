#!/bin/sh
# Keep the proven automatic USB diagnosis on a Mac; no vehicle boot counter.
Z=/mnt/UDISK/audi-zoom6238
sleep 60
if [ -s /tmp/audi-hu-identified ]; then
 exit 0
fi
if echo no-hu >"$Z/diagnostic.next.tmp" && mv "$Z/diagnostic.next.tmp" "$Z/diagnostic.next"; then
 sync
 reboot -f
fi
