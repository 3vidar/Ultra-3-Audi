#!/bin/sh
Z=/mnt/UDISK/audi-zoom6238
if [ -x "$Z/carplay.sh" ] &&
 [ "$(sha256sum "$Z/SHA256SUMS" 2>/dev/null | awk '{print $1}')" = "f16340db5a18e8deba0153a36ec13c7f15ad518a24848ba0af2eacfb4f017182" ] &&
 (cd "$Z" && sha256sum -c SHA256SUMS >/dev/null 2>&1); then
 . "$Z/dispatch-carplay.sh"
fi
# Temporary USB-only diagnostic mode; original firmware remains in the backup.
PATH=/usr/sbin:/usr/bin:/sbin:/bin
export PATH
exec >>/dev/null 2>&1
echo "Audi USB diagnostic start"
mkdir -p /var/run /dev/usb-ffs/adb
G=/sys/kernel/config/usb_gadget/g1
if [ ! -d /sys/kernel/config/usb_gadget ]; then
    mount -t configfs none /sys/kernel/config || exit 1
fi
mkdir -p "$G/strings/0x409" "$G/configs/c.1/strings/0x409" "$G/functions/ffs.adb" || exit 1
echo '' > "$G/UDC"
echo 0x18d1 > "$G/idVendor"
echo 0xd002 > "$G/idProduct"
echo Allwinner > "$G/strings/0x409/manufacturer"
echo Audi-USB-Diagnose > "$G/strings/0x409/product"
echo V821-Audi-USB > "$G/strings/0x409/serialnumber"
echo 0xc0 > "$G/configs/c.1/bmAttributes"
echo 500 > "$G/configs/c.1/MaxPower"
mount -t functionfs -o uid=0,gid=0 adb /dev/usb-ffs/adb || exit 1
ln -s "$G/functions/ffs.adb" "$G/configs/c.1/ffs.adb" || exit 1
ADB_AUTH_ENABLE=0 /bin/adbd >/dev/null 2>&1 &
ADBPID=$!
UDC=$(ls /sys/class/udc | head -n 1)
[ -n "$UDC" ] || exit 1
for n in 1 2 3 4 5 6 7 8 9 10; do
    sleep 0.5
    kill -0 "$ADBPID" || exit 1
    if [ "$(cat "$G/UDC" 2>/dev/null)" = "$UDC" ] || echo "$UDC" > "$G/UDC"; then
        echo ready >/tmp/audi-usb-debug-ready
        echo "ADB USB bound to $UDC"
        exit 0
    fi
done
echo "ADB USB bind failed"
exit 1#                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
                                      