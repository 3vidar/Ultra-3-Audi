#!/bin/sh
# The first argument labels the process; no observer or capture is started.
shift
exec "$@"
