"""Host-only tests. A real owner backup is optional and never shipped."""
from pathlib import Path
import os
import sys
import tempfile
import unittest
from unittest.mock import patch
import subprocess
import shutil

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'tools'))
from common import SIZE, START, END, REFERENCE, apply_unified, backup_pair, factory_ok, profile, verify_flash
from prepare import prepare
import activate

class GuardTests(unittest.TestCase):
    def test_patch_exact_context(self):
        self.assertEqual(apply_unified('a\nb\nc\n', '--- original\n+++ v8\n@@ -1,3 +1,3 @@\n a\n-b\n+B\n c\n'), 'a\nB\nc\n')

    def test_patch_wrong_context_rejected(self):
        with self.assertRaises(ValueError): apply_unified('a\nx\n', '--- a\n+++ b\n@@ -1,2 +1,2 @@\n a\n-b\n+B\n')

    def test_factory_wrong_size_rejected(self):
        with self.assertRaises(ValueError): factory_ok(b'wrong')

    def test_foreign_firmware_rejected(self):
        with self.assertRaises(ValueError): factory_ok(bytes(SIZE))

    def test_same_backup_path_rejected(self):
        with self.assertRaises(ValueError): backup_pair('one.bin', 'one.bin')

    def test_two_different_reads_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            a,b=Path(t)/'a',Path(t)/'b';a.write_bytes(bytes(SIZE));b.write_bytes(b'x'+bytes(SIZE-1))
            with self.assertRaises(ValueError): backup_pair(a,b)

    def test_whole_flash_comparison(self):
        before=bytes(SIZE);target=b'\x55'*(END-START);after=before[:START]+target+before[END:]
        self.assertTrue(verify_flash(before,after,target))

    def test_outside_byte_rejected(self):
        before=bytes(SIZE);target=bytes(END-START);after=bytearray(before);after[END+1]=1
        with self.assertRaises(ValueError): verify_flash(before,after,target)

    def test_wrong_target_byte_rejected(self):
        before=bytes(SIZE);after=bytearray(before);after[START+1]=1
        with self.assertRaises(ValueError): verify_flash(before,after,bytes(END-START))

class OwnFactoryFixtureTests(unittest.TestCase):
    @unittest.skipUnless(os.environ.get('V8_TEST_OWN_FACTORY_BACKUP'), 'requires local private owner fixture')
    def test_fresh_generation_and_different_owner_data(self):
        raw=Path(os.environ['V8_TEST_OWN_FACTORY_BACKUP']).read_bytes()
        with tempfile.TemporaryDirectory() as t:
            t=Path(t);a,b=t/'a.bin',t/'b.bin';a.write_bytes(raw);b.write_bytes(raw)
            first=prepare(a,b,t/'one');profile(t/'one/profile.json')
            self.assertEqual(first['target_root_sha256'],REFERENCE['target_root_sha256'])
            self.assertEqual(len(first['changed_factory_rootfs_sectors']),29)
            other=bytearray(raw);other[0xf80100]^=1
            a.write_bytes(other);b.write_bytes(other)
            second=prepare(a,b,t/'two');profile(t/'two/profile.json')
            self.assertNotEqual(first['backup_sha256'],second['backup_sha256'])
            self.assertEqual((t/'one/rootfs-v8.bin').read_bytes(),(t/'two/rootfs-v8.bin').read_bytes())
            self.assertEqual((t/'two/fullbackup.bin').read_bytes(),other)
            with self.assertRaises(ValueError): prepare(a,b,t/'two')
            # Device-facing calls simulated; prove guards before runtime upload.
            for case in ('wrong-root','existing-runtime','no-space','corrupt-runtime','valid-fresh-activation'):
                actions=[]
                mode={'value':'diagnostic'}
                def fake_run(args,**kwargs):
                    actions.append(args)
                    if 'shell' in args:
                        command=args[-1]
                        if 'V8_BOOT_READ' in command:
                            text='uid=0(root)\n'+('0'*64 if case=='wrong-root' else REFERENCE['target_root_sha256'])+'  /dev/mtd3\n'+REFERENCE['target_boot_script_sha256']+'  /sbin/ly_boot.sh\nV8_BOOT_READ\n'
                        elif 'RUNTIME_ALREADY_EXISTS' in command:
                            text='RUNTIME_ALREADY_EXISTS\n' if case=='existing-runtime' else 'RUNTIME_ABSENT\n'
                        elif 'V8_SPACE_READ' in command:
                            text='/dev/mtd9 512 100 '+('1' if case=='no-space' else '400')+' 50% /mnt/UDISK\nV8_SPACE_READ\n'
                        elif 'V8_RUNTIME_INSTALLED' in command:text='V8_RUNTIME_INSTALLED\n'
                        elif 'V8_CARPLAY_ENABLED' in command:
                            mode['value']='carplay';text='V8_CARPLAY_ENABLED\n'
                        else:raise AssertionError('Unexpected shell command.')
                        return subprocess.CompletedProcess(args,0,text,'')
                    if 'pull' in args:
                        if args[-2]=='/dev/mtd9':Path(args[-1]).write_bytes(bytes(524288))
                        else:
                            shutil.copytree(t/'two/runtime',args[-1])
                            (Path(args[-1])/'mode').write_text(mode['value']+'\n')
                            if case=='corrupt-runtime':(Path(args[-1])/'libaudi_knob_k1.so').write_bytes(b'wrong')
                    elif 'push' not in args:raise AssertionError('Unexpected device command.')
                    return subprocess.CompletedProcess(args,0,'','')
                with patch.object(activate.shutil,'which',return_value='/mock/adb'),patch.object(activate.subprocess,'run',side_effect=fake_run):
                    if case=='valid-fresh-activation':activate.activate(t/'two/profile.json')
                    else:
                        with self.assertRaises(ValueError):activate.activate(t/'two/profile.json')
                uploads=[x for x in actions if 'push' in x]
                self.assertEqual(len(uploads),1 if case in ('valid-fresh-activation','corrupt-runtime') else 0)
                if case=='corrupt-runtime':self.assertFalse(any('V8_CARPLAY_ENABLED' in x[-1] for x in actions))
                if case=='wrong-root':self.assertFalse(any('pull' in x for x in actions))

if __name__=='__main__': unittest.main()
