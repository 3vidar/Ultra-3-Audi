from pathlib import Path
import contextlib
import io
import json
import os
import stat
import struct
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'));sys.path.insert(0,str(ROOT))
import common
import flash
import fel_windows
import adb_windows
import installer
import activate

class BytesUSB:
    def __init__(self,data=b''):
        self.input=bytearray(data);self.writes=[]
    def read(self,n):
        if len(self.input)<n:raise ValueError('mock USB exhausted')
        data=bytes(self.input[:n]);del self.input[:n];return data
    def write(self,data):self.writes.append(bytes(data))

def awus():return b'AWUS'+bytes(9)
def usb_reply(data):return data+awus()

class ProtocolTests(unittest.TestCase):
    def test_winusb_interface_and_serial_selection(self):
        import usb_transport
        class Interface(list):
            bInterfaceNumber=0;bAlternateSetting=0
            bInterfaceClass=255;bInterfaceSubClass=66;bInterfaceProtocol=1
        interface=Interface([SimpleNamespace(bmAttributes=2,bEndpointAddress=0x81,wMaxPacketSize=512),SimpleNamespace(bmAttributes=2,bEndpointAddress=2,wMaxPacketSize=512)])
        device=SimpleNamespace(serial_number='V821-Audi-USB',get_active_configuration=lambda:[interface])
        calls=[]
        core=SimpleNamespace(find=lambda **kw:[device],USBError=RuntimeError)
        util=SimpleNamespace(claim_interface=lambda d,i:calls.append(('claim',i)),release_interface=lambda d,i:calls.append(('release',i)),dispose_resources=lambda d:calls.append(('dispose',)))
        usb=SimpleNamespace(core=core,util=util)
        with patch.dict(sys.modules,{'usb':usb,'usb.core':core,'usb.util':util}),patch.object(usb_transport,'backend',return_value=object()):
            with usb_transport.USB(usb_transport.ADB_ID) as connection:
                self.assertEqual((connection.epin,connection.epout),(0x81,2))
            self.assertIn(('release',0),calls)
            device.serial_number='unrelated'
            with self.assertRaises(ValueError):usb_transport.USB(usb_transport.ADB_ID)

    def test_usb_debug_full_packet_has_zero_length_terminator(self):
        import usb_transport
        connection=object.__new__(usb_transport.USB)
        connection.adb=True;connection.packet_size=512;connection.epout=2
        writes=[]
        def write(ep,data,timeout):writes.append(data);return len(data)
        connection.device=SimpleNamespace(write=write)
        connection.write(b'x'*4096)
        self.assertEqual([len(x) for x in writes],[4096,0])
        writes.clear();connection.write(b'x'*24)
        self.assertEqual([len(x) for x in writes],[24])
        connection.adb=False;writes.clear();connection.write(b'x'*4096)
        self.assertEqual([len(x) for x in writes],[4096])

    def test_two_usb_devices_are_refused(self):
        import usb_transport
        core=SimpleNamespace(find=lambda **kw:[object(),object()],USBError=RuntimeError)
        util=SimpleNamespace(dispose_resources=lambda d:None)
        with patch.dict(sys.modules,{'usb':SimpleNamespace(core=core,util=util),'usb.core':core,'usb.util':util}),patch.object(usb_transport,'backend',return_value=object()),self.assertRaises(ValueError):
            usb_transport.USB(usb_transport.FEL_ID)

    def test_sfdp_probe_and_erase_confirmation(self):
        device=object.__new__(fel_windows.FEL)
        table=bytes.fromhex('e520f9ffffffff07')+bytes(56)
        device.read_command=lambda tx,n:bytes.fromhex('0b4018')
        device.status_register=lambda command:{5:0,0x35:0x1a,0x15:0}[command]
        device.sfdp=lambda address,n:({0:bytes.fromhex('53464450060101ff'),8:bytes.fromhex('00060110000100ff'),256:table}[address])[:n]
        self.assertEqual(device.probe()['bytes'],common.SIZE)
        device.writable()
        device.status_register=lambda command:4 if command==5 else 0
        with self.assertRaises(ValueError):device.writable()

    def test_wrong_flash_identity_stops(self):
        device=object.__new__(fel_windows.FEL)
        device.read_command=lambda tx,n:bytes.fromhex('ffffff')
        device.status_register=lambda command:0
        device.sfdp=lambda address,n:bytes.fromhex('53464450060101ff')
        with self.assertRaises(ValueError):device.probe()

    def test_fel_version_and_wire_header(self):
        version=struct.pack('<8sIIHBBI8s',b'AWUSBFEX',0x00188200,0,0,0x44,8,0x02020800,bytes(8))
        usb=BytesUSB(awus()+usb_reply(version)+usb_reply(b'\xff\xff'+bytes(6)))
        fel_windows.FEL(usb)
        self.assertEqual(usb.writes[0],struct.pack('<8sIIHI10s',b'AWUC',16,0x0c000000,0x12,16,bytes(10)))
        self.assertEqual(usb.writes[1],struct.pack('<IIII',1,0,0,0))
        self.assertFalse(usb.input)

    def test_fel_bad_reply_stops(self):
        with self.assertRaises(ValueError):fel_windows.FEL(BytesUSB(b'BAD!'+bytes(9)))

    def test_fel_wrong_soc_stops(self):
        version=struct.pack('<8sIIHBBI8s',b'AWUSBFEX',0x123,0,0,0,0,0,bytes(8))
        with self.assertRaises(ValueError):fel_windows.FEL(BytesUSB(awus()+usb_reply(version)+usb_reply(b'\xff\xff'+bytes(6))))

    def test_spi_ram_payload_matches_source(self):
        import re
        source=(ROOT/'src/fel/v821-spi.c').read_text().split('payload[] = {',1)[1].split('};',1)[0]
        expected=bytes(int(h,16) for h in re.findall(r'0x([0-9a-f]{2})',source))
        self.assertEqual(expected,(ROOT/'src/v821-spi.bin').read_bytes())

    def test_spi_exact_instruction_encoding(self):
        device=object.__new__(fel_windows.FEL);device.spi_started=False
        memory=[];programs=[]
        device.write_ram=lambda addr,data:memory.append((addr,data))
        device.execute=lambda data:programs.append(data)
        device.read_ram=lambda addr,n:b'\x01'*n
        self.assertEqual(device.spi(b'\x9f',3),b'\x01'*3)
        self.assertEqual(programs,[b'\x01\x00',b'\x02\x05'+struct.pack('<II',0x02002000,1)+b'\x06'+struct.pack('<II',0x02002000,3)+b'\x03\x00'])
        self.assertEqual(memory[1],(0x02002000,b'\x9f'))

    def test_adb_shell_and_checksum(self):
        packet=adb_windows.packet
        usb=BytesUSB(packet(b'CNXN',0x01000000,4096,b'device::\0')+packet(b'OKAY',7,1)+packet(b'WRTE',7,1,b'uid=0(root)\n')+packet(b'CLSE',7,1))
        adb=adb_windows.ADB(usb)
        self.assertEqual(adb.shell('id'),b'uid=0(root)\n')
        self.assertFalse(usb.input)
        self.assertEqual(len(usb.writes),5)
        self.assertEqual(usb.writes[-1],packet(b'OKAY',1,7))

    def test_adb_bad_checksum_is_rejected(self):
        wire=bytearray(adb_windows.packet(b'CNXN',0x01000000,4096,b'device::\0'));wire[-2]^=1
        with self.assertRaises(ValueError):adb_windows.ADB(BytesUSB(wire))

    def test_adb_auth_is_rejected_without_host_key(self):
        with self.assertRaises(ValueError):adb_windows.ADB(BytesUSB(adb_windows.packet(b'AUTH',1,0,b'token')))

    def test_adb_wrong_stream_is_rejected(self):
        packet=adb_windows.packet
        usb=BytesUSB(packet(b'CNXN',0x01000000,4096)+packet(b'OKAY',7,1)+packet(b'WRTE',8,1,b'wrong'))
        adb=adb_windows.ADB(usb)
        with self.assertRaises(ValueError):adb.shell('id')

    def test_sync_directory_and_file_download(self):
        packet=adb_windows.packet
        listing=b'DENT'+struct.pack('<IIII',stat.S_IFREG|0o644,3,0,4)+b'mode'+b'DONE'+bytes(16)
        received=b'DATA'+struct.pack('<I',3)+b'abc'+b'DONE'+bytes(4)
        wire=packet(b'CNXN',0x01000000,4096)+packet(b'OKAY',7,1)+packet(b'OKAY',7,1)+packet(b'WRTE',7,1,listing)+packet(b'OKAY',7,1)+packet(b'WRTE',7,1,received)
        usb=BytesUSB(wire);sync=adb_windows.Sync(adb_windows.ADB(usb))
        self.assertEqual(sync.list_files('/runtime'),['mode'])
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'mode';sync.pull_file('/runtime/mode',p);self.assertEqual(p.read_bytes(),b'abc')
        sync.close();self.assertFalse(usb.input)

    def test_sync_push_waits_for_remote_confirmation(self):
        packet=adb_windows.packet
        wire=packet(b'CNXN',0x01000000,4096)+packet(b'OKAY',7,1)+packet(b'OKAY',7,1)*3+packet(b'WRTE',7,1,b'OKAY'+bytes(4))
        usb=BytesUSB(wire);sync=adb_windows.Sync(adb_windows.ADB(usb))
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'a';p.write_bytes(b'abc');sync.push_file(p,'/runtime/a')
        self.assertFalse(usb.input)

    def test_sync_directory_traversal_is_rejected(self):
        packet=adb_windows.packet
        listing=b'DENT'+struct.pack('<IIII',stat.S_IFREG|0o644,3,0,4)+b'../x'
        wire=packet(b'CNXN',0x01000000,4096)+packet(b'OKAY',7,1)+packet(b'OKAY',7,1)+packet(b'WRTE',7,1,listing)
        sync=adb_windows.Sync(adb_windows.ADB(BytesUSB(wire)))
        with self.assertRaises(ValueError):sync.list_files('/runtime')

    def test_device_boot_must_match(self):
        with self.assertRaises(ValueError):activate.verify_boot('uid=0(root)\n')

    def test_write_opcodes_and_ranges(self):
        for command in [b'\xc7',b'\x01\0',b'\x31\0',b'\x20\0\0\0',b'\x02\0\0\0X',b'\x20'+common.END.to_bytes(3,'big'),b'\x20'+(common.START+1).to_bytes(3,'big'),b'\x02'+common.START.to_bytes(3,'big')+bytes(257)]:
            with self.subTest(command=command):self.assertFalse(fel_windows.valid_write(command))
        self.assertTrue(fel_windows.valid_write(b'\x20'+common.START.to_bytes(3,'big')))

    def test_other_host_rejected(self):
        with patch.object(installer.platform,'system',return_value='Darwin'),self.assertRaises(ValueError):installer.preflight()

    def test_cancel_opens_no_usb(self):
        with patch.object(installer,'preflight'),patch.object(installer,'confirm',side_effect=ValueError('cancel')),patch.object(installer,'check_fel') as usb:
            with self.assertRaises(ValueError):installer.install()
            usb.assert_not_called()

    def test_journal_history(self):
        with tempfile.TemporaryDirectory() as t:
            installer.save_state(t,'before');installer.save_state(t,'after')
            self.assertEqual([x['phase'] for x in json.loads((Path(t)/'state.json').read_text())['history']],['before','after'])

class NOR:
    def __init__(self,data):self.data=bytearray(data);self.commands=[];self.sr=0;self.protected=False;self.corrupt=False
    def read_range(self,a,n):
        result=bytes(self.data[a:a+n])
        if self.corrupt and n==4096 and self.commands:result=b'X'+result[1:]
        return result
    def writable(self):
        if self.protected:raise ValueError('protected')
    def status_register(self,c):return self.sr
    def write_command(self,command):
        if not fel_windows.valid_write(command):raise AssertionError('invalid write command')
        self.commands.append(command)
        if command==b'\x06':self.sr=2;return
        if command==b'\x04':self.sr=0;return
        if self.sr!=2:raise AssertionError('write not enabled')
        a=int.from_bytes(command[1:4],'big')
        if command[0]==0x20:self.data[a:a+4096]=b'\xff'*4096
        elif command[0]==2:
            for i,b in enumerate(command[4:]):self.data[a+i]&=b
        self.sr=0

@unittest.skipUnless(os.environ.get('V8_TEST_OWN_FACTORY_BACKUP'),'requires local private owner fixture')
class WriterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original=Path(os.environ['V8_TEST_OWN_FACTORY_BACKUP']).read_bytes()
        cls.target=Path(os.environ['V8_TEST_TARGET_ROOT']).read_bytes()
        common.factory_ok(cls.original)
    def apply(self,device,mode='install',backup=None,target=None):
        backup=self.original if backup is None else backup
        target=(self.target if mode=='install' else backup[common.START:common.END]) if target is None else target
        with tempfile.TemporaryDirectory() as t,contextlib.redirect_stdout(io.StringIO()):
            return flash.apply_image(device,mode,backup,target,Path(t)/'before',Path(t)/'after',common.sha(backup))
    def test_install_preserves_outside_and_superblock_last(self):
        device=NOR(self.original);result=self.apply(device)
        self.assertEqual(len(result['changed_sectors']),29)
        self.assertEqual(device.data[:common.START],self.original[:common.START]);self.assertEqual(device.data[common.END:],self.original[common.END:])
        erases=[int.from_bytes(x[1:4],'big') for x in device.commands if x[0]==0x20]
        self.assertEqual(erases[-1],common.START)
    def test_restore_preserves_mutable_data(self):
        data=bytearray(self.original);data[common.START:common.END]=self.target;data[0xf80100]^=1
        device=NOR(data);self.apply(device,'restore')
        self.assertEqual(device.data[common.START:common.END],self.original[common.START:common.END]);self.assertEqual(device.data[0xf80100],data[0xf80100])
    def test_changed_original_refused_before_writes(self):
        data=bytearray(self.original);data[0xf80100]^=1;device=NOR(data)
        with self.assertRaises(ValueError):self.apply(device)
        self.assertFalse(device.commands)
    def test_foreign_boot_refused_before_writes(self):
        data=bytearray(self.original);data[100]^=1;device=NOR(data)
        with self.assertRaises(ValueError):self.apply(device,'restore')
        self.assertFalse(device.commands)
    def test_protection_is_not_changed(self):
        device=NOR(self.original);device.protected=True
        with self.assertRaises(ValueError):self.apply(device)
        self.assertFalse(device.commands)
    def test_wrong_target_stops_before_usb_write(self):
        device=NOR(self.original)
        with self.assertRaises(ValueError):self.apply(device,target=bytes(common.END-common.START))
        self.assertFalse(device.commands)
    def test_bad_sector_readback_stops(self):
        device=NOR(self.original);device.corrupt=True
        with self.assertRaises(ValueError):self.apply(device)
        erases=[x for x in device.commands if x[0]==0x20];self.assertEqual(len(erases),1)
    def test_partial_write_can_restore(self):
        data=bytearray(self.original);a=0xa8c000;data[a:a+4096]=b'\xff'*4096
        device=NOR(data);self.apply(device,'restore');self.assertEqual(device.data,self.original)
    def test_already_original_does_not_erase(self):
        device=NOR(self.original);result=self.apply(device,'restore');self.assertFalse(result['changed_sectors']);self.assertFalse(any(x[0]==0x20 for x in device.commands))
    def test_existing_output_stops_before_writes(self):
        device=NOR(self.original)
        with tempfile.TemporaryDirectory() as t:
            before,after=Path(t)/'before',Path(t)/'after';after.write_bytes(b'keep')
            with self.assertRaises(ValueError):flash.apply_image(device,'install',self.original,self.target,before,after,common.sha(self.original))
            self.assertEqual(after.read_bytes(),b'keep');self.assertFalse(device.commands)

if __name__=='__main__':unittest.main()
