"""Set up the local Windows Python environment and start the installer."""
from pathlib import Path
import importlib.metadata
import platform
import struct
import subprocess
import sys
from integrity import verify_release

ROOT=Path(__file__).resolve().parents[1]

def main():
    verify_release()
    if platform.system()!='Windows' or struct.calcsize('P')!=8 or platform.machine().lower() not in ('amd64','x86_64'):
        raise ValueError('Use Windows 10/11 x64 and 64-bit Python.')
    if not (3,11)<=sys.version_info[:2]<=(3,13):
        raise ValueError('Install 64-bit Python 3.11, 3.12 or 3.13 from python.org.')
    environment=ROOT/'.venv'
    if environment.is_symlink():
        raise ValueError('The local Python folder must not be a link.')
    python=environment/'Scripts/python.exe'
    if not environment.exists():
        subprocess.run([sys.executable,'-m','venv',str(environment)],check=True)
    if not python.is_file():
        raise ValueError('Incomplete setup. Remove only .venv, then start again. Keep private.')
    print('Preparing the installer. Internet is needed for this first setup.',flush=True)
    subprocess.run([str(python),'-m','pip','--disable-pip-version-check','install','--only-binary=:all:','-r',str(ROOT/'requirements.txt')],check=True)
    return subprocess.run([str(python),'-X','utf8',str(ROOT/'installer.py')],cwd=ROOT).returncode

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as error:print('SETUP STOPPED:',error,file=sys.stderr);raise SystemExit(1)
