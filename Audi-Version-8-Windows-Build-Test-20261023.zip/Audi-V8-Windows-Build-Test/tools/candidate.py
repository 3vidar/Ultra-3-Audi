"""Build-independent ly6238 inspection and reproducible own-backup generation."""
from pathlib import Path
import io
import json
import struct
import zipfile
import zlib
from common import PROJECT, REFERENCE, SIZE, START, END, sha, apply_unified, payload_ok
from check_squashfs_mount import check_mount_layout
from rootfs_patch import rootfs

CUSTOMER_END=REFERENCE['customer_end']
API_FILES={
    '/app/libwcarplay_new.so':'f708c771eb6f912f9d05a935b231e294f15922cb4bfc7e2ef12a954ee361a64a',
    '/app/libiap_new.so':'617ff1b235d8cc5e6e7e1dd4e97a937c173120173ba4173758fc71a08f7cd134',
}
PACKED_FILES={
    'librcarplay.so':'556c306b0bbe538377426df470a8648a29513bb2d1c78f16e7b9a79d07dfbfac',
    'libriap2.so':'f9656e2a816a5ac159423bc7d704a28eb069c223765d09bb2dbda35916d12a72',
}

def environment(data):
    data=bytes(data)
    matches=[]
    expected={b'ly_project_name':b'ly6238',b'flash_size':b'16',b'nor_root':b'/dev/mtdblock3',b'root_partition':b'rootfs'}
    for offset in (0xea0000,0xeb0000):
        blob=data[offset:offset+65536]
        crc=struct.unpack_from('<I',blob)[0]
        starts=[i for i in (4,5) if zlib.crc32(blob[i:])&0xffffffff==crc]
        if len(starts)!=1:
            raise ValueError('The existing ly6238 flash environment layout could not be confirmed.')
        values={}
        for item in blob[starts[0]:].split(b'\0'):
            if not item:break
            if b'=' in item:
                key,value=item.split(b'=',1)
                if key in values:raise ValueError('Duplicate flash environment field.')
                values[key]=value
        if any(values.get(k)!=v for k,v in expected.items()):
            raise ValueError('This hardware/project or root partition layout differs from ly6238.')
        matches.append(True)
    return len(matches)==2

def packed_libraries(raw):
    if len(raw)<266 or len(raw)>8*1024*1024 or not raw.endswith(b'lypackfile'):
        raise ValueError('Unexpected CarPlay container format.')
    data=bytearray(raw[:-10])
    for i in range(128):
        data[i]^=b'ya-iepc'[i%7]
        data[len(data)-128+i]^=b'aoyutec'[i%7]
    result={}
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        names=archive.namelist()
        if len(names)!=len(set(names)) or len(names)>32:
            raise ValueError('Ambiguous CarPlay container.')
        for item in archive.infolist():
            if item.file_size>8*1024*1024 or item.compress_size>8*1024*1024:
                raise ValueError('CarPlay container exceeds its bounds.')
        for name,digest in PACKED_FILES.items():
            value=archive.read(name)
            if sha(value)!=digest:
                raise ValueError('V8 code addresses differ in '+name+'. No firmware written.')
            result[name]=digest
    return result

def inspect(data):
    from dissect.squashfs import SquashFS
    if len(data)!=SIZE:
        raise ValueError('Exactly 16 MiB is required.')
    if data[0x60000:0x60008]!=b'ANDROID!' or data[0x370000:0x370008]!=b'ANDROID!':
        raise ValueError('The existing kernel/recovery layout was not recognised.')
    environment(data)
    original=data[START:END];customer=data[END:CUSTOMER_END]
    check_mount_layout(original,strict_id_end=True)
    check_mount_layout(customer,strict_id_end=True)
    fs=SquashFS(io.BytesIO(original));cs=SquashFS(io.BytesIO(customer))
    for path in ('/bin/adbd','/sbin/ly_boot.sh'):
        node=fs.get(path)
        if not node.is_file() or node.size==0:
            raise ValueError('Required system file missing: '+path)
    apis={}
    for name,digest in API_FILES.items():
        content=cs.get(name).open().read()
        if sha(content)!=digest:
            raise ValueError('V8 code addresses differ in '+name+'. No firmware written.')
        if content[:6]!=b'\x7fELF\x01\x01' or struct.unpack_from('<H',content,18)[0]!=243:
            raise ValueError('Expected RV32 CarPlay libraries.')
        apis[name]=digest
    apis.update(packed_libraries(cs.get('/app/lylink').open().read()))
    return fs,cs,{'build_number_checked':False,'flash_layout_checked':True,'api_files':apis,
                  'original_root_sha256':sha(original),'customer_sha256':sha(customer)}

def build(data):
    payload_ok()
    fs,cs,report=inspect(data)
    boot=fs.get('/sbin/ly_boot.sh').open().read().decode('utf-8')
    link=cs.get('/app/lyLink.sh').open().read().decode('utf-8')
    runtime={}
    runtime['carplay.sh']=apply_unified(boot,(PROJECT/'payload/carplay.patch').read_text(encoding='utf-8')).encode('utf-8')
    runtime['lyLink-zoom.sh']=apply_unified(link,(PROJECT/'payload/lyLink.patch').read_text(encoding='utf-8')).encode('utf-8')
    for name in REFERENCE['runtime_files']:
        if name not in ('carplay.sh','lyLink-zoom.sh','SHA256SUMS'):
            runtime[name]=(PROJECT/'payload'/name).read_bytes()
    manifest=''.join(sha(runtime[n])+'  '+n+'\n' for n in sorted(runtime)).encode('ascii')
    runtime['SHA256SUMS']=manifest
    old=REFERENCE['runtime_manifest_sha256'].encode('ascii')
    template=(PROJECT/'payload/boot-dispatcher.sh').read_bytes()
    if template.count(old)!=1:
        raise ValueError('Unexpected boot dispatcher template.')
    replacement=template.replace(old,sha(manifest).encode('ascii'))
    size=fs.get('/sbin/ly_boot.sh').size
    if len(replacement)!=size:
        replacement=replacement.rstrip(b' \r\n')
        if len(replacement)>size:
            raise ValueError('USB boot dispatcher does not fit this firmware inode.')
        replacement=replacement.ljust(size,b' ')
    target=rootfs(data[START:END],replacement)
    descriptor={'target_root_sha256':sha(target),'target_boot_script_sha256':sha(replacement),
                'runtime_manifest_sha256':sha(manifest),
                'runtime_files':{n:sha(v) for n,v in runtime.items()}}
    return target,runtime,descriptor,report
