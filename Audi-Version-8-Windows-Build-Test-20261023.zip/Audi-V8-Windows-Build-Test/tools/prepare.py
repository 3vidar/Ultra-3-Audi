"""Generate a V8 Build Test package from two complete own-device reads."""
from pathlib import Path
import argparse
import json
import os
import tempfile
from common import START, END, sha, backup_pair
from candidate import build


def prepare(a,b,destination):
    original=backup_pair(a,b)
    destination=Path(destination).resolve()
    if destination.exists():
        raise ValueError('Output must be a new directory.')
    target,runtime,expected,compatibility=build(original)
    destination.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.v8-build-',dir=destination.parent) as temp:
        d=Path(temp);(d/'runtime').mkdir()
        for name,value in runtime.items():
            (d/'runtime'/name).write_bytes(value)
        for name,value in [('fullbackup.bin',original),('rootfs-original.bin',original[START:END]),('rootfs-v8.bin',target)]:
            (d/name).write_bytes(value)
        sectors=[hex(START+i) for i in range(0,END-START,4096) if original[START+i:START+i+4096]!=target[i:i+4096]]
        data={'schema':1,'revision':8,'variant':'build-test-1','backup_sha256':sha(original),
              'two_complete_identical_backup_files_confirmed':True,'expected':expected,
              'factory_root_sha256':sha(original[START:END]),'target_root_sha256':sha(target),
              'runtime_manifest_sha256':expected['runtime_manifest_sha256'],
              'changed_factory_rootfs_sectors':sectors,'compatibility':compatibility,
              'device_installation_performed':False,'contains_private_backup':True}
        (d/'profile.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
        (d/'compatibility.json').write_text(json.dumps(compatibility,indent=2)+'\n',encoding='utf-8')
        os.replace(d,destination)
    return data


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('backup_a');p.add_argument('backup_b');p.add_argument('--output',required=True)
    args=p.parse_args()
    prepare(args.backup_a,args.backup_b,args.output)
    print('OWN-BACKUP BUILD TEST PACKAGE GENERATED. No device written.')
