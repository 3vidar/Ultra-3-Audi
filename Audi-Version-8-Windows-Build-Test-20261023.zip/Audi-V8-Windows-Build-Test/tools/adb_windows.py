"""Small direct-USB ADB client for V8 shell and legacy file-sync operations.

No daemon, TCP listener, host ADB keys, or network transport is used.
"""
from pathlib import Path, PurePosixPath
import stat
import struct
import sys
import time
from usb_transport import USB, ADB_ID

def packet(command, arg0=0, arg1=0, payload=b''):
    command = int.from_bytes(command, 'little')
    return struct.pack('<6I',command,arg0,arg1,len(payload),sum(payload)&0xffffffff,command^0xffffffff)+payload

class ADB:
    def __init__(self, usb):
        self.usb = usb
        self.next_id = 1
        self.send(b'CNXN',0x01000000,4096,b'host::\0')
        cmd, version, maximum, payload = self.receive()
        if cmd != b'CNXN' or version not in (0x01000000,0x01000001) or maximum < 1024:
            raise ValueError('USB root connection unavailable. Check the diagnostic WinUSB driver.')
        self.maximum = min(maximum,4096)

    def send(self, command, arg0=0, arg1=0, payload=b''):
        data = packet(command,arg0,arg1,payload)
        self.usb.write(data[:24])
        if payload:
            self.usb.write(payload)

    def receive(self):
        cmd,a,b,n,checksum,magic = struct.unpack('<6I',self.usb.read(24))
        if cmd^0xffffffff != magic or n > 1024*1024:
            raise ValueError('Invalid USB debug packet.')
        data = self.usb.read(n) if n else b''
        if sum(data)&0xffffffff != checksum:
            raise ValueError('USB debug checksum failed.')
        return cmd.to_bytes(4,'little'),a,b,data

    def open(self, service):
        local = self.next_id; self.next_id += 1
        self.send(b'OPEN',local,0,service.encode()+b'\0')
        command, remote, recipient, data = self.receive()
        if command != b'OKAY' or recipient != local or not remote or data:
            raise ValueError('USB debug service was refused.')
        return Stream(self,local,remote)

    def shell(self, command):
        stream = self.open('shell:'+command)
        data = bytearray()
        while not stream.closed:
            data.extend(stream.read_block())
            if len(data) > 8*1024*1024:
                raise ValueError('Shell response exceeds the limit.')
        return bytes(data)

class Stream:
    def __init__(self, adb, local, remote):
        self.adb,self.local,self.remote = adb,local,remote
        self.buffer = bytearray()
        self.closed = False

    def event(self):
        command,a,b,data = self.adb.receive()
        if a != self.remote or b != self.local:
            raise ValueError('Unexpected USB stream identity.')
        if command == b'WRTE':
            self.buffer.extend(data)
            self.adb.send(b'OKAY',self.local,self.remote)
        elif command == b'CLSE':
            self.closed = True
        elif command != b'OKAY':
            raise ValueError('Unexpected USB stream packet.')
        return command

    def write(self, data):
        for offset in range(0,len(data),self.adb.maximum):
            if self.closed:
                raise ValueError('USB stream closed during upload.')
            self.adb.send(b'WRTE',self.local,self.remote,data[offset:offset+self.adb.maximum])
            for _ in range(64):
                event = self.event()
                if event == b'OKAY':
                    break
                if self.closed:
                    raise ValueError('USB stream closed before upload acknowledgement.')
            else:
                raise ValueError('USB acknowledgement limit exceeded.')

    def read(self, length):
        for _ in range(65536):
            if len(self.buffer) >= length:
                value=bytes(self.buffer[:length]);del self.buffer[:length];return value
            if self.closed:
                raise ValueError('USB stream ended before the requested bytes.')
            self.event()
        raise ValueError('USB stream response limit exceeded.')

    def read_block(self):
        if not self.buffer and not self.closed:
            self.event()
        result=bytes(self.buffer);self.buffer.clear();return result

    def close(self):
        if self.closed:
            return
        self.adb.send(b'CLSE',self.local,self.remote)
        self.closed = True

class Sync:
    def __init__(self, adb):
        self.stream = adb.open('sync:')

    def request(self, command, data=b''):
        self.stream.write(command+struct.pack('<I',len(data))+data)

    def header(self):
        command,length=struct.unpack('<4sI',self.stream.read(8))
        if command == b'FAIL':
            if length > 65536:
                raise ValueError('Invalid file-sync failure.')
            raise ValueError('File-sync failed: '+self.stream.read(length).decode('utf-8',errors='replace'))
        return command,length

    def pull_file(self, remote, local):
        self.request(b'RECV',remote.encode())
        total = 0
        with Path(local).open('xb') as output:
            while True:
                cmd,n = self.header()
                if cmd == b'DONE':
                    return
                if cmd != b'DATA' or not 0 < n <= 65536:
                    raise ValueError('Invalid download record.')
                total += n
                if total > 16*1024*1024:
                    raise ValueError('Download exceeds the limit.')
                output.write(self.stream.read(n))

    def list_files(self, remote):
        self.request(b'LIST',remote.encode())
        result=[]
        for _ in range(256):
            command,mode = self.header()
            size,mtime,length=struct.unpack('<III',self.stream.read(12))
            if command == b'DONE':
                return result
            if command != b'DENT' or length > 255:
                raise ValueError('Invalid directory entry.')
            name=self.stream.read(length).decode('utf-8')
            if name in ('.','..'):
                continue
            if not stat.S_ISREG(mode) or PurePosixPath(name).name != name or '/' in name or '\\' in name or ':' in name or name in ('','..'):
                raise ValueError('Unexpected runtime file or directory.')
            result.append(name)
        raise ValueError('Too many directory entries.')

    def push_file(self, local, remote):
        source=Path(local)
        if source.is_symlink() or not source.is_file() or source.stat().st_size > 4*1024*1024:
            raise ValueError('Invalid upload file.')
        self.request(b'SEND',(remote+','+str(stat.S_IFREG|0o755)).encode())
        with source.open('rb') as stream:
            for chunk in iter(lambda:stream.read(4096),b''):
                self.request(b'DATA',chunk)
        self.stream.write(b'DONE'+struct.pack('<I',int(time.time())))
        if self.header() != (b'OKAY',0):
            raise ValueError('File upload was not confirmed.')

    def close(self):
        self.stream.close()

def main(args):
    if not args or args[0] not in ('shell','pull','push'):
        raise ValueError('Expected shell, pull or push.')
    with USB(ADB_ID) as usb:
        adb=ADB(usb)
        if args[0]=='shell' and len(args)==2:
            sys.stdout.buffer.write(adb.shell(args[1]));return
        if len(args)!=3:
            raise ValueError('Invalid file operation.')
        if args[0]=='push':
            source=Path(args[1]);remote=args[2]
            if not remote.startswith('/mnt/UDISK/audi-zoom6238-stage-') or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/-' for c in remote):
                raise ValueError('Unexpected upload destination.')
            result=adb.shell('mkdir '+remote+' && echo V8_STAGE_READY')
            if b'V8_STAGE_READY' not in result.splitlines():
                raise ValueError('Unable to create upload directory.')
            sync=Sync(adb)
            for file in sorted(source.iterdir()):
                sync.push_file(file,remote+'/'+file.name)
        else:
            remote,local=args[1],Path(args[2]);sync=Sync(adb)
            if remote=='/mnt/UDISK/audi-zoom6238':
                names=sync.list_files(remote)
                local.mkdir(exist_ok=False)
                for name in names:
                    sync.pull_file(remote+'/'+name,local/name)
            elif remote=='/dev/mtd9':
                sync.pull_file(remote,local)
            else:
                raise ValueError('Unexpected download path.')
        sync.close()

if __name__=='__main__':
    try:
        main(sys.argv[1:])
    except Exception as error:
        print('USB step stopped: '+str(error),file=sys.stderr)
        raise SystemExit(1)
