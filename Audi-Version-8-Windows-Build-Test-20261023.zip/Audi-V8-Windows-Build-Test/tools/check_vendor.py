"""Optional read-only vendor web query. Never uploads, sets values or reboots."""
import argparse
import ipaddress
import json
from pathlib import Path
import re
import urllib.error
import urllib.parse
import urllib.request

MAX_BYTES = 65536

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError('HTTP-Weiterleitung abgelehnt.')

def endpoint(base):
    p = urllib.parse.urlsplit(base)
    if p.scheme != 'http' or p.username or p.password or p.path not in ('', '/') or p.query or p.fragment:
        raise ValueError('Nur eine lokale HTTP-Geräteadresse ohne Pfad oder Zugangsdaten ist erlaubt.')
    try:
        address = ipaddress.IPv4Address(p.hostname)
        port = p.port
    except (ValueError, TypeError):
        raise ValueError('Eine private IPv4-Adresse ist erforderlich.') from None
    allowed = any(address in ipaddress.ip_network(net) for net in ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16'))
    if not allowed or port not in (None, 80):
        raise ValueError('Nur private IPv4-Adressen auf HTTP-Port 80 sind erlaubt.')
    return 'http://' + str(address) + '/cgi-bin/index.cgi?id=host'

def summarize(value):
    if not isinstance(value, dict) or not isinstance(value.get('sys'), dict):
        raise ValueError('Die Antwort enthält keine passende Herstellerinformation.')
    appver = value['sys'].get('appver')
    if not isinstance(appver, str) or not re.fullmatch(r'[0-9]{8}\.[0-9]{4}\.[0-9]{1,3}', appver):
        raise ValueError('Unbekanntes Firmwareformat. Keine Freigabe.')
    update = value.get('update')
    if type(update) is not int:
        raise ValueError('Unbekannter Updatezustand.')
    return {'appver': appver, 'project': 'ly' + appver.split('.')[1], 'update_state': update,
            'software_candidate': appver == '26011618.6238.2' and update == 0,
            'hardware_verified': False, 'installation_approved': False,
            'note': 'Nur Software-Vorauswahl. Chip, Flash und Originaldateien müssen separat geprüft werden.'}

def query(base):
    url = endpoint(base)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    request = urllib.request.Request(url, headers={'User-Agent': 'Audi-V8-read-only-check/1'}, method='GET')
    with opener.open(request, timeout=8) as response:
        if response.status != 200:
            raise ValueError('Keine gültige Geräteantwort.')
        data = response.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise ValueError('Geräteantwort zu groß.')
    return summarize(json.loads(data))

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument('--url'); g.add_argument('--json-file', type=Path)
    a = p.parse_args()
    try:
        if a.json_file:
            if a.json_file.stat().st_size > MAX_BYTES:
                raise ValueError('Datei zu groß.')
            result = summarize(json.loads(a.json_file.read_bytes()))
        else:
            result = query(a.url)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except (ValueError, OSError, urllib.error.URLError) as e:
        raise SystemExit('Prüfung beendet: ' + str(e))
