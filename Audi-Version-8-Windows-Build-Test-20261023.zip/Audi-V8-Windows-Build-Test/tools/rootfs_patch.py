from pathlib import Path
import io, lzma, struct
from common import sha
from check_squashfs_mount import check_mount_layout

def rootfs(original, replacement):
    from dissect.squashfs import SquashFS
    fs = SquashFS(io.BytesIO(original)); node = fs.get('/sbin/ly_boot.sh')
    if len(replacement) != node.size:
        raise ValueError('Exact V8 boot script must retain the original inode size.')
    entry = fs._lookup_fragment(node.header.fragment)
    _, fragment = fs._read_block(entry.start_block, entry.size)
    start = node.header.offset
    if fragment[start:start+node.size] != node.open().read():
        raise ValueError('Original fragment differs from its inode.')
    newfragment = fragment[:start] + replacement + fragment[start+node.size:]
    compressed = lzma.compress(newfragment, format=lzma.FORMAT_XZ, check=lzma.CHECK_CRC32,
        filters=[{'id': lzma.FILTER_LZMA2, 'dict_size': fs.block_size, 'preset': 6}])
    patched = bytearray(original); pos = (fs.size + 4095) & ~4095; data_at = pos
    patched[pos:pos+len(compressed)] = compressed; pos += len(compressed)
    entries = []
    for i in range(fs.sb.fragments):
        old = fs._lookup_fragment(i)
        entries.append(struct.pack('<QII', data_at if i == node.header.fragment else old.start_block,
            len(compressed) if i == node.header.fragment else old.size, old.unused))
    metadata = b''.join(entries)
    if len(metadata) >= 8192:
        raise ValueError('Unsupported fragment table size.')
    meta_at = pos
    patched[pos:pos+2+len(metadata)] = struct.pack('<H', 0x8000 | len(metadata)) + metadata
    pos += 2 + len(metadata); index_at = pos
    patched[pos:pos+8] = struct.pack('<Q', meta_at); pos += 8
    struct.pack_into('<Q', patched, 80, index_at)
    for offset in (88, 48):
        oldindex = struct.unpack_from('<Q', original, offset)[0]
        oldmeta = struct.unpack_from('<Q', original, oldindex)[0]
        stored = original[oldmeta:oldindex]; newmeta = pos
        patched[pos:pos+len(stored)] = stored; pos += len(stored)
        newindex = pos; patched[pos:pos+8] = struct.pack('<Q', newmeta); pos += 8
        struct.pack_into('<Q', patched, offset, newindex)
    if pos >= len(original) or not set(original[data_at:pos]) <= {0, 255}:
        raise ValueError('New fragment would overwrite existing firmware data.')
    struct.pack_into('<Q', patched, 40, pos)
    check_mount_layout(patched, strict_id_end=True)
    def inventory(data):
        sq = SquashFS(io.BytesIO(data)); result = {}
        def walk(n, path):
            record = (n.type, n.mode, n.uid, n.gid, n.mtime.isoformat(), n.inode_number, n.size)
            if n.is_file(): record += (sha(n.open().read()),)
            elif n.is_symlink(): record += (n.link,)
            result[path] = record
            if n.is_dir():
                for child in n.iterdir(): walk(child, path.rstrip('/') + '/' + child.name)
        walk(sq.root, '/'); return result
    before, after = inventory(original), inventory(patched)
    if before.keys() != after.keys()  or [n for n in before if before[n] != after[n]] != ['/sbin/ly_boot.sh']:
        raise ValueError('Unexpected filesystem change.')
    if len(patched) != len(original):
        raise ValueError('Root filesystem size changed.')
    return bytes(patched)

