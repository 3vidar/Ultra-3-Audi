"""V821 FEL transport and bounded NOR access, ported from src/fel/."""
import json
import struct
from pathlib import Path
from usb_transport import USB, FEL_ID
from common import PROJECT, SIZE, START, END

class FEL:
    def __init__(self, usb):
        self.usb = usb
        self.spi_started = False
        self.request(1, 0, 0)
        self.version = self.usb_read(32)
        self.status()
        if self.version[:8] != b'AWUSBFEX' or struct.unpack_from('<I', self.version, 8)[0] != 0x00188200:
            raise ValueError('Exactly one V821 FEL dongle is required.')

    def usb_request(self, kind, length):
        self.usb.write(struct.pack('<8sIIHI10s', b'AWUC', length, 0x0c000000, kind, length, bytes(10)))

    def response(self):
        data = self.usb.read(13)
        if data[:4] != b'AWUS' or data[12]:
            raise ValueError('Invalid FEL USB response.')

    def usb_write(self, data):
        self.usb_request(0x12, len(data)); self.usb.write(data); self.response()

    def usb_read(self, length):
        self.usb_request(0x11, length); data = self.usb.read(length); self.response()
        return data

    def request(self, kind, address, length):
        self.usb_write(struct.pack('<IIII', kind, address, length, 0))

    def status(self):
        data = self.usb_read(8)
        if data[:2] != b'\xff\xff' or data[4]:
            raise ValueError('FEL operation failed.')

    def read_ram(self, address, length):
        self.request(0x103, address, length)
        data = self.usb_read(length); self.status()
        return data

    def write_ram(self, address, data):
        self.request(0x101, address, len(data)); self.usb_write(data); self.status()

    def execute(self, program):
        self.write_ram(0x02001000, program)
        self.request(0x102, 0x02000000, 0); self.status()

    def spi(self, tx, rx=0):
        if not 0 < len(tx) <= 65536 or not 0 <= rx <= 65536:
            raise ValueError('SPI transfer exceeds its bounds.')
        if not self.spi_started:
            self.write_ram(0x02000000, (PROJECT/'src/v821-spi.bin').read_bytes())
            self.execute(bytes((1, 0))); self.spi_started = True
        self.write_ram(0x02002000, tx)
        program = b'\x02\x05' + struct.pack('<II', 0x02002000, len(tx))
        if rx:
            program += b'\x06' + struct.pack('<II', 0x02002000, rx)
        self.execute(program + b'\x03\x00')
        return self.read_ram(0x02002000, rx) if rx else b''

    def read_command(self, tx, length):
        allowed = (len(tx) == 1 and tx[0] in (0x9f, 5)) or (len(tx) == 5 and tx[0] == 0x5a) or (len(tx) == 4 and tx[0] == 3)
        if not allowed or not 0 < length <= 65536:
            raise ValueError('Read command is not allowed.')
        return self.spi(tx, length)

    def status_register(self, command):
        if command not in (5, 0x35, 0x15):
            raise ValueError('Status command is not allowed.')
        return self.spi(bytes((command,)), 1)[0]

    def write_command(self, command):
        if not valid_write(command):
            raise ValueError('Flash write is outside the allowed root filesystem.')
        self.spi(command)

    def sfdp(self, address, count):
        return self.read_command(b'\x5a' + address.to_bytes(3, 'big') + b'\0', count)

    def probe(self):
        jedec = self.read_command(b'\x9f', 3)
        sr1 = self.status_register(5)
        header = self.sfdp(0, 8)
        if jedec != bytes.fromhex('0b4018') or header[:4] != b'SFDP' or header[5] != 1 or sr1 & 1:
            raise ValueError('Unsupported or busy flash memory.')
        table = None
        for i in range(header[6]+1):
            ph = self.sfdp(8+i*8, 8)
            if ph[0] == 0 and ph[7] == 255 and ph[2] == 1 and ph[3] >= 2:
                table = self.sfdp(int.from_bytes(ph[4:7], 'little'), min(64, ph[3]*4))
                break
        if table is None:
            raise ValueError('SFDP flash table not found.')
        first, density = struct.unpack_from('<II', table)
        bits = (1 << (density & 0x7fffffff)) if density & 0x80000000 and (density & 0x7fffffff) < 63 else (density + 1 if not density & 0x80000000 else 0)
        if bits != SIZE*8 or ((first >> 17) & 3) > 1:
            raise ValueError('Expected 16 MiB and three-byte flash addressing.')
        self.table = table
        return {'chip':'V821', 'jedec':jedec.hex(), 'bytes':SIZE, 'status1':sr1, 'flash_write_commands':False}

    def writable(self):
        self.probe()
        a, b, c = [self.status_register(i) for i in (5, 0x35, 0x15)]
        if a & 0xfd or b & 0x40 or c & 4 or not self.table[0] & 1 or self.table[1] != 0x20:
            raise ValueError('Flash is protected or 4 KiB erase is unavailable. Protection will not be changed.')

    def read_range(self, address, length):
        if address < 0 or length < 0 or address+length > SIZE:
            raise ValueError('Read range is outside flash.')
        result = bytearray()
        while len(result) < length:
            count = min(65536, length-len(result))
            result.extend(self.read_command(b'\x03' + (address+len(result)).to_bytes(3,'big'), count))
        return bytes(result)

def valid_write(command):
    if len(command) == 1:
        return command[0] in (4, 6)
    if len(command) < 4:
        return False
    address = int.from_bytes(command[1:4], 'big')
    if not START <= address < END:
        return False
    if command[0] == 0x20:
        return len(command) == 4 and address % 4096 == 0 and address+4096 <= END
    return command[0] == 2 and 4 < len(command) <= 260 and address % 256 == 0 and address+len(command)-4 <= END

def reader(action, destination=None):
    with USB(FEL_ID) as usb:
        device = FEL(usb)
        if action == 'version':
            return 'AWUSBFEX ID=0x00188200(V821)\n'
        data = device.probe()
        if action == 'probe':
            return json.dumps(data)+'\n'
        if action != 'read' or destination is None:
            raise ValueError('Unknown read operation.')
        with Path(destination).open('xb') as output:
            for address in range(0, SIZE, 65536):
                output.write(device.read_range(address, 65536))
        return 'READ_OK bytes='+str(SIZE)+'\n'
