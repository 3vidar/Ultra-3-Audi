"""WinUSB transport restricted to the two V8 USB identities."""
from contextlib import suppress

FEL_ID = (0x1f3a, 0xefe8)
ADB_ID = (0x18d1, 0xd002)

def backend():
    import libusb_package
    value = libusb_package.get_libusb1_backend()
    if value is None or libusb_package.get_library_path() is None:
        raise ValueError('USB library unavailable. Run Start-Windows.cmd again.')
    return value

class USB:
    def __init__(self, identity):
        import usb.core
        import usb.util
        self.device = None
        self.interface = None
        self.adb = identity == ADB_ID
        if identity not in (FEL_ID, ADB_ID):
            raise ValueError('USB identity is not allowed.')
        try:
            devices = list(usb.core.find(find_all=True, idVendor=identity[0], idProduct=identity[1], backend=backend()))
            if len(devices) != 1:
                raise ValueError('Connect exactly one matching dongle. Check its WinUSB driver in Zadig.')
            self.device = devices[0]
            if identity == ADB_ID and self.device.serial_number != 'V821-Audi-USB':
                raise ValueError('Unexpected USB diagnostic serial number.')
            try:
                cfg = self.device.get_active_configuration()
            except usb.core.USBError:
                self.device.set_configuration()
                cfg = self.device.get_active_configuration()
            choices = []
            for interface in cfg:
                if identity == ADB_ID and (interface.bInterfaceClass, interface.bInterfaceSubClass, interface.bInterfaceProtocol) != (255, 66, 1):
                    continue
                if identity == FEL_ID and interface.bInterfaceNumber != 0:
                    continue
                ins, outs = [], []
                for ep in interface:
                    if ep.bmAttributes & 3 == 2:
                        (ins if ep.bEndpointAddress & 128 else outs).append(ep)
                if len(ins) == len(outs) == 1:
                    choices.append((interface.bInterfaceNumber, interface.bAlternateSetting, ins[0], outs[0]))
            if len(choices) != 1 or choices[0][1] != 0:
                raise ValueError('Unexpected USB interface layout.')
            self.interface, _, epin, epout = choices[0]
            self.epin, self.epout = epin.bEndpointAddress, epout.bEndpointAddress
            self.packet_size = epout.wMaxPacketSize
            if self.packet_size not in (8,16,32,64,512,1024):
                raise ValueError('Unexpected USB bulk packet size.')
            usb.util.claim_interface(self.device, self.interface)
        except Exception as error:
            self.close()
            raise ValueError('USB access failed. Select this dongle in Zadig and install WinUSB. ' + str(error)) from error

    def write(self, data):
        data = bytes(data)
        length = len(data)
        while data:
            count = self.device.write(self.epout, data[:131072], timeout=10000)
            if count <= 0 or count > min(len(data), 131072):
                raise ValueError('Incomplete USB write.')
            data = data[count:]
        # FunctionFS reads do not derive transfer boundaries from ADB headers.
        # A full final bulk packet therefore needs an explicit short terminator.
        if self.adb and length and length % self.packet_size == 0:
            if self.device.write(self.epout, b'', timeout=10000) != 0:
                raise ValueError('USB zero-length packet failed.')

    def read(self, size):
        result = bytearray()
        while len(result) < size:
            block = bytes(self.device.read(self.epin, size - len(result), timeout=10000))
            if not block or len(block) > size-len(result):
                raise ValueError('Incomplete USB read.')
            result.extend(block)
        return bytes(result)

    def close(self):
        if self.device is not None:
            import usb.util
            with suppress(Exception):
                if self.interface is not None:
                    usb.util.release_interface(self.device, self.interface)
            with suppress(Exception):
                usb.util.dispose_resources(self.device)
            self.device = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
