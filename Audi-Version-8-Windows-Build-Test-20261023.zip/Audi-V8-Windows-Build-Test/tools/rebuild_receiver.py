"""Build a version-locked RX-gap extension for the verified receiver library."""
from pathlib import Path
import hashlib,io,json,struct,sys
from elftools.elf.elffile import ELFFile
HERE=Path(__file__).resolve().parent
ORIGINAL=None
OUTPUT=None
SHA='556c306b0bbe538377426df470a8648a29513bb2d1c78f16e7b9a79d07dfbfac'
SITE=0x39cf2;CAVE=0x60ba0;FALSE=0x3a646;MODES=0x39cf6;REPLY=0x3a50c;CLEANUP=0x3a602

def jal(rd,pc,target):
 off=target-pc
 assert off%2==0 and -(1<<20)<=off<(1<<20)
 u=off&0x1fffff
 return ((u>>20)<<31)|(((u>>1)&0x3ff)<<21)|(((u>>11)&1)<<20)|(((u>>12)&0xff)<<12)|(rd<<7)|0x6f

def branch(rs1,rs2,kind,off):
 assert off%2==0 and -4096<=off<4096
 u=off&0x1fff
 return ((u>>12)<<31)|(((u>>5)&0x3f)<<25)|(rs2<<20)|(rs1<<15)|(kind<<12)|(((u>>1)&0xf)<<8)|(((u>>11)&1)<<7)|0x63

def addi(rd,rs,imm):
 assert -2048<=imm<2048
 return ((imm&0xfff)<<20)|(rs<<15)|(rd<<7)|0x13

def lw(rd,rs,imm):return ((imm&0xfff)<<20)|(rs<<15)|(2<<12)|(rd<<7)|3

def sw(rs,base,imm):return (((imm>>5)&0x7f)<<25)|(rs<<20)|(base<<15)|(2<<12)|((imm&31)<<7)|0x23

class Program:
 def __init__(self):self.code=[];self.labels={};self.fixes=[]
 @property
 def pc(self):return CAVE+4*len(self.code)
 def emit(self,n):self.code.append(n)
 def label(self,n):self.labels[n]=self.pc
 def jump(self,target,rd=0):
  if isinstance(target,str):self.fixes.append((len(self.code),'jal',rd,target));self.emit(0)
  else:self.emit(jal(rd,self.pc,target))
 def cond(self,rs,kind,label):self.fixes.append((len(self.code),'branch',rs,kind,label));self.emit(0)
 def addr(self,rd,target):
  if isinstance(target,str):self.fixes.append((len(self.code),'addr',rd,target));self.emit(0);self.emit(0)
  else:self._addr(rd,target)
 def _addr(self,rd,target):
  delta=target-self.pc;hi=(delta+0x800)>>12;lo=delta-(hi<<12)
  self.emit(((hi&0xfffff)<<12)|(rd<<7)|0x17);self.emit(addi(rd,rd,lo))
 def finish(self):
  for f in self.fixes:
   i,kind,*args=f;pc=CAVE+i*4
   if kind=='jal':rd,t=args;self.code[i]=jal(rd,pc,self.labels[t])
   elif kind=='branch':rs,k,t=args;self.code[i]=branch(rs,0,k,self.labels[t]-pc)
   else:
    rd,t=args;delta=self.labels[t]-pc;hi=(delta+0x800)>>12;lo=delta-(hi<<12)
    self.code[i]=((hi&0xfffff)<<12)|(rd<<7)|0x17;self.code[i+1]=addi(rd,rd,lo)
  return b''.join(struct.pack('<I',x) for x in self.code)

def build():
 original=ORIGINAL.read_bytes();assert hashlib.sha256(original).hexdigest()==SHA
 assert original[SITE:SITE+4]==bytes.fromhex('e30a0514')
 e=ELFFile(io.BytesIO(original));loads=[(i,s) for i,s in enumerate(e.iter_segments()) if s['p_type']=='PT_LOAD']
 index,rx=next((i,s) for i,s in loads if s['p_flags']==5)
 nextfile=min(s['p_offset'] for i,s in loads if s['p_offset']>rx['p_offset'])
 assert rx['p_offset']==0 and rx['p_vaddr']==0 and rx['p_filesz']==rx['p_memsz']==0x60b9c
 assert nextfile==0x60f18 and not any(original[rx['p_filesz']:nextfile])
 for s in e.iter_sections():
  if s['sh_type']!='SHT_NOBITS' and s['sh_size']:
   assert not (s['sh_offset']<nextfile and s['sh_offset']+s['sh_size']>rx['p_filesz'])
 p=Program()
 p.cond(10,1,'modes')                 # original comparison succeeded
 p.emit(addi(10,23,0));p.addr(11,'zoom');p.jump(0x87ec,1)
 p.cond(10,0,'unknown')
 p.emit(lw(15,8,0x30));p.cond(15,0,'no_callback')
 p.emit(lw(14,8,0x50));p.emit(lw(11,20,0x4a8));p.emit(lw(10,20,0x49c))
 p.emit(addi(13,2,0x1f8));p.emit(addi(12,2,0x500));p.emit((15<<15)|(1<<7)|0x67)
 p.emit(sw(10,2,0x1ec));p.cond(10,1,'error')
 p.emit(lw(11,2,0x1f8));p.cond(11,0,'empty_reply');p.jump(REPLY)
 p.label('no_callback');p.label('empty_reply');p.emit(addi(10,0,-50));p.emit(sw(10,2,0x1ec))
 p.label('error');p.emit(addi(9,0,0));p.jump(CLEANUP)
 p.label('modes');p.jump(MODES)
 p.label('unknown');p.jump(FALSE)
 p.label('zoom');blob=p.finish()+bytes.fromhex('56070100ffffff7f')+b'changeMapZoomLevel\0'
 assert CAVE+len(blob)<=nextfile
 modified=bytearray(original);modified[SITE:SITE+4]=struct.pack('<I',jal(0,SITE,CAVE));modified[CAVE:CAVE+len(blob)]=blob
 ph=e.header['e_phoff']+index*e.header['e_phentsize'];newsize=CAVE+len(blob)
 struct.pack_into('<II',modified,ph+16,newsize,newsize)
 OUTPUT.mkdir(parents=True,exist_ok=True)
 out=OUTPUT/'librcarplay-patched.so';out.write_bytes(modified)
 for name,at,n in [('receiver-header.bin',100,8),('receiver-jump.bin',SITE,4),('receiver-stub.bin',CAVE,len(blob))]:
  (OUTPUT/name).write_bytes(modified[at:at+n])
 ranges=[];start=None
 for i,(a,b) in enumerate(zip(original,modified)):
  if a!=b and start is None:start=i
  if a==b and start is not None:ranges.append([start,i]);start=None
 if start is not None:ranges.append([start,len(modified)])
 report=dict(original_sha256=SHA,patched_sha256=hashlib.sha256(modified).hexdigest(),bytes=len(modified),site=SITE,cave=CAVE,stub_bytes=len(blob),labels=p.labels,changed_ranges=ranges,rx_new_filesz=newsize,normal_changeModes_preserved=True,zoom_skips_mode_parser=True,persistent_install_performed=False,vehicle_tested=False)
 (OUTPUT/'receiver-build.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--original',required=True);p.add_argument('--output',required=True);a=p.parse_args()
 ORIGINAL=Path(a.original).resolve();OUTPUT=Path(a.output).resolve()
 if OUTPUT.exists():raise SystemExit('Output must be new; do not overwrite original libraries.')
 build()
