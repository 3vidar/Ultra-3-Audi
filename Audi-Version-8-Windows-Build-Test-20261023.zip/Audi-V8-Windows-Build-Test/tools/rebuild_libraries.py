"""Developer build only. Rebuilt bytes require new hash pins/native validation."""
from pathlib import Path
import argparse
import json
import os
import subprocess
from common import PROJECT, sha

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--zig',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    out=Path(a.output).resolve()
    if out.exists():raise SystemExit('Output must be a new directory.')
    out.mkdir(parents=True)
    env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(out/'cache'),ZIG_LOCAL_CACHE_DIR=str(out/'local-cache'))
    files={}
    for name,source in [('libaudi_zoom.so','zoom_bridge.c'),('libaudi_navigation.so','navigation.c'),('libaudi_knob_k1.so','knob.c')]:
        cmd=[str(Path(a.zig).resolve()),'cc','-target','riscv32-linux-musl','-mcpu=generic_rv32+m+a+f+d+c',
             '-mabi=ilp32d','-Os','-shared','-fPIC','-Wl,-soname,'+name,str(PROJECT/'src'/source),'-o',str(out/name)]
        subprocess.run(cmd,env=env,check=True);files[name]=sha((out/name).read_bytes())
    (out/'build.json').write_text(json.dumps({'files':files,'native_tests_performed':False,'release_hashes_require_review':True},indent=2)+'\n')
    print(json.dumps(files,indent=2))
