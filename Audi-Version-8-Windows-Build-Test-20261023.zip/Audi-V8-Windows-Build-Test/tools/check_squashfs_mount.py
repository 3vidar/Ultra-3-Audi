"""Check the SquashFS mount-time table bounds used by the Linux driver.

This is a static check, not a live kernel mount or a dongle boot test.
Sources: Linux fs/squashfs/{super,id,export,fragment}.c. Also check the
stricter exact index lengths present in newer versions, plus metadata/data
block read bounds. The first version was readable by dissect.squashfs but
failed the kernel's fragment-index order check.
"""
import struct


def check_mount_layout(image, strict_id_end=False):
    def need(condition, explanation):
        if not condition:
            raise ValueError(explanation)

    def u16(at): return struct.unpack_from('<H', image, at)[0]
    def u32(at): return struct.unpack_from('<I', image, at)[0]
    def u64(at): return struct.unpack_from('<Q', image, at)[0]
    used = u64(40)
    block_size, block_log = u32(12), u16(22)
    need(u32(0) == 0x73717368 and u16(28) == 4 and u16(30) == 0, 'SquashFS version/magic')
    need(96 <= used <= len(image), 'filesystem size')
    need(4096 <= block_size <= 1048576 and block_size == 1 << block_log, 'block size/log')
    need((u64(32) & 0xffff) <= 8192, 'root inode offset')
    need(u64(56) == 0xffffffffffffffff, 'this check only supports images without xattrs')

    def index(name, start, count, entry_bytes, next_table, exact):
        need(count > 0, name + ' count is zero')
        length = ((count * entry_bytes + 8191) // 8192) * 8
        need(start <= next_table and length <= next_table - start,
             f'{name} index extends past next table: {start:#x}+{length:#x}>{next_table:#x}')
        if exact:
            need(start + length == next_table, name + ' index is not adjacent to next table')
        need(start + length <= used, name + ' index outside filesystem')
        pointers = [u64(start + i) for i in range(0, length, 8)]
        for i, at in enumerate(pointers):
            end = pointers[i + 1] if i + 1 < len(pointers) else start
            need(96 <= at < end <= used and end - at <= 8194, name + ' metadata pointers')
            stored = u16(at) & 0x7fff
            need(0 < stored <= 8192 and at + 2 + stored <= end, name + ' metadata block bounds')
        return pointers

    ids = index('id', u64(48), u16(26), 4, used, strict_id_end)
    next_table = ids[0]
    if u64(88) != 0xffffffffffffffff:
        lookups = index('lookup', u64(88), u32(4), 8, next_table, True)
        next_table = lookups[0]
    fragments = []
    if u32(16):
        fragments = index('fragment', u64(80), u32(16), 16, next_table, False)
        next_table = fragments[0]
    need(u64(72) <= next_table, 'directory table starts past fragment metadata')
    need(96 <= u64(64) < u64(72), 'inode/directory table order')
    return {'mount_table_bounds_pass': True, 'bytes_used': used,
            'id_metadata': ids, 'fragment_metadata': fragments,
            'live_kernel_mount_tested': False}
