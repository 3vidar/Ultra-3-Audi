"""Produce a small report without raw dumps, identifiers, keys or local paths."""
from pathlib import Path
import argparse
import json
from common import REFERENCE, profile

def export(path, output):
    d, data = profile(path)
    report = {'release': REFERENCE['release'], 'software': 'own-backup V8 Build Test',
              'expected_hardware': REFERENCE['hardware'], 'build_number_checked': False,
              'required_api_files_match': True,
              'target_root_sha256': data['expected']['target_root_sha256'],
              'runtime_manifest_sha256': data['expected']['runtime_manifest_sha256'],
              'physical_second_device_validation': 'pilot; tester must supply vehicle results',
              'flash_runs': [], 'activation_runs': []}
    for p in sorted(d.glob('*/result.json')):
        value = json.loads(p.read_text())
        if 'flash_verified' in value:
            report['flash_runs'].append({'mode': value.get('mode') if value.get('mode') in ('install', 'restore') else 'unknown',
                                        'flash_verified': value.get('flash_verified') is True,
                                        'error_recorded': 'error' in value})
        elif 'actual_root_boot_verified' in value:
            report['activation_runs'].append({key: value.get(key) is True for key in
                                             ('actual_root_boot_verified', 'runtime_installed', 'runtime_bytes_pulled_and_verified', 'vehicle_mode_enabled')})
    output = Path(output)
    if output.exists():
        raise ValueError('Berichtsdatei existiert bereits; wird nicht überschrieben.')
    with output.open('x', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False); f.write('\n')
    return report

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('profile'); p.add_argument('--output', required=True, type=Path); a = p.parse_args()
    export(a.profile, a.output)
    print('Anonymisierter technischer Bericht geschrieben. Vor dem Teilen selbst lesen; Fahrzeugtest separat ergänzen.')
