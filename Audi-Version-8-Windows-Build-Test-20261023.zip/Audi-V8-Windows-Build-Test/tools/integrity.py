"""Verify the distributed source/payload file list before device operations."""
from pathlib import Path, PurePosixPath
import hashlib
import re

ROOT = Path(__file__).resolve().parents[1]

def verify_release(root=ROOT):
    root = Path(root).resolve()
    manifest = root / 'SHA256SUMS'
    if not manifest.is_file() or manifest.is_symlink():
        raise ValueError('Missing SHA256SUMS. Extract the complete ZIP.')
    names = set()
    for line in manifest.read_text(encoding='utf-8').splitlines():
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
        if not match:
            raise ValueError('Invalid installer checksum list.')
        expected, name = match.groups()
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or '\\' in name or name in names:
            raise ValueError('Invalid installer file path.')
        names.add(name)
        p = root.joinpath(*path.parts)
        if p.is_symlink() or not p.is_file() or not p.resolve().is_relative_to(root):
            raise ValueError('Installer file missing or linked: ' + name)
        if hashlib.sha256(p.read_bytes()).hexdigest() != expected:
            raise ValueError('Installer file modified: ' + name)
    if not {'reference.json', 'installer.py', 'tools/prepare.py', 'tools/activate.py'} <= names:
        raise ValueError('Incomplete installer checksum list.')
    return len(names)

if __name__ == '__main__':
    print('RELEASE_OK files=' + str(verify_release()))
