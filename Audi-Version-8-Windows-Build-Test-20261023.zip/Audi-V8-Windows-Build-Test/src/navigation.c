#define _GNU_SOURCE
#include <dlfcn.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <time.h>
#include <errno.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/file.h>

/* Public APIs of the exact ly6238 native libraries, checked against their
 * original offsets. The successful V4 zoom library remains separate. */
#define ROOT "/mnt/UDISK/audi-zoom6238"
#define STREAM_MAX 8192
#define CAPTURE_MAX 4096
#define RGD_REJECT_MASK 0x01000000u
typedef int (*raw_callback)(const void *,unsigned);
typedef int (*send_api)(void *,const void *,unsigned);
struct stream {unsigned n;unsigned char data[STREAM_MAX];};
static struct {
 void *context;raw_callback original_callback;
 unsigned generation,attempts,unit_ms;
 uint64_t epoch_ms;
 unsigned tx,rx;uint16_t component;
 int have_hu,component_valid,pass_ready,stopped,got_rgd,armed,started,destroying,rejected;
 int native_mask_known;unsigned native_mask;
 struct stream decoded,link,link_control;
 int link_session,decoded_bare;
 unsigned counts[2][5],ident_counts[2][7],api_calls[5];
 int identify_saved,raw_input_saved;
} S={.link_session=-1};
static pthread_mutex_t lock;
static pthread_mutex_t send_lock;
static pthread_cond_t changed;
static pthread_once_t once=PTHREAD_ONCE_INIT;
static int worker_started;
static send_api real_send;
static uintptr_t native_base;
static unsigned native_calls;
static void *pending_context;
static unsigned char pending[4096];static unsigned pending_len;
static unsigned be16(const unsigned char *p){return ((unsigned)p[0]<<8)|p[1];}
static void put16(unsigned char *p,unsigned n){p[0]=(unsigned char)(n>>8);p[1]=(unsigned char)n;}
static uint64_t now_ms(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000u+(unsigned)t.tv_nsec/1000000u;}
static void init(void){
 pthread_mutexattr_t a;pthread_mutexattr_init(&a);pthread_mutexattr_settype(&a,PTHREAD_MUTEX_RECURSIVE);pthread_mutex_init(&lock,&a);pthread_mutex_init(&send_lock,&a);pthread_mutexattr_destroy(&a);
 pthread_condattr_t c;pthread_condattr_init(&c);pthread_condattr_setclock(&c,CLOCK_MONOTONIC);pthread_cond_init(&changed,&c);pthread_condattr_destroy(&c);
 S.unit_ms=2000;const char *v=getenv("AUDI_NAV_TEST_DELAY_MS");
 if(v&&*v){char *end;long n=strtol(v,&end,10);if(!*end&&n>=5&&n<=2000)S.unit_ms=(unsigned)n;}
}
static void acquire(void){pthread_once(&once,init);pthread_mutex_lock(&lock);}
static void release(void){pthread_mutex_unlock(&lock);}
static int native_ready_locked(void *context);
static void inspect_native_mask_locked(void);
static void finish_native_locked(void){native_calls--;pthread_cond_broadcast(&changed);}
static int call_send_locked(void *context,const void *data,unsigned n,int constructed,unsigned generation){
 send_api f=real_send;if(!f)return -38;
 native_calls++;release();
 pthread_mutex_lock(&send_lock);
 int allowed=1;
 if(constructed){acquire();allowed=S.context==context&&S.generation==generation&&S.armed&&!S.stopped&&!S.destroying&&!S.rejected&&S.pass_ready&&S.original_callback&&S.have_hu&&S.component_valid&&(S.tx&9)==9&&(S.rx&22)==22;
  if(allowed){inspect_native_mask_locked();allowed=!S.rejected&&native_ready_locked(context);}release();}
 int result=allowed?f(context,data,n):-125;pthread_mutex_unlock(&send_lock);
 acquire();finish_native_locked();return result;
}
static void event(const char *kind,int value,unsigned len){
 const char *path=getenv("AUDI_NAV_LOG");if(!path)path=ROOT "/navigation.log";
 struct stat st;if(!stat(path,&st)&&st.st_size>=65536)return;
 FILE *f=fopen(path,"a");if(f){fprintf(f,"pid=%ld gen=%u %s value=%d bytes=%u\n",(long)getpid(),S.generation,kind,value,len);fclose(f);}
}
static int sample(unsigned n){return n==1||n==2||(n&&(n&(n-1))==0);}
static void api_event(unsigned index,const char *kind,const void *data,unsigned n){
 if(sample(++S.api_calls[index])){
  event(kind,(int)S.api_calls[index],n);
  if(data&&n){char detail[80];const unsigned char *p=data;unsigned at=0,limit=n<12?n:12;
   at+=(unsigned)snprintf(detail+at,sizeof detail-at,"%s-head-",kind);
   for(unsigned i=0;i<limit&&at+3<sizeof detail;i++)at+=(unsigned)snprintf(detail+at,sizeof detail-at,"%02x",p[i]);
   event(detail,0,n);
  }
 }
}
static void capture(const char *name,const void *data,unsigned n){
 if(!data||!n||n>CAPTURE_MAX){if(n>CAPTURE_MAX)event("capture-too-large",0,n);return;}
 const char *dir=getenv("AUDI_NAV_CAPTURE_DIR");if(!dir)dir=ROOT;
 char path[192];if(snprintf(path,sizeof path,"%s/%s",dir,name)>=(int)sizeof path)return;
 char quota_lock[192];if(snprintf(quota_lock,sizeof quota_lock,"%s/.navigation-capture.lock",dir)>=(int)sizeof quota_lock)return;
 int fd=open(quota_lock,O_WRONLY|O_CREAT,0600);if(fd<0)return;
 if(flock(fd,LOCK_EX)){close(fd);return;}
 unsigned total=0;DIR *d=opendir(dir);struct dirent *e;
 if(d){while((e=readdir(d))){if(strncmp(e->d_name,"first-rgd-",10)&&strncmp(e->d_name,"first-ident-",12)&&strcmp(e->d_name,"first-phone-wifi-input.bin")&&strcmp(e->d_name,"first-phone-wifi-input.bin.meta"))continue;
   char existing[384];struct stat st;if(snprintf(existing,sizeof existing,"%s/%s",dir,e->d_name)<(int)sizeof existing&&!stat(existing,&st)&&S_ISREG(st.st_mode)&&st.st_size>0){
    if((uint64_t)st.st_size>32768u||total>32768u-(unsigned)st.st_size){total=32769;break;}total+=(unsigned)st.st_size;}}
  closedir(d);
 }
 struct stat old;unsigned previous=(!stat(path,&old)&&S_ISREG(old.st_mode)&&old.st_size>=0&&old.st_size<=32768)?(unsigned)old.st_size:0;
 if(total>32768||total<previous||total-previous+n+128>32768){flock(fd,LOCK_UN);close(fd);event("capture-quota-retained-old-file",0,n);return;}
 FILE *f=fopen(path,"wb");if(f){fwrite(data,1,n,f);fclose(f);
  char meta[208];if(snprintf(meta,sizeof meta,"%s.meta",path)<(int)sizeof meta){f=fopen(meta,"w");if(f){fprintf(f,"pid=%ld generation=%u bytes=%u monotonic_ms=%llu\n",(long)getpid(),S.generation,n,(unsigned long long)now_ms());fclose(f);}}}
 flock(fd,LOCK_UN);close(fd);
}
static void *resolve(const char *name,unsigned offset,const char *library){
 void *f=dlsym(RTLD_NEXT,name);Dl_info i;
 if(!f||!dladdr(f,&i)||!i.dli_fname||!strstr(i.dli_fname,library)||(uintptr_t)f-(uintptr_t)i.dli_fbase!=offset){event("identity-rejected",(int)offset,0);return NULL;}
 if(!strcmp(library,"libiap_new.so"))native_base=(uintptr_t)i.dli_fbase;
 return f;
}
static int valid_tlvs(const unsigned char *p,unsigned n){
 unsigned at=0;while(at<n){if(n-at<4)return 0;unsigned z=be16(p+at);if(z<4||z>n-at)return 0;at+=z;}return at==n;
}
static const unsigned char *control(const void *data,unsigned n,unsigned *length){
 const unsigned char *p=data;if(!p)return NULL;
 if(n&&p[0]==0){p++;n--;}
 if(n<6||p[0]!=0x40||p[1]!=0x40||be16(p+2)!=n||!valid_tlvs(p+6,n-6))return NULL;
 *length=n;return p;
}
static int component_matches(const unsigned char *p,unsigned n){
 for(unsigned at=6;at<n;){unsigned z=be16(p+at),id=be16(p+at+2);
  if(id==0&&z>=6&&((z-4)&1)==0)for(unsigned q=at+4;q+1<at+z;q+=2)if(be16(p+q)==S.component)return 1;
  at+=z;
 }return 0;
}
static void cancel_locked(const char *reason){
 if(S.armed)event(reason,(int)S.attempts,0);
 S.armed=0;pthread_cond_broadcast(&changed);
}
static void adopt_locked(void *context){
 if(S.context==context)return;
 S.context=context;S.original_callback=NULL;S.generation++;
 S.have_hu=S.component_valid=S.pass_ready=S.stopped=S.got_rgd=S.armed=S.started=S.destroying=S.rejected=0;
 S.attempts=S.tx=S.rx=S.component=0;S.native_mask_known=0;S.native_mask=0;
 S.decoded.n=S.link.n=S.link_control.n=0;S.link_session=-1;S.decoded_bare=0;
 memset(S.counts,0,sizeof S.counts);memset(S.ident_counts,0,sizeof S.ident_counts);
 S.identify_saved=S.raw_input_saved=0;pthread_cond_broadcast(&changed);
 pending_context=NULL;pending_len=0;
}
static int native_ready_locked(void *context){
 if(!context||S.destroying)return 0;
 void *inner=*(void**)context;return inner&&*(unsigned*)((char*)inner+0x144)!=0;
}
static void inspect_native_mask_locked(void){
 /* Verified getter and native back-reference; observe only, never clear a
  * rejection or change the native Identification structure. Fake CPU-test
  * objects with no Controlsession simply have no mask to inspect. */
 if(!native_base||!S.context||S.destroying)return;
 void *inner=*(void**)S.context;if(!inner)return;
 void *ctrl=*(void**)((char*)inner+0x104);if(!ctrl||*(void**)ctrl!=inner)return;
 static const unsigned char expected[]={0x97,0xf7,0,0,0x83,0xa7,0xc7,0x66,0xcc,0x43,0x6f,0xf0,0x6f,0xf0};
 void *fn=(void*)(native_base+0x1134c);
 if(memcmp(fn,expected,sizeof expected)){event("identify-getter-rejected",0,0);return;}
 void *ident=((void*(*)(void*))fn)(ctrl);if(!ident)return;
 unsigned mask=*(unsigned*)((char*)ident+0xc);
 if(!S.native_mask_known||mask!=S.native_mask)event("native-identification-reject-mask",(int)mask,0);
 S.native_mask_known=1;S.native_mask=mask;
 if(mask&RGD_REJECT_MASK){S.rejected=1;cancel_locked("native-rgd-rejection-stops-subscription");}
}
static void observed_frame_locked(const char *kind,int phone,const unsigned char *p,unsigned n){
 if(n<6||be16(p+2)!=n||!valid_tlvs(p+6,n-6)){event("control-frame-invalid",0,n);return;}
 unsigned id=be16(p+4);char name[80];
 if(id>=0x5200&&id<=0x5204){
  unsigned count=++S.counts[phone!=0][id-0x5200];if(sample(count))event(kind,(int)id,n);
  if(count==1){snprintf(name,sizeof name,"first-rgd-%s-%04x.bin",phone?"phone":"hu",id);capture(name,p,n);}
  if(phone&&S.component_valid&&(id==0x5201||id==0x5202||id==0x5204)&&component_matches(p,n)){
   if(!S.got_rgd)event("matching-phone-route-guidance",(int)id,n);
   S.got_rgd=1;cancel_locked("phone-route-guidance-stops-retries");
  }
 }else if(id>=0x1d00&&id<=0x1d06){
  unsigned count=++S.ident_counts[phone!=0][id-0x1d00];if(sample(count))event(kind,(int)id,n);
  if(count==1){snprintf(name,sizeof name,"first-ident-%s-%04x.bin",phone?"phone":"hu",id);capture(name,p,n);}
  if(phone&&id==0x1d03){
   for(unsigned at=6;at<n;){unsigned z=be16(p+at);if(be16(p+at+2)==0x1e){S.rejected=1;event("phone-explicitly-rejected-rgd",0x1e,n);cancel_locked("phone-rejection-stops-subscription");}at+=z;}
  }
 }
}
static void observe_locked(const char *kind,int phone,const void *data,unsigned n){unsigned z=0;const unsigned char *p=control(data,n,&z);if(p)observed_frame_locked(kind,phone,p,z);}
static void feed_control_locked(struct stream *s,const unsigned char *p,unsigned n,const char *kind,int phone);
static void process_link_packet_locked(const unsigned char *p,unsigned n){
 unsigned sum=0;for(unsigned i=0;i<9;i++)sum+=p[i];if((sum&255)!=0){event("link-header-checksum-invalid",0,n);return;}
 unsigned z=n-9;if(!z)return;if(z<2){event("link-payload-too-small",0,n);return;}
 sum=0;for(unsigned i=9;i<n;i++)sum+=p[i];if((sum&255)!=0){event("link-payload-checksum-invalid",0,n);return;}
 unsigned session=p[7];const unsigned char *body=p+9;z--;
 if(z>=2&&body[0]==0x40&&body[1]==0x40){if(S.link_session!=(int)session)S.link_control.n=0;S.link_session=(int)session;}
 if(S.link_session==(int)session)feed_control_locked(&S.link_control,body,z,"phone-link-control",1);
}
static void feed_locked(struct stream *s,const unsigned char *p,unsigned n,const char *kind,int phone,int link){
 const unsigned char first=link?0xff:0x40,second=link?0x5a:0x40;
 while(n){
  unsigned room=STREAM_MAX-s->n;if(!room){event("stream-overflow-reset",link,s->n);s->n=0;room=STREAM_MAX;}
  unsigned take=n<room?n:room;memcpy(s->data+s->n,p,take);s->n+=take;p+=take;n-=take;
  unsigned at=0;
  while(s->n-at>=2){
   if(s->data[at]!=first||s->data[at+1]!=second){at++;continue;}
   if(s->n-at<4)break;
   unsigned z=be16(s->data+at+2);if(z<(link?9u:6u)||z>STREAM_MAX){event("stream-frame-length-rejected",link,z);at++;continue;}
   if(s->n-at<z)break;
   if(link)process_link_packet_locked(s->data+at,z);
   else observed_frame_locked(kind,phone,s->data+at,z);
   at+=z;
  }
  if(at){memmove(s->data,s->data+at,s->n-at);s->n-=at;}
 }
}
static void feed_control_locked(struct stream *s,const unsigned char *p,unsigned n,const char *kind,int phone){feed_locked(s,p,n,kind,phone,0);}
static void *worker(void *unused);
static void maybe_arm_locked(void){
 if(S.started||S.stopped||S.got_rgd||S.destroying||!S.have_hu||!S.component_valid||(S.tx&9)!=9||(S.rx&22)!=22||!S.pass_ready||!S.original_callback||!native_ready_locked(S.context))return;
 inspect_native_mask_locked();if(S.rejected)return;
 if(!worker_started){pthread_t t;int e=pthread_create(&t,NULL,worker,NULL);if(e){event("subscription-worker-failed",e,0);return;}pthread_detach(t);worker_started=1;}
 S.started=S.armed=1;S.attempts=0;S.epoch_ms=now_ms();event("bounded-native-subscription-armed",S.component,25);pthread_cond_broadcast(&changed);
}
static void *worker(void *unused){
 (void)unused;static const unsigned schedule[]={1,2,3,4,5,15,30};
 acquire();
 for(;;){
  while(!S.armed||S.attempts>=7)pthread_cond_wait(&changed,&lock);
  uint64_t due=S.epoch_ms+(uint64_t)schedule[S.attempts]*S.unit_ms,t=now_ms();
  if(t<due){struct timespec deadline={(time_t)(due/1000u),(long)((due%1000u)*1000000u)};pthread_cond_timedwait(&changed,&lock,&deadline);continue;}
  if(S.destroying||!S.pass_ready||!S.original_callback||S.stopped||S.got_rgd||S.rejected||!S.have_hu||!S.component_valid||(S.tx&9)!=9||(S.rx&22)!=22||!native_ready_locked(S.context)){cancel_locked("subscription-no-longer-ready");continue;}
  inspect_native_mask_locked();if(S.rejected)continue;
  if(!real_send)real_send=resolve("SendiAPRawDataToHS",0x90a8,"libiap_new.so");
  unsigned char frame[]={0,0x40,0x40,0,24,0x52,0,0,6,0,0,0,0,0,4,0,1,0,4,0,2,0,4,0,3};
  put16(frame+11,S.component);S.attempts++;
  /* Admission leases prevent Destroy from freeing a native call's context.
   * No state mutex remains held across native code or its callbacks. */
  unsigned attempt=S.attempts,generation=S.generation;void *context=S.context;
  int result=call_send_locked(context,frame,sizeof frame,1,generation);
  if(S.context!=context||S.generation!=generation)continue;
  event("native-subscription-attempt",(int)attempt,sizeof frame);event("native-subscription-result",result,sizeof frame);
  if(S.attempts==7)cancel_locked("subscription-seven-attempt-limit");
 }
 return NULL;
}
static int decoded_callback(const void *data,unsigned n){
 acquire();raw_callback original=S.original_callback;
 api_event(4,"decoded-phone-callback",data,n);
 const unsigned char *p=data;
 if(p&&n){
  if(S.decoded.n&&S.decoded_bare)feed_control_locked(&S.decoded,p,n,"phone-decoded-control",1);
  else if(p[0]==0){S.decoded_bare=0;feed_control_locked(&S.decoded,p+1,n-1,"phone-decoded-control",1);}
  else if(p[0]==0x40&&(n==1||p[1]==0x40)){S.decoded_bare=1;feed_control_locked(&S.decoded,p,n,"phone-decoded-control",1);}
  if(!S.decoded.n)S.decoded_bare=0;
 }
 release();
 return original?original(data,n):-38;
}
int SendiAPRawDataToHS(void *context,const void *data,unsigned n){
 acquire();if(S.destroying){release();return -108;}
 if(!S.context)adopt_locked(context);
 if(!real_send)real_send=resolve("SendiAPRawDataToHS",0x90a8,"libiap_new.so");
 if(!real_send){release();return -38;}
 api_event(0,"hu-raw-send",data,n);unsigned z=0;const unsigned char *p=control(data,n,&z);unsigned id=p?be16(p+4):0;
 observe_locked("hu-to-phone",0,data,n);
 if(id==0x5203){pending_len=0;pending_context=NULL;S.stopped=1;cancel_locked("hu-stop-cancels-subscription");}
 else if(id==0x5200){
  S.started=1;cancel_locked("genuine-hu-start-suppresses-fallback");
  if(n<=sizeof pending&&!native_ready_locked(context)){memcpy(pending,data,n);pending_len=n;pending_context=context;event("start-deferred",(int)id,n);}
 }
 int result=call_send_locked(context,data,n,0,0);release();return result;
}
void SetiAP2OverWifiCPPassState(void *context,raw_callback callback,int pass){
 acquire();void(*actual)(void*,raw_callback,int)=resolve("SetiAP2OverWifiCPPassState",0x9024,"libiap_new.so");
 if(!actual||S.destroying){release();return;}
 adopt_locked(context);if(callback!=decoded_callback)S.original_callback=callback;
 raw_callback forwarded=callback?decoded_callback:NULL;
 int previously_ready=S.pass_ready;
 native_calls++;release();actual(context,forwarded,pass);acquire();finish_native_locked();
 if(S.destroying||S.context!=context){release();return;}
 S.pass_ready=pass&&native_ready_locked(context);
 event("pass-state",pass,0);
 if(!callback)cancel_locked("null-callback-cancels-subscription");
 if(!S.pass_ready){
  cancel_locked("disconnect-cancels-subscription");pending_len=0;pending_context=NULL;
  if(previously_ready){S.generation++;S.started=S.stopped=S.got_rgd=S.rejected=0;S.native_mask_known=0;S.native_mask=0;S.attempts=0;S.decoded.n=S.link.n=S.link_control.n=0;S.link_session=-1;S.decoded_bare=0;
   memset(S.counts,0,sizeof S.counts);memset(S.ident_counts,0,sizeof S.ident_counts);S.raw_input_saved=0;}
 }else{
  inspect_native_mask_locked();
  if(pending_context==context&&pending_len){unsigned char copy[4096];unsigned n=pending_len;memcpy(copy,pending,n);pending_len=0;pending_context=NULL;
   if(!real_send)real_send=resolve("SendiAPRawDataToHS",0x90a8,"libiap_new.so");int e=call_send_locked(context,copy,n,0,0);event("deferred-start-replayed",e,n);}
  maybe_arm_locked();
 }
 release();
}
void SetHUIdentInfoData(void *context,const void *data,unsigned n){
 acquire();void(*actual)(void*,const void*,unsigned)=resolve("SetHUIdentInfoData",0x90d0,"libiap_new.so");
 if(!actual||S.destroying){release();return;}
 adopt_locked(context);const unsigned char *p=data;
 if(p&&n>=4&&n<=STREAM_MAX&&valid_tlvs(p,n)){
  unsigned tx=0,rx=0;uint16_t component=0;int valid=0;
  for(unsigned at=0;at<n;){unsigned z=be16(p+at),id=be16(p+at+2);
   if(id==6||id==7)for(unsigned q=at+4;q+1<at+z;q+=2){unsigned m=be16(p+q);if(m>=0x5200&&m<=0x5204){if(id==6)tx|=1u<<(m-0x5200);else rx|=1u<<(m-0x5200);}}
   if(id==0x1e&&valid_tlvs(p+at+4,z-4))for(unsigned q=at+4;q<at+z;){unsigned inner=be16(p+q);if(be16(p+q+2)==0&&inner==6){component=(uint16_t)be16(p+q+4);valid=1;}q+=inner;}
   at+=z;
  }
  S.have_hu=1;S.component_valid=valid;S.component=component;S.tx=tx;S.rx=rx;
  event("hu-identification-component1e",valid?component:-1,n);event("hu-identification-rgd-tx",(int)tx,n);event("hu-identification-rgd-rx",(int)rx,n);
  const char *marker=getenv("AUDI_NAV_HU_MARKER");if(!marker)marker="/tmp/audi-hu-identified";
  FILE *f=fopen(marker,"w");if(f){fprintf(f,"valid HU identification %u\n",n);fclose(f);}
  if(!S.identify_saved){const char *path=getenv("AUDI_NAV_IDENT_CAPTURE");if(!path)path=ROOT "/hu-identification.bin";f=fopen(path,"wb");if(f){if(fwrite(p,1,n,f)==n)S.identify_saved=1;fclose(f);}}
  if(!valid||(tx&9)!=9||(rx&22)!=22)cancel_locked("hu-no-route-guidance-capability");
 }else{S.have_hu=S.component_valid=0;S.tx=S.rx=0;cancel_locked("invalid-hu-clears-route-guidance-caps");event("hu-identification-invalid",-50,n);}
 native_calls++;release();actual(context,data,n);acquire();finish_native_locked();maybe_arm_locked();release();
}
int WriteWiFiCPDataToiAP(void *context,const void *data,unsigned n){
 acquire();int(*actual)(void*,const void*,unsigned)=resolve("WriteWiFiCPDataToiAP",0x8d3c,"libiap_new.so");
 if(!actual||S.destroying){release();return -108;}
 if(!S.context)adopt_locked(context);api_event(1,"phone-wifi-input",data,n);
 if(!S.raw_input_saved&&data&&n){capture("first-phone-wifi-input.bin",data,n<CAPTURE_MAX?n:CAPTURE_MAX);S.raw_input_saved=1;}
 observe_locked("phone-to-iap",1,data,n);
 if(data&&n)feed_locked(&S.link,data,n,"phone-link-input",1,1);
 native_calls++;release();int result=actual(context,data,n);acquire();finish_native_locked();release();return result;
}
int WriteiAPDataToHu(const void *data,unsigned n,void *context){
 acquire();int(*actual)(const void*,unsigned,void*)=resolve("WriteiAPDataToHu",0x1288a,"libriap2.so");
 if(!actual){release();return -38;}api_event(2,"phone-wired-output",data,n);observe_locked("phone-to-hu",1,data,n);
 release();return actual(data,n,context);
}
int DestroyiAP2(void *context){
 acquire();int(*actual)(void*)=resolve("DestroyiAP2",0x921c,"libiap_new.so");if(!actual){release();return -38;}
 unsigned epoch=0;if(S.context==context){cancel_locked("destroy-cancels-subscription");S.destroying=1;S.pass_ready=0;epoch=++S.generation;}
 if(pending_context==context){pending_context=NULL;pending_len=0;}
 while(native_calls)pthread_cond_wait(&changed,&lock);
 release();
 /* Native Stop joins the link worker. Its final callbacks must be allowed to
  * take a snapshot and invoke the retained original without our lock. */
 int result=actual(context);
 acquire();if(S.context==context&&S.generation==epoch){S.original_callback=NULL;S.context=NULL;S.destroying=0;S.started=S.armed=0;S.decoded.n=S.link.n=S.link_control.n=0;}
 release();return result;
}
