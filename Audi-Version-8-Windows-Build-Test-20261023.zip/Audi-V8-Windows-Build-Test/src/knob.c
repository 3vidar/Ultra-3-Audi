#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <pthread.h>
#include "knob.h"

/* Only the SHA-bound ly6238 RV32 library is supported. No text patching. */
#define LIMIT 65536u
#define KEY(n,s) static const struct {uint64_t tag;char text[sizeof(s)];} n={UINT64_C(0x7fffffff00010756),s}
KEY(k_hids,"hidDevices"); KEY(k_uuid,"uuid"); KEY(k_pid,"hidProductID");
KEY(k_vid,"hidVendorID"); KEY(k_country,"hidCountryCode");
KEY(main_display,"e5f7a68d-7b0f-4305-984b-974f677a150b");
static pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;
static unsigned sequence;
static char paths[8][160]; /* Native code may retain the supplied filename. */
static K1API api;
static const unsigned char donor_flags[8]={0,1,0,0,1,1,1,1};
static int (*original)(const void *,const char *);
#ifdef HOST_TEST
void AudiK1HostInstall(const K1API *a,int (*forward)(const void *,const char *)){
 api=*a;original=forward;sequence=0;
}
#endif

int AudiK1Bind(void *symbol,K1API *a){
 Dl_info d;
 if(!symbol||!dladdr(symbol,&d)||(uintptr_t)symbol-(uintptr_t)d.dli_fbase!=0x1c628u)return -1;
 uintptr_t b=(uintptr_t)d.dli_fbase;
 /* These short entry signatures additionally reject unrelated mapped images. */
 static const unsigned char sig1[]={0x1d,0x71,0xa2,0xcc};
 static const unsigned char sig2[]={0xb7,0x07,0x09,0x08};
 if(memcmp(symbol,sig1,sizeof(sig1))||memcmp((void *)(b+0x27160),sig2,sizeof(sig2)))return -1;
 memset(a,0,sizeof(*a));
#define FN(field,offset) a->field=(__typeof__(a->field))(b+(offset))
 FN(decode,0x4e9e8);FN(get,0x71fc8);FN(equal,0x71a98);FN(release,0x71a94);
 FN(serialize,0x4e098);FN(type,0x71a68);FN(count,0x71b7c);FN(item,0x71b94);
 FN(copy_array,0x71b64);FN(set,0x71fdc);FN(build_descriptor,0x27160);FN(build_hid,0x3e1bc);
 FN(build_report,0x275b0);
#undef FN
 return 0;
}

/* API-injected for sanitizer tests; production and CPU tests use AudiK1Bind. */
int AudiK1Transform(K1API *a,const void *input,unsigned length,unsigned id,
                   void **output,unsigned *out_length,unsigned *old_count){
 CF root=NULL,array=NULL,copy=NULL,first=NULL,check=NULL;void *desc=NULL,*bytes=NULL;
 unsigned desc_len=0,n=0;int error=0,result=-1;
 *output=NULL;*out_length=0;*old_count=0;
 if(!input||length<40||length>LIMIT||memcmp(input,"bplist00",8)||id>255)return -1;
 root=a->decode(input,length,&error);if(!root||error)goto done;
 /* CFL type IDs are established by the known, independently checked fixture. */
 if(a->type(root)!=5)goto done;
 array=a->get(root,(CF)&k_hids);if(!array||a->type(array)!=1)goto done;
 int count=a->count(array);if(count<1||count>32)goto done;
 *old_count=(unsigned)count;
 first=a->item(array,0);if(!first||a->type(first)!=5)goto done;
 CF metadata[3]={a->get(first,(CF)&k_pid),a->get(first,(CF)&k_vid),a->get(first,(CF)&k_country)};
 for(unsigned i=0;i<3;i++)if(!metadata[i]||a->type(metadata[i])!=6)goto done;
 /* The extra UUID must match the ID used by this library's SendKnobEvent. */
 struct {uint64_t tag;char text[4];} uuid={UINT64_C(0x7fffffff00010756),{0}};
 snprintf(uuid.text,sizeof(uuid.text),"%X",id);
 for(int i=0;i<count;i++){
  CF item=a->item(array,i);if(!item||a->type(item)!=5)goto done;
  CF u=a->get(item,(CF)&k_uuid);
  if(u&&a->equal(u,(CF)&uuid)){result=1;goto done;} /* Preserve an existing ID. */
 }
 copy=a->copy_array(NULL,count+1,array);if(!copy||a->count(copy)!=count)goto done;
 if(a->build_descriptor(&desc,&desc_len,donor_flags)||!desc||desc_len<8||desc_len>2048)goto done;
 if(a->build_hid(&copy,id,"Knob",0x28,0x7e8,0,desc,desc_len,(CF)&main_display))goto done;
 if(a->count(copy)!=count+1||a->count(array)!=count)goto done;
 CF added=a->item(copy,count);if(!added||a->type(added)!=5)goto done;
 a->set(added,(CF)&k_pid,metadata[0]);a->set(added,(CF)&k_vid,metadata[1]);a->set(added,(CF)&k_country,metadata[2]);
 for(int i=0;i<count;i++)if(!a->equal(a->item(array,i),a->item(copy,i)))goto done;
 a->set(root,(CF)&k_hids,copy);
 bytes=a->serialize(root,&n,&error);if(!bytes||error||n<40||n>LIMIT)goto done;
 check=a->decode(bytes,n,&error);if(!check||error||!a->equal(root,check))goto done;
 *output=bytes;*out_length=n;bytes=NULL;result=0;
done:
 if(check)a->release(check);if(copy)a->release(copy);if(root)a->release(root);
 free(desc);free(bytes);return result;
}

int AudiK1Read(const char *path,void **out,unsigned *length){
 *out=NULL;*length=0;if(!path)return -1;
 FILE *f=fopen(path,"rb");if(!f)return -1;
 unsigned char h[4];void *p=NULL;int result=-1;
 if(fread(h,1,4,f)!=4)goto done;
 unsigned n=(unsigned)h[0]|(unsigned)h[1]<<8|(unsigned)h[2]<<16|(unsigned)h[3]<<24;
 if(n<40||n>LIMIT)goto done;
 p=malloc(n);if(!p||fread(p,1,n,f)!=n||fgetc(f)!=EOF||ferror(f))goto done;
 *out=p;*length=n;p=NULL;result=0;
done:free(p);fclose(f);return result;
}

int AudiK1Write(const char *path,const void *data,unsigned n){
 if(!path||!data||n<40||n>LIMIT)return -1;
 FILE *f=fopen(path,"wb");if(!f)return -1;
 unsigned char h[4]={(unsigned char)n,(unsigned char)(n>>8),(unsigned char)(n>>16),(unsigned char)(n>>24)};
 int result=fwrite(h,1,4,f)==4&&fwrite(data,1,n,f)==n?0:-1;
 if(fclose(f))result=-1;if(result)unlink(path);return result;
}

static const char *log_root(void){const char *p=getenv("AUDI_K1_DIR");return p?p:"/mnt/UDISK/audi-zoom6238";}
static void record(const char *event,unsigned id,unsigned count,int status){
 char path[512];if(snprintf(path,sizeof(path),"%s/k1-events.log",log_root())>=(int)sizeof(path))return;
 struct stat st;if(!stat(path,&st)&&st.st_size>4096)return;
 FILE *f=fopen(path,"a");if(f){fprintf(f,"K1 pid=%ld %s id=%X previous_hids=%u status=%d\n",(long)getpid(),event,id,count,status);fclose(f);}
}
static void capture_hids(const char *name,const void *data,unsigned n){
 char path[512];int error=0;
 if(snprintf(path,sizeof(path),"%s/k1-hids-%s.bplist",log_root(),name)>=(int)sizeof(path)||!access(path,F_OK))return;
 CF root=api.decode(data,n,&error);if(!root||error||api.type(root)!=5){if(root)api.release(root);return;}
 CF h=api.get(root,(CF)&k_hids);unsigned len=0;void *raw=h&&api.type(h)==1?api.serialize(h,&len,&error):NULL;
 if(raw&&!error&&len<=8192){FILE *f=fopen(path,"wb");if(f){(void)fwrite(raw,1,len,f);fclose(f);}}
 free(raw);api.release(root);
}

int SetInfoFile(const void *context,const char *filename){
 pthread_mutex_lock(&lock);
 if(!original){original=(int (*)(const void *,const char *))dlsym(RTLD_NEXT,"SetInfoFile");
  if(original&&AudiK1Bind((void *)original,&api))memset(&api,0,sizeof(api));}
 if(!original){pthread_mutex_unlock(&lock);return -1;}
 if(!context||!filename||!api.decode||sequence>=8){pthread_mutex_unlock(&lock);return original(context,filename);}
 void *input=NULL,*output=NULL;unsigned n=0,m=0,count=0;
 unsigned id=((const unsigned char *)context)[0x495];int status=-1;char *temp=NULL;
 if(!AudiK1Read(filename,&input,&n)){
  capture_hids("before",input,n);
  status=AudiK1Transform(&api,input,n,id,&output,&m,&count);
 }
 if(!status){
  unsigned slot=sequence++;temp=paths[slot];
  snprintf(temp,sizeof(paths[slot]),"/tmp/audi-k1-%ld-%u.info",(long)getpid(),slot);
  if(AudiK1Write(temp,output,m)){record("write-failed-original",id,count,-1);status=-1;}
  else{capture_hids("before",input,n);capture_hids("after",output,m);record("extra-knob-prepared",id,count,0);}
 }else record(status==1?"id-exists-original":"validation-failed-original",id,count,status);
 free(input);free(output);pthread_mutex_unlock(&lock);
 /* This calls the native parser once. Its original file remains untouched. */
 int result=original(context,status?filename:temp);
 if(!status){
  /* Same eight flags for advertisement and the native report encoder. The
     donor copies these into its Knob configuration too (layout shifted +0x18).
     This is session RAM; original application and configuration files stay intact. */
  if(!result)memcpy((unsigned char *)context+0x698,donor_flags,sizeof(donor_flags));
  record("extra-knob-forwarded",id,count,result);
 }
 return result;
}
