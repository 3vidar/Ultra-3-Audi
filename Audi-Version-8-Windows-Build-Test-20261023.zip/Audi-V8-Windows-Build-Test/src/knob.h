#ifndef AUDI_K1_H
#define AUDI_K1_H
typedef void *CF;
typedef struct {
 CF (*decode)(const void *,unsigned,int *);
 CF (*get)(CF,CF);int (*equal)(CF,CF);void (*release)(CF);
 void *(*serialize)(CF,unsigned *,int *);unsigned (*type)(CF);
 int (*count)(CF);CF (*item)(CF,int);CF (*copy_array)(CF,int,CF);
 void (*set)(CF,CF,CF);
 int (*build_descriptor)(void **,unsigned *,const unsigned char *);
 int (*build_hid)(CF *,unsigned,const char *,unsigned,unsigned,unsigned,const void *,unsigned,CF);
 void (*build_report)(void *,unsigned,unsigned,unsigned,int,int,int,int,const unsigned char *,unsigned *);
} K1API;
int AudiK1Bind(void *,K1API *);
int AudiK1Transform(K1API *,const void *,unsigned,unsigned,void **,unsigned *,unsigned *);
int AudiK1Read(const char *,void **,unsigned *);
int AudiK1Write(const char *,const void *,unsigned);
#endif
