#define _GNU_SOURCE
#include <dlfcn.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>

/* Internal addresses are specific to the verified 26011618.6238.2 libraries. */
#define MAX_REQUEST 4096u
#define MAX_RESPONSE 1024u
#define SOCKET_PATH "/tmp/audi-zoom-6238.sock"
typedef void *CF;
typedef int (*DelegateFn)(void *,const void *);
typedef int (*RawFn)(const void *,unsigned,void *,unsigned *,void *);
typedef CF (*DecodeFn)(const void *,unsigned,int *);
typedef CF (*GetFn)(CF,CF);
typedef int (*EqualFn)(CF,CF);
typedef CF (*RetainFn)(CF);
typedef void (*ReleaseFn)(CF);
typedef void *(*SerializeFn)(CF,unsigned *,int *);
typedef void (*CompletionFn)(int,CF,void *);
typedef int (*SendFn)(void *,CF,CompletionFn,void *);
static struct {uint64_t tag;char text[8];} const key_type={0x7fffffff00010756ULL,"type"};
static struct {uint64_t tag;char text[24];} const val_zoom={0x7fffffff00010756ULL,"changeMapZoomLevel"};
static pthread_mutex_t context_lock=PTHREAD_MUTEX_INITIALIZER;
static pthread_once_t server_once=PTHREAD_ONCE_INIT;
static void *wireless_context;
static DecodeFn decode_request;
static GetFn get_value;
static EqualFn equal_value;
static RetainFn retain_value;
static ReleaseFn release_value;
static SerializeFn serialize_value;
static SendFn send_value;
static DecodeFn wired_decode;
static GetFn wired_get;
static EqualFn wired_equal;
static ReleaseFn wired_release;
static RawFn original_raw;
static DelegateFn actual_delegate;

static void log_event(const char *event,int status,unsigned bytes){
 const char *path=getenv("AUDI_ZOOM_LOG"); if(!path)path="/tmp/audi-zoom.log";
 struct stat st; if(!stat(path,&st)&&st.st_size>65536)return;
 FILE *f=fopen(path,"a");if(f){fprintf(f,"pid=%ld %s status=%d bytes=%u\n",(long)getpid(),event,status,bytes);fclose(f);}
}
static void capture_request(const void *data,unsigned len){
 static int saved;const char *path=getenv("AUDI_ZOOM_CAPTURE");
 if(saved||!path)return;
 FILE *f=fopen(path,"wb");if(f){if(fwrite(data,1,len,f)==len)saved=1;fclose(f);}
}
static int all_io(int fd,void *buffer,unsigned length,int writing){
 unsigned char *p=buffer;
 while(length){ssize_t n=writing?send(fd,p,length,MSG_NOSIGNAL):recv(fd,p,length,0);
  if(n<0&&errno==EINTR)continue;if(n<=0)return -1;p+=n;length-=(unsigned)n;}
 return 0;
}
static void socket_deadline(int fd){struct timeval t={3,0};setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&t,sizeof(t));setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&t,sizeof(t));}
static uint32_t be32(uint32_t n){return __builtin_bswap32(n);}
static int zoom_dictionary(CF d,GetFn get,EqualFn equal){return d&&equal(get(d,(CF)&key_type),(CF)&val_zoom);}

/* A queued zoom is a one-way command, as in the Audi AltScreen sender. It must
 * not use the changeModes completion or demand a plist body from the iPhone.
 * The local reply acknowledges queuing, not execution by the phone. */
static const unsigned char reply_template[] = {
 0x62,0x70,0x6c,0x69,0x73,0x74,0x30,0x30,0xd1,0x01,0x02,
 0x56,0x73,0x74,0x61,0x74,0x75,0x73,0x13,
 0,0,0,0,0,0,0,0, 0x08,0x0b,0x12,
 0,0,0,0,0,0,0x01,0x01, 0,0,0,0,0,0,0,0x03,
 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0x1b
};
static int status_reply(int status,void *out,unsigned *len){
 memcpy(out,reply_template,sizeof(reply_template));
 uint64_t value=(uint64_t)(int64_t)status;
 for(unsigned i=0;i<8;i++)((unsigned char *)out)[19+i]=(unsigned char)(value>>(56-8*i));
 *len=sizeof(reply_template);return 0;
}
static int wireless_command(const void *data,unsigned len,void *out,unsigned *outlen){
 int error=0;*outlen=0;
 CF dictionary=decode_request(data,len,&error);
 if(error||!zoom_dictionary(dictionary,get_value,equal_value)){if(dictionary)release_value(dictionary);return -50;}
 capture_request(data,len);
 pthread_mutex_lock(&context_lock);
 void *ctx=wireless_context;void *session=ctx?*(void **)((char *)ctx+0x6e0):0;
 if(!session||!*((unsigned char *)ctx+0x6dc))error=-107;
 else error=send_value(session,dictionary,NULL,NULL);
 pthread_mutex_unlock(&context_lock);release_value(dictionary);
 if(error)return error;
 return status_reply(0,out,outlen);
}
static void *serve(void *unused){
 (void)unused;int fd=socket(AF_UNIX,SOCK_STREAM,0);if(fd<0){log_event("listener-error",errno,0);return 0;}
 struct sockaddr_un addr={.sun_family=AF_UNIX};strcpy(addr.sun_path,SOCKET_PATH);
 /* Never remove another running listener. A stale task socket is safe to replace. */
 if(bind(fd,(struct sockaddr *)&addr,sizeof(addr))){
  int probe=socket(AF_UNIX,SOCK_STREAM,0);int active=probe>=0&&!connect(probe,(struct sockaddr *)&addr,sizeof(addr));if(probe>=0)close(probe);
  if(active||errno!=ECONNREFUSED){close(fd);return 0;}
  unlink(SOCKET_PATH);if(bind(fd,(struct sockaddr *)&addr,sizeof(addr))){close(fd);return 0;}
 }
 chmod(SOCKET_PATH,0600);if(listen(fd,4)){close(fd);return 0;}log_event("listener-ready",0,0);
 for(;;){int c=accept(fd,0,0);if(c<0){if(errno==EINTR)continue;break;}socket_deadline(c);
  uint32_t header[2];unsigned char input[MAX_REQUEST],output[MAX_RESPONSE];unsigned n=0;int error=-50;
  if(!all_io(c,header,8,0)&&header[0]==0x314d5a41){unsigned bytes=be32(header[1]);
   if(bytes&&bytes<=MAX_REQUEST&&!all_io(c,input,bytes,0)){error=wireless_command(input,bytes,output,&n);log_event("phone-queue",error,bytes);}}
  uint32_t answer[2]={be32((uint32_t)error),be32(n)};
  if(!all_io(c,answer,8,1)&&n)all_io(c,output,n,1);close(c);
 }
 close(fd);return 0;
}
static void start_server(void){pthread_t thread;if(!pthread_create(&thread,0,serve,0))pthread_detach(thread);}
static int relay(const void *data,unsigned len,void *out,unsigned *outlen,void *ctx){
 if(!data||!out||!outlen||!len||len>MAX_REQUEST)return -50;
 int e=0;CF d=wired_decode(data,len,&e);int zoom=!e&&zoom_dictionary(d,wired_get,wired_equal);if(d)wired_release(d);
 if(!zoom)return original_raw?original_raw(data,len,out,outlen,ctx):0;
 *outlen=0;int fd=socket(AF_UNIX,SOCK_STREAM,0);if(fd<0)return status_reply(-errno,out,outlen);socket_deadline(fd);
 struct sockaddr_un addr={.sun_family=AF_UNIX};strcpy(addr.sun_path,SOCKET_PATH);
 if(connect(fd,(struct sockaddr *)&addr,sizeof(addr))){e=-errno;close(fd);log_event("relay-unavailable",e,len);return status_reply(e,out,outlen);}
 uint32_t header[2]={0x314d5a41,be32(len)},answer[2];
 e=all_io(fd,header,8,1)||all_io(fd,(void *)data,len,1)||all_io(fd,answer,8,0)?-5:(int32_t)be32(answer[0]);
 if(!e){unsigned n=be32(answer[1]);if(!n||n>MAX_RESPONSE)e=-90;else if(all_io(fd,out,n,0))e=-5;else *outlen=n;}
 close(fd);log_event("relay-result",e,len);
 /* A zoom failure belongs in the command reply. Returning it as an HTTP
  * handler failure would interrupt the existing control connection. */
 return e?status_reply(e,out,outlen):0;
}
int SetDelegate(void *context,const void *delegate){
 if(!actual_delegate){actual_delegate=(DelegateFn)dlsym(RTLD_NEXT,"SetDelegate");if(!actual_delegate)return -38;}
 Dl_info info;if(!dladdr((void *)actual_delegate,&info)||!info.dli_fname)return -38;
 uintptr_t base=(uintptr_t)info.dli_fbase;
 if(strstr(info.dli_fname,"librcarplay.so")){
  if((uintptr_t)actual_delegate-base!=0x40d2a)return -38;
  wired_decode=(DecodeFn)(base+0xba8a);wired_get=(GetFn)(base+0x8a58);wired_equal=(EqualFn)(base+0x87ec);wired_release=(ReleaseFn)(base+0x87e8);
  unsigned char copy[0x58];if(!delegate)return -50;memcpy(copy,delegate,sizeof(copy));memcpy(&original_raw,copy+0x10,sizeof(original_raw));RawFn hook=relay;memcpy(copy+0x10,&hook,sizeof(hook));
  log_event("receiver-hook",0,0);return actual_delegate(context,copy);
 }
 if(strstr(info.dli_fname,"libwcarplay_new.so")){
  if((uintptr_t)actual_delegate-base!=0x1c518)return -38;
  decode_request=(DecodeFn)(base+0x4e9e8);get_value=(GetFn)(base+0x71fc8);equal_value=(EqualFn)(base+0x71a98);retain_value=(RetainFn)(base+0x71a90);release_value=(ReleaseFn)(base+0x71a94);serialize_value=(SerializeFn)(base+0x4e098);send_value=(SendFn)(base+0x35aa0);
  int result=actual_delegate(context,delegate);if(!result){pthread_mutex_lock(&context_lock);wireless_context=context;pthread_mutex_unlock(&context_lock);pthread_once(&server_once,start_server);}return result;
 }
 return actual_delegate(context,delegate);
}
int DestroyCarPlay(void *context){
 int (*actual)(void *)=(int(*)(void *))dlsym(RTLD_NEXT,"DestroyCarPlay");
 pthread_mutex_lock(&context_lock);if(wireless_context==context)wireless_context=0;int result=actual?actual(context):-38;pthread_mutex_unlock(&context_lock);return result;
}
#ifdef AUDI_ZOOM_TEST
int AudiTestConfigure(void *ctx,DecodeFn d,GetFn g,EqualFn e,RetainFn r,ReleaseFn f,SerializeFn s,SendFn send){
 decode_request=d;get_value=g;equal_value=e;retain_value=r;release_value=f;serialize_value=s;send_value=send;wireless_context=ctx;return 0;
}
int AudiTestSend(const void *d,unsigned n,void *out,unsigned *len){return wireless_command(d,n,out,len);}
void AudiTestStartServer(void){pthread_once(&server_once,start_server);}
#endif
