/* V821 SPI-NOR backup reader, using the local XFEL FEL transport and SPI payload.
 * Only commands 9F (JEDEC), 5A (SFDP), 05 (status), 03 (array read) are sent to flash.
 * No WREN, status write, reset, erase, program, four-byte-mode or eFuse operation.
 */
#include <fel.h>
#include <fcntl.h>
#include <sys/stat.h>

#define FLASH_BYTES (16u * 1024u * 1024u)
struct reader { struct xfel_ctx_t ctx; uint32_t swapbuf, swaplen, cmdlen; };

static int transfer(struct reader *r, uint8_t *tx, uint32_t txlen,
                    void *rx, uint32_t rxlen)
{
    int valid = (txlen == 1 && (tx[0] == 0x9f || tx[0] == 0x05)) ||
                (txlen == 5 && tx[0] == 0x5a) || (txlen == 4 && tx[0] == 0x03);
    if(!valid || !rxlen || rxlen > 65536 || rxlen > r->swaplen) {
        fprintf(stderr, "ERROR: Unzulässiger Lesebefehl.\n");
        return 0;
    }
    return fel_spi_xfer(&r->ctx, r->swapbuf, r->swaplen, r->cmdlen,
                        tx, txlen, rx, rxlen);
}

static int sfdp_read(struct reader *r, uint32_t addr, uint8_t *rx, uint32_t len)
{
    uint8_t tx[] = {0x5a, (uint8_t)(addr >> 16), (uint8_t)(addr >> 8), (uint8_t)addr, 0};
    return transfer(r, tx, sizeof(tx), rx, len);
}

static void hex(const uint8_t *buf, size_t len)
{
    for(size_t i = 0; i < len; i++) printf("%02x", buf[i]);
}

static int probe(struct reader *r)
{
    uint8_t jedec[3], status, header[8], ph[8], table[64] = {0};
    uint8_t tx_id = 0x9f, tx_status = 0x05;
    if(!fel_spi_init(&r->ctx, &r->swapbuf, &r->swaplen, &r->cmdlen) ||
       !transfer(r, &tx_id, 1, jedec, 3) || !transfer(r, &tx_status, 1, &status, 1) ||
       !sfdp_read(r, 0, header, sizeof(header))) {
        fprintf(stderr, "ERROR: Speicher-Erkennung fehlgeschlagen.\n"); return 0;
    }
    if((jedec[0] == 0 && jedec[1] == 0 && jedec[2] == 0) ||
       (jedec[0] == 255 && jedec[1] == 255 && jedec[2] == 255) ||
       memcmp(header, "SFDP", 4) || header[5] != 1 || (status & 1)) {
        fprintf(stderr, "ERROR: Ungültige JEDEC/SFDP-Antwort oder Speicher beschäftigt.\n");
        return 0;
    }
    int found = 0;
    for(unsigned i = 0; i <= header[6]; i++) {
        if(!sfdp_read(r, 8u + i * 8u, ph, sizeof(ph))) return 0;
        if(ph[0] == 0 && ph[7] == 0xff && ph[2] == 1 && ph[3] >= 2) {
            uint32_t addr = (uint32_t)ph[4] | ((uint32_t)ph[5] << 8) | ((uint32_t)ph[6] << 16);
            uint32_t len = ph[3] * 4u;
            if(len > sizeof(table)) len = sizeof(table);
            if(!sfdp_read(r, addr, table, len)) return 0;
            found = 1; break;
        }
    }
    if(!found) { fprintf(stderr, "ERROR: SFDP-Basistabelle fehlt.\n"); return 0; }
    uint32_t density = get_unaligned_le32(table + 4);
    uint64_t bits = density & 0x80000000u ?
                    ((density & 0x7fffffffu) < 63 ? 1ull << (density & 0x7fffffffu) : 0) :
                    (uint64_t)density + 1ull;
    uint32_t address_support = (get_unaligned_le32(table) >> 17) & 3u;
    if(bits != (uint64_t)FLASH_BYTES * 8 || address_support > 1) {
        fprintf(stderr, "ERROR: Erwartet werden 16 MiB mit 3-Byte-Adressierung, gemeldet: %llu Bytes.\n",
                (unsigned long long)(bits / 8));
        return 0;
    }
    printf("{\"chip\":\"V821\",\"jedec\":\""); hex(jedec, 3);
    printf("\",\"bytes\":%u,\"status1\":%u,\"sfdp_header\":\"", FLASH_BYTES, status);
    hex(header, sizeof(header)); printf("\",\"sfdp_basic_table\":\""); hex(table, sizeof(table));
    printf("\",\"flash_write_commands\":false}\n"); fflush(stdout);
    return 1;
}

static int full_read(struct reader *r, const char *filename)
{
    int fd = open(filename, O_WRONLY | O_CREAT | O_EXCL, 0600);
    if(fd < 0) { perror("Ausgabedatei"); return 0; }
    uint8_t buf[65536];
    for(uint32_t addr = 0; addr < FLASH_BYTES; addr += sizeof(buf)) {
        uint8_t tx[] = {0x03, (uint8_t)(addr >> 16), (uint8_t)(addr >> 8), (uint8_t)addr};
        if(!transfer(r, tx, sizeof(tx), buf, sizeof(buf))) {
            fprintf(stderr, "ERROR: Lesefehler bei 0x%06x.\n", addr); close(fd); return 0;
        }
        size_t done = 0;
        while(done < sizeof(buf)) {
            ssize_t n = write(fd, buf + done, sizeof(buf) - done);
            if(n < 0 && errno == EINTR) continue;
            if(n <= 0) { perror("Datei schreiben"); close(fd); return 0; }
            done += (size_t)n;
        }
        if((addr + sizeof(buf)) % (1024 * 1024) == 0)
            fprintf(stderr, "Gelesen: %u / 16 MiB\n", (unsigned)((addr + sizeof(buf)) / (1024 * 1024)));
    }
    if(fsync(fd) || close(fd)) { perror("Datei abschließen"); return 0; }
    printf("READ_OK bytes=%u\n", FLASH_BYTES); fflush(stdout);
    return 1;
}

static void usage(void)
{
    puts("V821-Flash-Leser: version | probe | read <neue-Ausgabedatei>");
    puts("Liest ausschließlich 16-MiB-SPI-NOR. Keine Flash-Schreibbefehle.");
}

int main(int argc, char **argv)
{
    int is_version = argc == 2 && !strcmp(argv[1], "version");
    int is_probe = argc == 2 && !strcmp(argv[1], "probe");
    int is_read = argc == 3 && !strcmp(argv[1], "read");
    if(argc == 1 || (argc == 2 && !strcmp(argv[1], "--help"))) { usage(); return 0; }
    if(!is_version && !is_probe && !is_read) { usage(); return 2; }
    struct reader r = {0}; libusb_context *context = NULL; libusb_device **list = NULL;
    int result = 1, init = libusb_init(&context);
    if(init) { fprintf(stderr, "USB-Initialisierung: %s\n", libusb_error_name(init)); return 1; }
    ssize_t count = libusb_get_device_list(context, &list);
    libusb_device *selected = NULL;
    unsigned matches = 0;
    for(ssize_t i = 0; i < count; i++) {
        struct libusb_device_descriptor desc;
        if(libusb_get_device_descriptor(list[i], &desc)) continue;
        if(desc.idVendor == 0x1f3a && desc.idProduct == 0xefe8) {
            selected = list[i];
            matches++;
        }
    }
    if(matches != 1) {
        fprintf(stderr, "ERROR: Genau ein FEL-Gerät muss verbunden sein.\n"); goto cleanup;
    }
    int opened = libusb_open(selected, &r.ctx.hdl);
    if(opened) fprintf(stderr, "USB öffnen: %s\n", libusb_error_name(opened));
    if(!r.ctx.hdl || !fel_init(&r.ctx) || r.ctx.version.id != 0x00188200 ||
       memcmp(r.ctx.version.magic, "AWUSBFEX", 8)) {
        fprintf(stderr, "ERROR: Kein bestätigter V821-FEL-Zugang.\n"); goto cleanup;
    }
    if(is_version) {
        printf("AWUSBFEX ID=0x%08x(V821) dflag=0x%02x dlength=0x%02x scratchpad=0x%08x\n",
               r.ctx.version.id, r.ctx.version.dflag, r.ctx.version.dlength, r.ctx.version.scratchpad);
        result = 0;
    } else if(probe(&r)) result = is_probe || full_read(&r, argv[2]) ? 0 : 1;
cleanup:
    if(r.ctx.hdl) { libusb_release_interface(r.ctx.hdl, 0); libusb_close(r.ctx.hdl); }
    if(list) libusb_free_device_list(list, 1);
    libusb_exit(context);
    return result;
}
