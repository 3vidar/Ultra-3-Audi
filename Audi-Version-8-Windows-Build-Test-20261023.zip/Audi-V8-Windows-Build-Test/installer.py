"""Audi Version 8 Windows Build Test installer."""
from pathlib import Path
import argparse
import datetime
import importlib.metadata
import json
import os
import platform
import secrets
import shutil
import struct
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from common import SIZE, sha, backup_pair, profile
from integrity import verify_release
from prepare import prepare
from flash import flash
from fel_windows import reader
from activate import activate, adb_command, verify_boot
from usb_transport import backend

PRIVATE=ROOT/'private'

def confirm(word,message):
    print(message,flush=True)
    if input('Type '+word+' to continue: ').strip()!=word:
        raise ValueError('Cancelled before the next operation.')

def preflight():
    if platform.system()!='Windows' or platform.machine().lower() not in ('amd64','x86_64') or struct.calcsize('P')!=8:
        raise ValueError('Use 64-bit Python on Windows 10/11 x64.')
    if not (3,11)<=sys.version_info[:2]<=(3,13):
        raise ValueError('Use 64-bit Python 3.11, 3.12 or 3.13.')
    for line in (ROOT/'requirements.txt').read_text(encoding='ascii').splitlines():
        name,wanted=line.split('==')
        if importlib.metadata.version(name)!=wanted:
            raise ValueError('Dependency version differs. Run Start-Windows.cmd again.')
    backend()
    if PRIVATE.is_symlink():
        raise ValueError('The private folder must not be a link.')
    PRIVATE.mkdir(exist_ok=True)
    if shutil.disk_usage(PRIVATE).free<512*1024*1024:
        raise ValueError('At least 512 MiB of free disk space is required.')

def check_fel():
    version=reader('version')
    if 'ID=0x00188200(V821)' not in version:
        raise ValueError('Unexpected processor.')
    result=json.loads(reader('probe'))
    if result.get('chip')!='V821' or result.get('jedec')!='0b4018' or result.get('bytes')!=SIZE or result.get('flash_write_commands') is not False:
        raise ValueError('Unexpected flash device.')
    print('FEL CONNECTION VERIFIED.',flush=True)
    return result

def wait_fel():
    preflight()
    print('Waiting for FEL. Remove the contact bridge within five seconds in all cases.',flush=True)
    deadline=time.monotonic()+90
    while time.monotonic()<deadline:
        try:
            reader('version')
        except Exception:
            time.sleep(1);continue
        print('FEL DETECTED. Remove every contact bridge now. Leave USB connected.',flush=True)
        input('Press Enter only after removing the bridge: ')
        return check_fel()
    raise ValueError('FEL not detected. Remove any bridge. Set up WinUSB as described in the guide.')

def save_state(directory,phase,**data):
    path=Path(directory)/'state.json'
    value=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
    value.setdefault('history',[]).append({'phase':phase,'at':datetime.datetime.now().isoformat(timespec='seconds')})
    value.update(phase=phase,**data)
    temp=path.with_name('state.json.tmp')
    temp.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8');temp.replace(path)

def root_shell(command,timeout=30):
    return subprocess.run(adb_command()+['shell',command],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout,check=True).stdout

def wait_root():
    print('Waiting for the USB diagnostic connection.\nIf this is its first connection, install WinUSB for Audi-USB-Diagnose (18D1:D002) in Zadig.\nUse only this dongle. Leave it connected.',flush=True)
    deadline=time.monotonic()+300
    while time.monotonic()<deadline:
        try:
            output=root_shell('id',timeout=15)
            if 'uid=0(root)' in output:
                return
        except (OSError,ValueError,subprocess.SubprocessError):
            pass
        time.sleep(2)
    raise ValueError('USB root connection not confirmed. Install its WinUSB driver, reopen the installer and select 3.')

def activate_remaining(path):
    _,data=profile(path)
    wait_root()
    verify_boot(root_shell('id; sha256sum /dev/mtd3 /sbin/ly_boot.sh'),data['expected'])
    result=root_shell('if [ -e /mnt/UDISK/audi-zoom6238 ]; then echo EXISTS; else echo ABSENT; fi').strip()
    if result not in ('EXISTS','ABSENT'):
        raise ValueError('Runtime state is ambiguous.')
    return activate(path,resume=result=='EXISTS')

def install():
    preflight()
    confirm('ULTRA3','V8 BUILD TEST. Build number is not checked. Connect the ly6238 Mini Ultra 3 in FEL mode. Remove every contact bridge.')
    device=check_fel()
    directory=PRIVATE/('device-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(3))
    backups=directory/'backups';backups.mkdir(parents=True)
    save_state(directory,'reading_original',device_probe=device)
    try:
        for name in ('a','b'):
            print('Reading full backup '+name.upper()+'. Keep USB connected.',flush=True)
            reader('read',backups/('original-'+name+'.bin'))
        original=backup_pair(backups/'original-a.bin',backups/'original-b.bin')
        save_state(directory,'original_backups_verified',backup_sha256=sha(original))
        print('BOTH ORIGINAL BACKUPS VERIFIED.',flush=True)
        prepare(backups/'original-a.bin',backups/'original-b.bin',directory/'device-v8')
        path=directory/'device-v8/profile.json'
        save_state(directory,'ready_to_flash',profile='device-v8/profile.json')
        print('Keep this backup folder:',directory)
        confirm('INSTALL','Ready to install Version 8 Build Test from your own backup. The target build is not vehicle-tested. Keep USB connected during writing and readback.')
        save_state(directory,'flashing_rootfs');flash(path)
        save_state(directory,'rootfs_readback_verified')
        input('Unplug and reconnect normally, without any bridge. Then press Enter: ')
        result=activate_remaining(path)
        save_state(directory,'ready_for_vehicle_test',actual_root_boot_verified=result['actual_root_boot_verified'],vehicle_mode_enabled=result['vehicle_mode_enabled'])
        print('V8 BUILD TEST INSTALLED; BYTES AND BOOT VERIFIED. You may unplug the dongle and test in the parked Audi.')
    except BaseException as error:
        save_state(directory,'stopped',error=type(error).__name__+': '+str(error))
        print('Installation stopped. Keep this backup folder:',directory)
        raise

def choose_profile():
    files=sorted(PRIVATE.glob('device-*/device-v8/profile.json'))
    if not files:
        raise ValueError('No original backup found in this installer folder.')
    for number,path in enumerate(files,1):
        print(str(number)+': '+str(path.relative_to(ROOT)))
    value=input('Select your backup number: ').strip()
    if not value.isdigit() or not 1<=int(value)<=len(files):
        raise ValueError('No backup selected.')
    return files[int(value)-1]

def restore(path):
    preflight();_,data=profile(path)
    confirm('RESTORE','Restore your own original root filesystem. Keep USB connected.')
    try:
        check_fel()
    except Exception:
        wait_root();verify_boot(root_shell('id; sha256sum /dev/mtd3 /sbin/ly_boot.sh'),data['expected'])
        try:
            root_shell('sync; if echo 1 >/sys/class/misc/ly_misc_dev/ly/ly_efex; then sync; reboot -f; else echo V8_FEL_FAILED; exit 1; fi',timeout=15)
        except (OSError,subprocess.SubprocessError):
            pass
        for _ in range(30):
            try:
                check_fel();break
            except Exception:
                time.sleep(1)
        else:
            raise ValueError('FEL restart not confirmed. No recovery data written.')
    flash(path,restore=True)
    print('ORIGINAL ROOT FILESYSTEM RESTORED AND VERIFIED. Reconnect normally and test original CarPlay.')

def menu():
    while True:
        print('\nAudi Version 8 Build Test - Windows\n1: Check FEL connection\n2: Back up and install V8 Build Test\n3: Continue installation after reconnecting\n4: Restore your original firmware filesystem\n5: Verify installer files\n6: Wait for FEL connection\n0: Exit')
        choice=input('Select: ').strip()
        if choice=='0':
            return
        try:
            if choice=='5':
                print('INSTALLER FILES VERIFIED:',verify_release());continue
            preflight()
            if choice=='1':check_fel()
            elif choice=='2':install()
            elif choice=='3':
                result=activate_remaining(choose_profile())
                if result['vehicle_mode_enabled']:print('V8 BUILD TEST INSTALLED; BYTES AND BOOT VERIFIED. You may unplug the dongle.')
            elif choice=='4':restore(choose_profile())
            elif choice=='6':wait_fel()
            else:raise ValueError('Select a listed number.')
        except Exception as error:
            print('STOPPED:',error,flush=True)
            print('Keep the installer folder and all backups. Use 3 to continue after driver setup, or 4 to restore.')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify-release',action='store_true')
    options=parser.parse_args()
    verify_release()
    if options.verify_release:
        print('INSTALLER FILES VERIFIED. No device accessed.');return
    menu()

if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('Stopped. Keep all backups.');raise SystemExit(130)
    except Exception as error:print('STOPPED:',error,file=sys.stderr);raise SystemExit(1)
