@echo off
setlocal DisableDelayedExpansion
pushd "%~dp0"
if errorlevel 1 exit /b 1
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PYTHONNOUSERSITE=1"
where py >nul 2>nul
if not errorlevel 1 goto use_launcher
where python >nul 2>nul
if errorlevel 1 goto missing_python
python -X utf8 tools\bootstrap.py
set "result=%errorlevel%"
goto finish
:use_launcher
for %%V in (3.13 3.12 3.11) do (
    py -%%V -c "import struct; assert struct.calcsize('P') == 8" >nul 2>nul
    if not errorlevel 1 (
        py -%%V -X utf8 tools\bootstrap.py
        goto launcher_finished
    )
)
goto missing_python
:launcher_finished
set "result=%errorlevel%"
goto finish
:missing_python
echo Install 64-bit Python 3.11, 3.12 or 3.13 from https://www.python.org/downloads/windows/
set "result=1"
:finish
echo.
pause
popd
exit /b %result%
